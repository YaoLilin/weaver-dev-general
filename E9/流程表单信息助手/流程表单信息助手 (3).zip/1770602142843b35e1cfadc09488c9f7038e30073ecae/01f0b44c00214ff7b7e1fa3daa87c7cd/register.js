
let loaded = false;

function getUserId() {
  const user = ecodeSDK.getEcodeParams(['ecode_params'])._user
  if (!user) {
    return null;
  }
  return user.id;
}

ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop', {
  fn: (props) => {
    if (location.href.includes('spa/workflow/static4form/index') && props.buttons && props.buttons.length > 0) {
      const userId = getUserId();
      if (userId && userId === '1' && !loaded) {
        loaded = true;
        // 添加组件到页面
        loadTool();
      }
    }
  }
});

const FormTool = (props) => {
  const params = {
    appId: '${appId}',
    name: 'FormTool',
    isPage: false,
    noCss: true,
    props
  }
  const NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(params) : (<NewCom { ...props } />);
}

function loadTool() {
  const div = document.getElementById('container');
  // 创建子元素
  const node = document.createElement('div');
  div.appendChild(node);
  // 将自己创建的组件：Main ，渲染到子元素中
  ReactDOM.render(<FormTool />, node);
}
