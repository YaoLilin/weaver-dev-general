"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem;
/**
 * 关于面板组件
 * 用于显示关于信息，包括：
 * - ecode 应用ID
 */

var AboutPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(AboutPanel, _React$Component);

  function AboutPanel() {
    _classCallCheck(this, AboutPanel);

    return _possibleConstructorReturn(this, _getPrototypeOf(AboutPanel).apply(this, arguments));
  }

  _createClass(AboutPanel, [{
    key: "render",
    value: function render() {
      return React.createElement("div", {
        style: {
          padding: '20px'
        }
      }, React.createElement(WeaFormItem, {
        label: "ecode \u5E94\u7528id",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        style: {
          marginBottom: '16px'
        }
      }, React.createElement("div", {
        style: {
          lineHeight: '30px'
        }
      }, '${appId}')));
    }
  }]);

  return AboutPanel;
}(React.Component);

ecodeSDK.exp(AboutPanel);