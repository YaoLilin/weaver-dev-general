"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaInput = _ecCom.WeaInput;
var _antd = antd,
    Input = _antd.Input,
    Icon = _antd.Icon,
    Modal = _antd.Modal,
    message = _antd.message;
/**
 * 主表字段信息面板组件
 * 用于显示流程表单的主表字段信息，包括：
 * - 字段搜索功能（支持中文名和数据库名搜索）
 * - 字段值显示（使用WeaInput组件）
 * - 字段显示值展示
 * - 字段定位功能（点击定位图标可定位到表单中的字段）
 * - 字段信息查看（点击感叹号图标可查看字段详细信息）
 * - 字段编辑功能（鼠标悬停显示编辑图标，点击可编辑字段值）
 * 
 * @props {Object} formInfo - 表单信息对象，包含tableInfo和maindata
 * @props {String} searchText - 搜索文本
 * @props {Function} onSearchChange - 搜索文本变化回调函数
 * @props {Function} onCloseDrawer - 关闭抽屉回调函数
 * @props {Number} requestId - 流程请求ID
 */

var MainFieldsPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MainFieldsPanel, _React$Component);

  function MainFieldsPanel(props) {
    var _this;

    _classCallCheck(this, MainFieldsPanel);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(MainFieldsPanel).call(this, props));

    _this.showFieldModal = function (fieldInfo) {
      _this.setState({
        fieldModalVisible: true,
        currentFieldInfo: fieldInfo
      });
    };

    _this.closeFieldModal = function () {
      _this.setState({
        fieldModalVisible: false,
        currentFieldInfo: null
      });
    };

    _this.locateField = function (fieldId) {
      try {
        // 关闭抽屉以便看到定位效果
        if (_this.props.onCloseDrawer) {
          _this.props.onCloseDrawer();
        } // 根据字段ID查找对应的DOM元素


        var className = "field".concat(fieldId, "_swapDiv");
        var fieldElement = document.querySelector(".".concat(className));

        if (fieldElement) {
          // 滚动到该元素
          fieldElement.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          }); // 添加高亮效果

          var originalStyle = {
            outline: fieldElement.style.outline,
            outlineOffset: fieldElement.style.outlineOffset,
            transition: fieldElement.style.transition
          };
          fieldElement.style.outline = '3px solid #1890ff';
          fieldElement.style.outlineOffset = '2px';
          fieldElement.style.transition = 'outline 0.3s ease'; // 3秒后移除高亮

          setTimeout(function () {
            fieldElement.style.outline = originalStyle.outline || '';
            fieldElement.style.outlineOffset = originalStyle.outlineOffset || '';
            fieldElement.style.transition = originalStyle.transition || '';
          }, 3000);
        } else {
          // 如果找不到元素，尝试查找其他可能的类名
          var alternativeSelectors = ["#field".concat(fieldId), "[id*=\"field".concat(fieldId, "\"]"), ".field".concat(fieldId), "[class*=\"field".concat(fieldId, "\"]")];
          var found = false;

          for (var _i = 0, _alternativeSelectors = alternativeSelectors; _i < _alternativeSelectors.length; _i++) {
            var selector = _alternativeSelectors[_i];
            var element = document.querySelector(selector);

            if (element) {
              element.scrollIntoView({
                behavior: 'smooth',
                block: 'center',
                inline: 'nearest'
              });
              found = true;
              break;
            }
          }

          if (!found) {
            console.warn("\u672A\u627E\u5230\u5B57\u6BB5ID\u4E3A ".concat(fieldId, " \u7684\u8868\u5355\u5143\u7D20"));
          }
        }
      } catch (error) {
        console.error('定位字段失败:', error);
      }
    };

    _this.getFieldDisplayValue = function (fieldData) {
      if (!fieldData) return '';

      if (fieldData.specialobj && fieldData.specialobj.length > 0) {
        return fieldData.specialobj.map(function (item) {
          return item.name;
        }).join(', ');
      }

      return fieldData.value || '';
    };

    _this.startEdit = function (field, fieldData) {
      var currentValue = _this.state.fieldValues["field".concat(field.fieldId)] !== undefined ? _this.state.fieldValues["field".concat(field.fieldId)] : fieldData.value || '';

      _this.setState({
        editingField: field.fieldId,
        editingValue: currentValue,
        hoveredField: null
      });
    };

    _this.cancelEdit = function () {
      _this.setState({
        editingField: null,
        editingValue: '',
        hoveredField: null
      });
    };

    _this.saveFieldValue = async function (field) {
      var requestId = _this.props.requestId;
      var _this$state = _this.state,
          editingValue = _this$state.editingValue,
          fieldValues = _this$state.fieldValues;

      if (!requestId) {
        message.error('无法获取请求ID');
        return;
      }

      try {
        // 调用后端接口保存字段值
        var params = new URLSearchParams();
        params.append('requestId', requestId);
        params.append('fieldName', field.fieldname);
        params.append('fieldValue', editingValue);
        var response = await fetch('/api/second-dev/workflow/field/main-field/change-value', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: params.toString()
        });
        var result = await response.json(); // 检查响应状态码和结果

        if (response.ok && (result.success || result.data && result.data.changeSuccess)) {
          message.success('保存成功'); // 更新字段值缓存

          _this.setState({
            fieldValues: _objectSpread({}, fieldValues, _defineProperty({}, "field".concat(field.fieldId), editingValue)),
            editingField: null,
            editingValue: ''
          }); // 更新表单中的字段值


          var fieldMark = "field".concat(field.fieldId);
          var fieldObj = window.WfForm ? window.WfForm.getFieldObj(fieldMark) : null;

          if (fieldObj) {
            fieldObj.value = editingValue;
          }
        } else {
          // 处理错误情况：优先显示返回的错误信息
          var errorMsg = result.msg || result.data && result.data.msg || result.message || result.data && result.data.message || "\u4FDD\u5B58\u5931\u8D25".concat(response.status ? ' (状态码: ' + response.status + ')' : '');
          message.error(errorMsg);
        }
      } catch (error) {
        console.error('保存字段值失败:', error);
        message.error('保存字段值失败: ' + error.message);
      }
    };

    _this.handleEditingValueChange = function (e) {
      _this.setState({
        editingValue: e.target.value
      });
    };

    _this.renderFieldItem = function (field, fieldData) {
      var _this$state2 = _this.state,
          editingField = _this$state2.editingField,
          editingValue = _this$state2.editingValue,
          hoveredField = _this$state2.hoveredField,
          fieldValues = _this$state2.fieldValues;
      var fieldKey = "field".concat(field.fieldId);
      var isEditing = editingField === field.fieldId;
      var isHovered = hoveredField === field.fieldId && !isEditing;
      var displayValue = fieldValues[fieldKey] !== undefined ? fieldValues[fieldKey] : fieldData.value || '';
      return React.createElement(WeaFormItem, {
        label: React.createElement("span", {
          title: field.fieldlabel,
          style: {
            display: 'inline-flex',
            alignItems: 'center',
            overflow: 'hidden',
            minWidth: 0,
            width: '100%'
          }
        }, React.createElement("i", {
          className: "icon-coms02-Positioning",
          type: "aim",
          style: {
            marginRight: '4px',
            cursor: 'pointer',
            color: '#999',
            fontSize: '14px',
            flexShrink: 0
          },
          onClick: function onClick(e) {
            e.stopPropagation();

            _this.locateField(field.fieldId);
          },
          title: "\u5B9A\u4F4D\u5230\u5B57\u6BB5"
        }), React.createElement(Icon, {
          type: "exclamation-circle",
          style: {
            marginRight: '4px',
            cursor: 'pointer',
            color: '#999',
            fontSize: '14px',
            flexShrink: 0
          },
          onClick: function onClick() {
            return _this.showFieldModal(field);
          }
        }), React.createElement("span", {
          style: {
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            flex: 1,
            minWidth: 0
          }
        }, field.fieldlabel)),
        style: {
          overflow: 'visible'
        },
        colon: false,
        labelCol: {
          span: 8
        },
        wrapperCol: {
          span: 16
        }
      }, React.createElement("div", {
        className: "wea-form-item-wrapper",
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          position: 'relative'
        },
        onMouseEnter: function onMouseEnter() {
          return !isEditing && _this.setState({
            hoveredField: field.fieldId
          });
        },
        onMouseLeave: function onMouseLeave() {
          return !isEditing && _this.setState({
            hoveredField: null
          });
        }
      }, isEditing ? React.createElement(React.Fragment, null, React.createElement(Input, {
        value: editingValue,
        onChange: _this.handleEditingValueChange,
        style: {
          flex: 1,
          maxWidth: 160
        },
        autoFocus: true
      }), React.createElement(Icon, {
        type: "check",
        style: {
          cursor: 'pointer',
          color: '#52c41a',
          fontSize: '16px',
          flexShrink: 0
        },
        onClick: function onClick() {
          return _this.saveFieldValue(field);
        },
        title: "\u4FDD\u5B58"
      }), React.createElement(Icon, {
        type: "cross",
        style: {
          cursor: 'pointer',
          color: '#f5222d',
          fontSize: '16px',
          flexShrink: 0
        },
        onClick: _this.cancelEdit,
        title: "\u53D6\u6D88"
      })) : React.createElement(React.Fragment, null, React.createElement(WeaInput, {
        value: displayValue,
        viewAttr: "1",
        style: {
          flex: 1,
          maxWidth: 160
        },
        textDecoration: true
      }), isHovered && React.createElement(Icon, {
        type: "edit",
        style: {
          cursor: 'pointer',
          color: '#1890ff',
          fontSize: '16px',
          flexShrink: 0,
          marginLeft: '4px'
        },
        onClick: function onClick() {
          return _this.startEdit(field, fieldData);
        },
        title: "\u7F16\u8F91"
      }), fieldData.specialobj && fieldData.specialobj.length > 0 && React.createElement("span", {
        style: {
          color: '#666',
          whiteSpace: 'nowrap'
        }
      }, "\u663E\u793A\u503C\uFF1A", _this.getFieldDisplayValue(fieldData)))));
    };

    _this.getFilteredMainFields = function () {
      var _this$props = _this.props,
          formInfo = _this$props.formInfo,
          searchText = _this$props.searchText;

      if (!formInfo || !formInfo.tableInfo || !formInfo.tableInfo.main) {
        return [];
      }

      var fieldInfoMap = formInfo.tableInfo.main.fieldinfomap || {};
      var fields = Object.keys(fieldInfoMap).map(function (fieldId) {
        return _objectSpread({
          fieldId: fieldId
        }, fieldInfoMap[fieldId]);
      });

      if (!searchText) {
        return fields;
      }

      var searchLower = searchText.toLowerCase();
      return fields.filter(function (field) {
        var fieldLabel = (field.fieldlabel || '').toLowerCase();
        var fieldName = (field.fieldname || '').toLowerCase();
        return fieldLabel.includes(searchLower) || fieldName.includes(searchLower);
      });
    };

    _this.state = {
      fieldModalVisible: false,
      // 字段信息 Modal 显示
      currentFieldInfo: null,
      // 当前显示的字段信息
      editingField: null,
      // 正在编辑的字段ID
      editingValue: '',
      // 正在编辑的字段值
      hoveredField: null,
      // 鼠标悬停的字段ID
      fieldValues: {} // 字段值缓存（用于更新显示）

    };
    return _this;
  } // 显示字段信息 Modal


  _createClass(MainFieldsPanel, [{
    key: "render",
    value: function render() {
      var _this$props2 = this.props,
          formInfo = _this$props2.formInfo,
          searchText = _this$props2.searchText,
          onSearchChange = _this$props2.onSearchChange;
      var _this$state3 = this.state,
          fieldModalVisible = _this$state3.fieldModalVisible,
          currentFieldInfo = _this$state3.currentFieldInfo;
      var fields = this.getFilteredMainFields();
      var mainData = formInfo ? formInfo.maindata : {}; // 检查是否有字段数据（不考虑搜索）

      var hasFormInfo = formInfo && formInfo.tableInfo && formInfo.tableInfo.main && formInfo.tableInfo.main.fieldinfomap;
      var fieldItems = [];

      for (var i = 0; i < fields.length; i += 2) {
        var field1 = fields[i];
        var field2 = fields[i + 1];
        var field1Data = mainData["field".concat(field1.fieldId)] || {};
        var field2Data = field2 ? mainData["field".concat(field2.fieldId)] || {} : null;
        fieldItems.push(React.createElement("div", {
          key: i,
          style: {
            display: 'flex',
            marginBottom: '10px'
          }
        }, React.createElement("div", {
          style: {
            width: 'calc(50% - 5px)',
            marginRight: '10px'
          }
        }, this.renderFieldItem(field1, field1Data)), field2 && React.createElement("div", {
          style: {
            width: 'calc(50% - 5px)'
          }
        }, this.renderFieldItem(field2, field2Data))));
      }

      return React.createElement("div", null, React.createElement("div", {
        style: {
          marginBottom: '16px'
        }
      }, React.createElement(Input, {
        placeholder: "\u641C\u7D22\u5B57\u6BB5\uFF08\u652F\u6301\u4E2D\u6587\u540D\u548C\u6570\u636E\u5E93\u540D\uFF09",
        value: searchText,
        onChange: onSearchChange,
        prefix: React.createElement(Icon, {
          type: "search"
        }),
        allowClear: true
      })), !hasFormInfo ? React.createElement("div", {
        style: {
          padding: '20px',
          textAlign: 'center',
          color: '#999'
        }
      }, "\u6682\u65E0\u5B57\u6BB5\u6570\u636E") : fieldItems.length > 0 ? React.createElement("div", {
        className: "wea-form-item-group"
      }, fieldItems) : React.createElement("div", {
        style: {
          padding: '20px',
          textAlign: 'center',
          color: '#999'
        }
      }, "\u6682\u65E0\u5339\u914D\u7684\u5B57\u6BB5\u6570\u636E"), React.createElement(Modal, {
        title: "\u5B57\u6BB5\u4FE1\u606F",
        visible: fieldModalVisible,
        onOk: this.closeFieldModal,
        onCancel: this.closeFieldModal,
        footer: [React.createElement("button", {
          key: "ok",
          onClick: this.closeFieldModal,
          style: {
            padding: '4px 15px',
            background: '#1890ff',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }
        }, "\u786E\u5B9A")]
      }, currentFieldInfo && React.createElement("div", null, React.createElement("p", null, React.createElement("strong", null, "\u5B57\u6BB5\u4E2D\u6587\u540D\uFF1A"), currentFieldInfo.fieldlabel || '-'), React.createElement("p", null, React.createElement("strong", null, "\u5B57\u6BB5\u6570\u636E\u5E93\u540D\uFF1A"), currentFieldInfo.fieldname || '-'), React.createElement("p", null, React.createElement("strong", null, "\u5B57\u6BB5ID\uFF1A"), currentFieldInfo.fieldid || '-'))));
    }
  }]);

  return MainFieldsPanel;
}(React.Component);

ecodeSDK.exp(MainFieldsPanel);