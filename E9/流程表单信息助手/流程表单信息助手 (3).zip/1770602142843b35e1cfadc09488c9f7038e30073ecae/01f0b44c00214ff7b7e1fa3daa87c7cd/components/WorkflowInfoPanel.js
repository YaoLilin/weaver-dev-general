const {WeaFormItem} = ecCom;

/**
 * 流程信息面板组件
 * 用于显示流程的基本信息，包括：
 * - 用户信息（f_weaver_belongto_userid）
 * - 用户类型（f_weaver_belongto_usertype）
 * - 表单ID（formid）
 * - 新表单/老表单标识（isbill）
 * - 节点ID（nodeid）
 * - 请求ID（requestid）
 * - 路径ID（workflowid）
 * 组件内部负责获取流程信息
 */
class WorkflowInfoPanel extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            workflowInfo: null // 流程信息
        };
    }

    componentDidMount() {
        this.loadWorkflowInfo();
    }

    // 加载流程信息
    loadWorkflowInfo = () => {
        try {
            const baseInfo = window.WfForm ? window.WfForm.getBaseInfo() : null;
            if (baseInfo) {
                this.setState({
                    workflowInfo: baseInfo
                });
            }
        } catch (error) {
            console.error('加载流程信息失败:', error);
        }
    }

    render() {
        const {workflowInfo} = this.state;
        
        if (!workflowInfo) {
            return <div style={{padding: '20px', textAlign: 'center', color: '#999'}}>暂无流程信息</div>;
        }

        const infoItems = [
            {label: '用户信息', key: 'f_weaver_belongto_userid'},
            {label: '用户类型', key: 'f_weaver_belongto_usertype'},
            {label: '表单ID', key: 'formid'},
            {label: '新表单/老表单', key: 'isbill'},
            {label: '节点ID', key: 'nodeid'},
            {label: '请求ID', key: 'requestid'},
            {label: '路径ID', key: 'workflowid'}
        ];

        return (
            <div style={{padding: '20px'}}>
                {infoItems.map(item => (
                    <WeaFormItem
                        key={item.key}
                        label={item.label}
                        labelCol={{span: 6}}
                        wrapperCol={{span: 18}}
                        style={{marginBottom: '16px'}}
                    >
                        <div style={{lineHeight:'30px'}}>{workflowInfo[item.key] !== undefined ? String(workflowInfo[item.key]) : '-'}</div>
                    </WeaFormItem>
                ))}
            </div>
        );
    }
}

ecodeSDK.exp(WorkflowInfoPanel);
