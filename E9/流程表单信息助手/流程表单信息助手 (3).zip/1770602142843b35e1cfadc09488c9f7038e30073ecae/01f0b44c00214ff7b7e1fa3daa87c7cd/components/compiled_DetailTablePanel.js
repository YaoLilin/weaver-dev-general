"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Input = _antd.Input,
    Icon = _antd.Icon,
    message = _antd.message;
/**
 * 明细表面板组件
 * 用于显示单个明细表的数据，包括：
 * - 明细表标题（显示明细表序号）
 * - 明细表数据表格（使用Antd Table组件）
 * - 分页功能（默认每页20条）
 * - 表格横向滚动支持
 * - 字段编辑功能（鼠标悬停显示编辑图标，点击可编辑字段值）
 * 
 * @props {String} detailIndex - 明细表索引，格式如"detail_1"、"detail_2"
 * @props {Array} columns - 表格列配置数组
 * @props {Array} dataSource - 表格数据源数组
 * @props {Number} requestId - 流程请求ID
 */

var DetailTablePanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(DetailTablePanel, _React$Component);

  function DetailTablePanel(props) {
    var _this;

    _classCallCheck(this, DetailTablePanel);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DetailTablePanel).call(this, props));

    _this.startEdit = function (fieldId, rowId, currentValue) {
      var cellKey = "".concat(fieldId, "_").concat(rowId);
      var displayValue = _this.state.cellValues[cellKey] !== undefined ? _this.state.cellValues[cellKey] : currentValue;

      _this.setState({
        editingCell: {
          fieldId: fieldId,
          rowId: rowId
        },
        editingValue: displayValue,
        hoveredCell: null
      });
    };

    _this.cancelEdit = function () {
      _this.setState({
        editingCell: null,
        editingValue: '',
        hoveredCell: null
      });
    };

    _this.saveFieldValue = async function (fieldId, fieldName, rowId) {
      var _this$props = _this.props,
          requestId = _this$props.requestId,
          detailIndex = _this$props.detailIndex;
      var _this$state = _this.state,
          editingValue = _this$state.editingValue,
          cellValues = _this$state.cellValues;

      if (!requestId) {
        message.error('无法获取请求ID');
        return;
      } // 获取明细表序号（detail_1 -> 1）


      var detailNum = detailIndex.replace('detail_', '');

      try {
        // 调用后端接口保存字段值
        var params = new URLSearchParams();
        params.append('requestId', requestId);
        params.append('detailIndex', detailNum);
        params.append('detailFieldName', fieldName);
        params.append('detailFieldValue', editingValue);
        params.append('detailRowId', rowId);
        var response = await fetch('/api/second-dev/workflow/field/detail-field/change-value', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: params.toString()
        });
        var result = await response.json(); // 检查响应状态码和结果

        if (response.ok && (result.success || result.data && result.data.changeSuccess)) {
          message.success('保存成功'); // 更新单元格值缓存

          var cellKey = "".concat(fieldId, "_").concat(rowId);

          _this.setState({
            cellValues: _objectSpread({}, cellValues, _defineProperty({}, cellKey, editingValue)),
            editingCell: null,
            editingValue: ''
          }); // 更新表单中的字段值


          var row = _this.props.dataSource.find(function (r) {
            return r.rowId === rowId;
          });

          if (row && row.key) {
            var rowKey = row.key;
            var fieldMark = "field".concat(fieldId, "_").concat(rowKey.replace('row_', ''));
            var fieldObj = window.WfForm ? window.WfForm.getFieldObj(fieldMark) : null;

            if (fieldObj) {
              fieldObj.value = editingValue;
            }
          }
        } else {
          // 处理错误情况：优先显示返回的错误信息
          var errorMsg = result.msg || result.data && result.data.msg || result.message || result.data && result.data.message || "\u4FDD\u5B58\u5931\u8D25".concat(response.status ? ' (状态码: ' + response.status + ')' : '');
          message.error(errorMsg);
        }
      } catch (error) {
        console.error('保存字段值失败:', error);
        message.error('保存字段值失败: ' + error.message);
      }
    };

    _this.handleEditingValueChange = function (e) {
      _this.setState({
        editingValue: e.target.value
      });
    };

    _this.state = {
      editingCell: null,
      // 正在编辑的单元格 {fieldId, rowId}
      editingValue: '',
      // 正在编辑的字段值
      hoveredCell: null,
      // 鼠标悬停的单元格 {fieldId, rowId}
      cellValues: {} // 单元格值缓存（用于更新显示）

    };
    return _this;
  } // 开始编辑单元格


  _createClass(DetailTablePanel, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props2 = this.props,
          detailIndex = _this$props2.detailIndex,
          columns = _this$props2.columns,
          dataSource = _this$props2.dataSource;
      var _this$state2 = this.state,
          editingCell = _this$state2.editingCell,
          editingValue = _this$state2.editingValue,
          hoveredCell = _this$state2.hoveredCell,
          cellValues = _this$state2.cellValues;
      var detailNum = detailIndex.replace('detail_', ''); // 如果没有列信息，不显示（即使没有数据也应该显示列信息）

      if (!columns || columns.length === 0) {
        return null;
      } // 确保 dataSource 是一个数组


      var safeDataSource = dataSource || []; // 构建带编辑功能的列

      var editableColumns = columns.map(function (col) {
        // 序号列不需要编辑
        if (col.key === 'index') {
          return col;
        } // 字段列添加编辑功能


        return _objectSpread({}, col, {
          render: function render(text, record) {
            var fieldData = record[col.dataIndex];
            var fieldId = col.fieldId;
            var fieldName = col.fieldName;
            var rowId = record.rowId; // 如果没有rowId，只显示值，不显示编辑功能

            if (!rowId) {
              var _displayValue = fieldData && fieldData.value ? fieldData.value : '';

              return React.createElement("span", null, _displayValue);
            }

            var cellKey = "".concat(fieldId, "_").concat(rowId);
            var isEditing = editingCell && editingCell.fieldId === fieldId && editingCell.rowId === rowId;
            var isHovered = hoveredCell && hoveredCell.fieldId === fieldId && hoveredCell.rowId === rowId && !isEditing; // 获取显示值：优先使用缓存值，其次使用字段数据值，最后为空字符串

            var displayValue = cellValues[cellKey] !== undefined ? cellValues[cellKey] : fieldData && fieldData.value !== undefined && fieldData.value !== null ? fieldData.value : '';
            return React.createElement("div", {
              style: {
                position: 'relative',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                minHeight: '22px'
              },
              onMouseEnter: function onMouseEnter() {
                return !isEditing && _this2.setState({
                  hoveredCell: {
                    fieldId: fieldId,
                    rowId: rowId
                  }
                });
              },
              onMouseLeave: function onMouseLeave() {
                return !isEditing && _this2.setState({
                  hoveredCell: null
                });
              }
            }, isEditing ? React.createElement(React.Fragment, null, React.createElement(Input, {
              value: editingValue,
              onChange: _this2.handleEditingValueChange,
              style: {
                flex: 1,
                minWidth: '100px'
              },
              autoFocus: true,
              size: "small"
            }), React.createElement(Icon, {
              type: "check",
              style: {
                cursor: 'pointer',
                color: '#52c41a',
                fontSize: '14px',
                flexShrink: 0
              },
              onClick: function onClick() {
                return _this2.saveFieldValue(fieldId, fieldName, rowId);
              },
              title: "\u4FDD\u5B58"
            }), React.createElement(Icon, {
              type: "cross",
              style: {
                cursor: 'pointer',
                color: '#f5222d',
                fontSize: '14px',
                flexShrink: 0
              },
              onClick: _this2.cancelEdit,
              title: "\u53D6\u6D88"
            })) : React.createElement(React.Fragment, null, React.createElement("span", {
              style: {
                flex: 1,
                minWidth: 0,
                minHeight: '22px',
                display: 'inline-block'
              }
            }, displayValue || "\xA0"), isHovered && React.createElement(Icon, {
              type: "edit",
              style: {
                cursor: 'pointer',
                color: '#1890ff',
                fontSize: '14px',
                flexShrink: 0,
                marginLeft: '4px'
              },
              onClick: function onClick() {
                return _this2.startEdit(fieldId, rowId, displayValue || '');
              },
              title: "\u7F16\u8F91"
            })));
          }
        });
      });
      return React.createElement("div", {
        style: {
          marginBottom: '24px'
        }
      }, React.createElement("h3", {
        style: {
          marginBottom: '12px'
        }
      }, "\u660E\u7EC6\u8868", detailNum), React.createElement(Table, {
        columns: editableColumns,
        dataSource: safeDataSource,
        pagination: {
          pageSize: 20,
          showSizeChanger: true,
          showTotal: function showTotal(total) {
            return "\u5171 ".concat(total, " \u6761");
          }
        },
        scroll: {
          x: 'max-content'
        },
        size: "small",
        locale: {
          emptyText: '暂无数据'
        }
      }));
    }
  }]);

  return DetailTablePanel;
}(React.Component);

ecodeSDK.exp(DetailTablePanel);