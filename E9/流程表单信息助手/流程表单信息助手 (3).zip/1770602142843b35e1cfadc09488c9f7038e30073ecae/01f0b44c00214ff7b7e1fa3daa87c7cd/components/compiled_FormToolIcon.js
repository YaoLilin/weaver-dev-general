"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

/**
 * 流程表单助手图标组件
 * 用于显示可拖动的流程表单助手图标，包括：
 * - 固定定位在页面右下角（可拖动到任意位置）
 * - 点击图标打开抽屉
 * - 拖拽功能（可拖动到任意位置）
 * - 位置保存（使用localStorage保存位置）
 * 
 * @props {Function} onClick - 点击图标回调函数
 */
var FormToolIcon =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FormToolIcon, _React$Component);

  function FormToolIcon(props) {
    var _this;

    _classCallCheck(this, FormToolIcon);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(FormToolIcon).call(this, props)); // 从localStorage加载保存的位置

    _this.loadIconPosition = function () {
      try {
        var saved = localStorage.getItem('formToolIconPosition');

        if (saved) {
          return JSON.parse(saved);
        }
      } catch (e) {
        console.warn('加载图标位置失败:', e);
      }

      return null;
    };

    _this.saveIconPosition = function (position) {
      try {
        localStorage.setItem('formToolIconPosition', JSON.stringify(position));
      } catch (e) {
        console.warn('保存图标位置失败:', e);
      }
    };

    _this.handleMouseDown = function (e) {
      e.preventDefault();
      e.stopPropagation();

      if (_this.iconRef.current) {
        var currentPos = _this.state.iconPosition;
        var windowWidth = window.innerWidth;
        var windowHeight = window.innerHeight; // 将当前位置转换为像素值

        var currentRight, currentBottom;

        if (typeof currentPos.right === 'number') {
          currentRight = currentPos.right;
        } else {
          // 如果是百分比或vh，转换为像素
          currentRight = 10; // 默认值
        }

        if (typeof currentPos.bottom === 'number') {
          currentBottom = currentPos.bottom;
        } else {
          // 如果是vh，转换为像素
          var vhValue = parseFloat(currentPos.bottom);
          currentBottom = windowHeight * vhValue / 100;
        }

        _this.setState({
          isDragging: true,
          hasMoved: false,
          dragStartPos: {
            x: e.clientX,
            y: e.clientY
          },
          iconStartPos: {
            right: currentRight,
            bottom: currentBottom
          }
        });
      }
    };

    _this.handleMouseMove = function (e) {
      if (!_this.state.isDragging) return;
      var _this$state = _this.state,
          dragStartPos = _this$state.dragStartPos,
          iconStartPos = _this$state.iconStartPos;
      var windowWidth = window.innerWidth;
      var windowHeight = window.innerHeight;
      var iconWidth = 50;
      var iconHeight = 50; // 计算移动距离

      var deltaX = e.clientX - dragStartPos.x;
      var deltaY = e.clientY - dragStartPos.y; // 如果移动距离超过5px，认为是拖拽而不是点击

      if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
        _this.setState({
          hasMoved: true
        });
      } // 计算新位置


      var right = iconStartPos.right - deltaX;
      var bottom = iconStartPos.bottom - deltaY; // bottom是距离底部的距离，鼠标向上移动时deltaY为负，bottom应该增加
      // 限制在窗口范围内

      right = Math.max(0, Math.min(right, windowWidth - iconWidth));
      bottom = Math.max(0, Math.min(bottom, windowHeight - iconHeight));
      var newPosition = {
        right: right,
        bottom: bottom
      };

      _this.setState({
        iconPosition: newPosition
      });

      _this.saveIconPosition(newPosition);
    };

    _this.handleMouseUp = function () {
      if (_this.state.isDragging) {
        _this.setState({
          isDragging: false,
          hasMoved: false
        });
      }
    };

    var savedPosition = _this.loadIconPosition();

    _this.state = {
      iconPosition: savedPosition || {
        right: 10,
        bottom: '20vh'
      },
      // 图标位置
      isDragging: false,
      // 是否正在拖拽
      dragStartPos: {
        x: 0,
        y: 0
      },
      // 拖拽开始时的鼠标位置
      iconStartPos: {
        right: 0,
        bottom: 0
      },
      // 拖拽开始时的图标位置
      hasMoved: false // 是否移动过（用于区分点击和拖拽）

    };
    _this.iconRef = React.createRef();
    return _this;
  }

  _createClass(FormToolIcon, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      // 绑定全局鼠标事件
      document.addEventListener('mousemove', this.handleMouseMove);
      document.addEventListener('mouseup', this.handleMouseUp);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // 清理事件监听
      document.removeEventListener('mousemove', this.handleMouseMove);
      document.removeEventListener('mouseup', this.handleMouseUp);
    } // 从localStorage加载图标位置

  }, {
    key: "render",
    value: function render() {
      var _onClick = this.props.onClick;
      var _this$state2 = this.state,
          iconPosition = _this$state2.iconPosition,
          isDragging = _this$state2.isDragging,
          hasMoved = _this$state2.hasMoved;
      return React.createElement("div", {
        ref: this.iconRef,
        title: "\u6D41\u7A0B\u8868\u5355\u52A9\u624B\uFF08\u53EF\u62D6\u52A8\uFF09",
        style: {
          position: 'fixed',
          right: typeof iconPosition.right === 'number' ? "".concat(iconPosition.right, "px") : iconPosition.right,
          bottom: typeof iconPosition.bottom === 'number' ? "".concat(iconPosition.bottom, "px") : iconPosition.bottom,
          width: '50px',
          height: '50px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: isDragging ? 'grabbing' : 'grab',
          zIndex: 1000,
          userSelect: 'none',
          WebkitUserSelect: 'none'
        },
        onMouseDown: this.handleMouseDown,
        onClick: function onClick(e) {
          // 如果刚刚拖拽过，不触发点击事件
          if (!hasMoved && _onClick) {
            _onClick(e);
          }
        }
      }, React.createElement("i", {
        className: "icon-coms-Relevant-workflow",
        style: {
          color: 'rgb(0, 121, 222)',
          fontSize: 30,
          pointerEvents: 'none'
        }
      }));
    }
  }]);

  return FormToolIcon;
}(React.Component);

ecodeSDK.exp(FormToolIcon);