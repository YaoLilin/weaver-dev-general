const {WeaFormItem, WeaInput} = ecCom;
const {Input, Icon, Modal, message} = antd;

/**
 * 主表字段信息面板组件
 * 用于显示流程表单的主表字段信息，包括：
 * - 字段搜索功能（支持中文名和数据库名搜索）
 * - 字段值显示（使用WeaInput组件）
 * - 字段显示值展示
 * - 字段定位功能（点击定位图标可定位到表单中的字段）
 * - 字段信息查看（点击感叹号图标可查看字段详细信息）
 * - 字段编辑功能（鼠标悬停显示编辑图标，点击可编辑字段值）
 * 
 * @props {Object} formInfo - 表单信息对象，包含tableInfo和maindata
 * @props {String} searchText - 搜索文本
 * @props {Function} onSearchChange - 搜索文本变化回调函数
 * @props {Function} onCloseDrawer - 关闭抽屉回调函数
 * @props {Number} requestId - 流程请求ID
 */
class MainFieldsPanel extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fieldModalVisible: false, // 字段信息 Modal 显示
            currentFieldInfo: null, // 当前显示的字段信息
            editingField: null, // 正在编辑的字段ID
            editingValue: '', // 正在编辑的字段值
            hoveredField: null, // 鼠标悬停的字段ID
            fieldValues: {} // 字段值缓存（用于更新显示）
        };
    }

    // 显示字段信息 Modal
    showFieldModal = (fieldInfo) => {
        this.setState({
            fieldModalVisible: true,
            currentFieldInfo: fieldInfo
        });
    }

    // 关闭字段信息 Modal
    closeFieldModal = () => {
        this.setState({
            fieldModalVisible: false,
            currentFieldInfo: null
        });
    }
    // 定位到表单字段
    locateField = (fieldId) => {
        try {
            // 关闭抽屉以便看到定位效果
            if (this.props.onCloseDrawer) {
                this.props.onCloseDrawer();
            }
            
            // 根据字段ID查找对应的DOM元素
            const className = `field${fieldId}_swapDiv`;
            const fieldElement = document.querySelector(`.${className}`);
            
            if (fieldElement) {
                // 滚动到该元素
                fieldElement.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'center',
                    inline: 'nearest'
                });
                
                // 添加高亮效果
                const originalStyle = {
                    outline: fieldElement.style.outline,
                    outlineOffset: fieldElement.style.outlineOffset,
                    transition: fieldElement.style.transition
                };
                
                fieldElement.style.outline = '3px solid #1890ff';
                fieldElement.style.outlineOffset = '2px';
                fieldElement.style.transition = 'outline 0.3s ease';
                
                // 3秒后移除高亮
                setTimeout(() => {
                    fieldElement.style.outline = originalStyle.outline || '';
                    fieldElement.style.outlineOffset = originalStyle.outlineOffset || '';
                    fieldElement.style.transition = originalStyle.transition || '';
                }, 3000);
            } else {
                // 如果找不到元素，尝试查找其他可能的类名
                const alternativeSelectors = [
                    `#field${fieldId}`,
                    `[id*="field${fieldId}"]`,
                    `.field${fieldId}`,
                    `[class*="field${fieldId}"]`
                ];
                
                let found = false;
                for (const selector of alternativeSelectors) {
                    const element = document.querySelector(selector);
                    if (element) {
                        element.scrollIntoView({ 
                            behavior: 'smooth', 
                            block: 'center',
                            inline: 'nearest'
                        });
                        found = true;
                        break;
                    }
                }
                
                if (!found) {
                    console.warn(`未找到字段ID为 ${fieldId} 的表单元素`);
                }
            }
        } catch (error) {
            console.error('定位字段失败:', error);
        }
    }
    // 获取字段显示值
    getFieldDisplayValue = (fieldData) => {
        if (!fieldData) return '';
        if (fieldData.specialobj && fieldData.specialobj.length > 0) {
            return fieldData.specialobj.map(item => item.name).join(', ');
        }
        return fieldData.value || '';
    }

    // 开始编辑字段
    startEdit = (field, fieldData) => {
        const currentValue = this.state.fieldValues[`field${field.fieldId}`] !== undefined 
            ? this.state.fieldValues[`field${field.fieldId}`] 
            : (fieldData.value || '');
        this.setState({
            editingField: field.fieldId,
            editingValue: currentValue,
            hoveredField: null
        });
    }

    // 取消编辑
    cancelEdit = () => {
        this.setState({
            editingField: null,
            editingValue: '',
            hoveredField: null
        });
    }

    // 保存字段值
    saveFieldValue = async (field) => {
        const {requestId} = this.props;
        const {editingValue, fieldValues} = this.state;

        if (!requestId) {
            message.error('无法获取请求ID');
            return;
        }

        try {
            // 调用后端接口保存字段值
            const params = new URLSearchParams();
            params.append('requestId', requestId);
            params.append('fieldName', field.fieldname);
            params.append('fieldValue', editingValue);

            const response = await fetch('/api/second-dev/workflow/field/main-field/change-value', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: params.toString()
            });

            const result = await response.json();

            // 检查响应状态码和结果
            if (response.ok && (result.success || (result.data && result.data.changeSuccess))) {
                message.success('保存成功');
                // 更新字段值缓存
                this.setState({
                    fieldValues: {
                        ...fieldValues,
                        [`field${field.fieldId}`]: editingValue
                    },
                    editingField: null,
                    editingValue: ''
                });
                // 更新表单中的字段值
                const fieldMark = `field${field.fieldId}`;
                const fieldObj = window.WfForm ? window.WfForm.getFieldObj(fieldMark) : null;
                if (fieldObj) {
                    fieldObj.value = editingValue;
                }
            } else {
                // 处理错误情况：优先显示返回的错误信息
                const errorMsg = result.msg || 
                               (result.data && result.data.msg) || 
                               result.message || 
                               (result.data && result.data.message) ||
                               `保存失败${response.status ? ' (状态码: ' + response.status + ')' : ''}`;
                message.error(errorMsg);
            }
        } catch (error) {
            console.error('保存字段值失败:', error);
            message.error('保存字段值失败: ' + error.message);
        }
    }

    // 编辑值变化
    handleEditingValueChange = (e) => {
        this.setState({
            editingValue: e.target.value
        });
    }

    // 渲染单个字段项
    renderFieldItem = (field, fieldData) => {
        const {editingField, editingValue, hoveredField, fieldValues} = this.state;
        const fieldKey = `field${field.fieldId}`;
        const isEditing = editingField === field.fieldId;
        const isHovered = hoveredField === field.fieldId && !isEditing;
        const displayValue = fieldValues[fieldKey] !== undefined 
            ? fieldValues[fieldKey] 
            : (fieldData.value || '');

        return (
            <WeaFormItem
                label={
                    <span title={field.fieldlabel} style={{display: 'inline-flex', alignItems: 'center',overflow:'hidden', minWidth: 0,width:'100%'}}>
                        <i  className="icon-coms02-Positioning" 
                            type="aim" 
                            style={{marginRight: '4px', cursor: 'pointer', color: '#999', fontSize: '14px', flexShrink: 0}}
                            onClick={(e) => {
                                e.stopPropagation();
                                this.locateField(field.fieldId);
                            }}
                            title="定位到字段"
                        />
                        <Icon 
                            type="exclamation-circle" 
                            style={{marginRight: '4px', cursor: 'pointer', color: '#999', fontSize: '14px', flexShrink: 0}}
                            onClick={() => this.showFieldModal(field)}
                        />
                        <span style={{
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                            flex: 1,
                            minWidth: 0
                        }}>{field.fieldlabel}</span>
                    </span>
                }
                style={{overflow:'visible'}}
                colon={false}
                labelCol={{span: 8}}
                wrapperCol={{span: 16}}
            >
                <div 
                    className='wea-form-item-wrapper' 
                    style={{display: 'flex', alignItems: 'center', gap: '8px', position: 'relative'}}
                    onMouseEnter={() => !isEditing && this.setState({hoveredField: field.fieldId})}
                    onMouseLeave={() => !isEditing && this.setState({hoveredField: null})}
                >
                    {isEditing ? (
                        <>
                            <Input
                                value={editingValue}
                                onChange={this.handleEditingValueChange}
                                style={{flex: 1,maxWidth:160}}
                                autoFocus
                            />
                            <Icon
                                type="check"
                                style={{cursor: 'pointer', color: '#52c41a', fontSize: '16px', flexShrink: 0}}
                                onClick={() => this.saveFieldValue(field)}
                                title="保存"
                            />
                            <Icon
                                type="cross"
                                style={{cursor: 'pointer', color: '#f5222d', fontSize: '16px', flexShrink: 0}}
                                onClick={this.cancelEdit}
                                title="取消"
                            />
                        </>
                    ) : (
                        <>
                            <WeaInput
                                value={displayValue}
                                viewAttr="1"
                                style={{flex: 1,maxWidth:160}}
                                textDecoration={true}
                            />
                            {isHovered && (
                                <Icon
                                    type="edit"
                                    style={{cursor: 'pointer', color: '#1890ff', fontSize: '16px', flexShrink: 0, marginLeft: '4px'}}
                                    onClick={() => this.startEdit(field, fieldData)}
                                    title="编辑"
                                />
                            )}
                            {fieldData.specialobj && fieldData.specialobj.length > 0 && (
                                <span style={{color: '#666', whiteSpace: 'nowrap'}}>
                                    显示值：{this.getFieldDisplayValue(fieldData)}
                                </span>
                            )}
                        </>
                    )}
                </div>
            </WeaFormItem>
        );
    }

    // 获取过滤后的主表字段
    getFilteredMainFields = () => {
        const {formInfo, searchText} = this.props;
        if (!formInfo || !formInfo.tableInfo || !formInfo.tableInfo.main) {
            return [];
        }

        const fieldInfoMap = formInfo.tableInfo.main.fieldinfomap || {};
        const fields = Object.keys(fieldInfoMap).map(fieldId => ({
            fieldId,
            ...fieldInfoMap[fieldId]
        }));

        if (!searchText) {
            return fields;
        }

        const searchLower = searchText.toLowerCase();
        return fields.filter(field => {
            const fieldLabel = (field.fieldlabel || '').toLowerCase();
            const fieldName = (field.fieldname || '').toLowerCase();
            return fieldLabel.includes(searchLower) || fieldName.includes(searchLower);
        });
    }

    render() {
        const {formInfo, searchText, onSearchChange} = this.props;
        const {fieldModalVisible, currentFieldInfo} = this.state;
        const fields = this.getFilteredMainFields();
        const mainData = formInfo ? formInfo.maindata : {};
        
        // 检查是否有字段数据（不考虑搜索）
        const hasFormInfo = formInfo && formInfo.tableInfo && formInfo.tableInfo.main && formInfo.tableInfo.main.fieldinfomap;

        const fieldItems = [];
        for (let i = 0; i < fields.length; i += 2) {
            const field1 = fields[i];
            const field2 = fields[i + 1];
            const field1Data = mainData[`field${field1.fieldId}`] || {};
            const field2Data = field2 ? (mainData[`field${field2.fieldId}`] || {}) : null;

            fieldItems.push(
                <div key={i} style={{display: 'flex', marginBottom: '10px'}}>
                    <div style={{width: 'calc(50% - 5px)', marginRight: '10px'}}>
                        {this.renderFieldItem(field1, field1Data)}
                    </div>
                    {field2 && (
                        <div style={{width: 'calc(50% - 5px)'}}>
                            {this.renderFieldItem(field2, field2Data)}
                        </div>
                    )}
                </div>
            );
        }

        return (
            <div>
                <div style={{marginBottom: '16px'}}>
                    <Input
                        placeholder="搜索字段（支持中文名和数据库名）"
                        value={searchText}
                        onChange={onSearchChange}
                        prefix={<Icon type="search" />}
                        allowClear
                    />
                </div>
                {!hasFormInfo ? (
                    <div style={{padding: '20px', textAlign: 'center', color: '#999'}}>暂无字段数据</div>
                ) : fieldItems.length > 0 ? (
                    <div className="wea-form-item-group">
                        {fieldItems}
                    </div>
                ) : (
                    <div style={{padding: '20px', textAlign: 'center', color: '#999'}}>暂无匹配的字段数据</div>
                )}

                {/* 字段信息 Modal */}
                <Modal
                    title="字段信息"
                    visible={fieldModalVisible}
                    onOk={this.closeFieldModal}
                    onCancel={this.closeFieldModal}
                    footer={[
                        <button key="ok" onClick={this.closeFieldModal} style={{
                            padding: '4px 15px',
                            background: '#1890ff',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer'
                        }}>确定</button>
                    ]}
                >
                    {currentFieldInfo && (
                        <div>
                            <p><strong>字段中文名：</strong>{currentFieldInfo.fieldlabel || '-'}</p>
                            <p><strong>字段数据库名：</strong>{currentFieldInfo.fieldname || '-'}</p>
                            <p><strong>字段ID：</strong>{currentFieldInfo.fieldid || '-'}</p>
                        </div>
                    )}
                </Modal>
            </div>
        );
    }
}

ecodeSDK.exp(MainFieldsPanel);
