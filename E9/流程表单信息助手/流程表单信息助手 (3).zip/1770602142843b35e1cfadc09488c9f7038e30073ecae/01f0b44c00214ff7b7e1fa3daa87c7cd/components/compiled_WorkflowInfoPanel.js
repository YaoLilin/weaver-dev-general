"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaFormItem = _ecCom.WeaFormItem;
/**
 * 流程信息面板组件
 * 用于显示流程的基本信息，包括：
 * - 用户信息（f_weaver_belongto_userid）
 * - 用户类型（f_weaver_belongto_usertype）
 * - 表单ID（formid）
 * - 新表单/老表单标识（isbill）
 * - 节点ID（nodeid）
 * - 请求ID（requestid）
 * - 路径ID（workflowid）
 * 组件内部负责获取流程信息
 */

var WorkflowInfoPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(WorkflowInfoPanel, _React$Component);

  function WorkflowInfoPanel(props) {
    var _this;

    _classCallCheck(this, WorkflowInfoPanel);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(WorkflowInfoPanel).call(this, props));

    _this.loadWorkflowInfo = function () {
      try {
        var baseInfo = window.WfForm ? window.WfForm.getBaseInfo() : null;

        if (baseInfo) {
          _this.setState({
            workflowInfo: baseInfo
          });
        }
      } catch (error) {
        console.error('加载流程信息失败:', error);
      }
    };

    _this.state = {
      workflowInfo: null // 流程信息

    };
    return _this;
  }

  _createClass(WorkflowInfoPanel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.loadWorkflowInfo();
    } // 加载流程信息

  }, {
    key: "render",
    value: function render() {
      var workflowInfo = this.state.workflowInfo;

      if (!workflowInfo) {
        return React.createElement("div", {
          style: {
            padding: '20px',
            textAlign: 'center',
            color: '#999'
          }
        }, "\u6682\u65E0\u6D41\u7A0B\u4FE1\u606F");
      }

      var infoItems = [{
        label: '用户信息',
        key: 'f_weaver_belongto_userid'
      }, {
        label: '用户类型',
        key: 'f_weaver_belongto_usertype'
      }, {
        label: '表单ID',
        key: 'formid'
      }, {
        label: '新表单/老表单',
        key: 'isbill'
      }, {
        label: '节点ID',
        key: 'nodeid'
      }, {
        label: '请求ID',
        key: 'requestid'
      }, {
        label: '路径ID',
        key: 'workflowid'
      }];
      return React.createElement("div", {
        style: {
          padding: '20px'
        }
      }, infoItems.map(function (item) {
        return React.createElement(WeaFormItem, {
          key: item.key,
          label: item.label,
          labelCol: {
            span: 6
          },
          wrapperCol: {
            span: 18
          },
          style: {
            marginBottom: '16px'
          }
        }, React.createElement("div", {
          style: {
            lineHeight: '30px'
          }
        }, workflowInfo[item.key] !== undefined ? String(workflowInfo[item.key]) : '-'));
      }));
    }
  }]);

  return WorkflowInfoPanel;
}(React.Component);

ecodeSDK.exp(WorkflowInfoPanel);