"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Input = _antd.Input,
    Icon = _antd.Icon,
    message = _antd.message;
/**
 * 流程节点信息面板组件
 * 用于显示当前流程的所有节点信息，包括：
 * - 节点ID
 * - 节点名称
 * - 搜索功能（支持节点ID和节点名称搜索）
 * 
 * 组件内部负责获取流程节点信息
 */

var WorkflowNodesPanel =
/*#__PURE__*/
function (_React$Component) {
  _inherits(WorkflowNodesPanel, _React$Component);

  function WorkflowNodesPanel(props) {
    var _this;

    _classCallCheck(this, WorkflowNodesPanel);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(WorkflowNodesPanel).call(this, props));

    _this.loadWorkflowNodes = async function () {
      try {
        // 获取流程ID
        var baseInfo = window.WfForm ? window.WfForm.getBaseInfo() : null;

        if (!baseInfo || !baseInfo.workflowid) {
          message.warning('无法获取流程ID');
          return;
        }

        _this.setState({
          loading: true
        }); // 调用后端接口获取节点信息


        var response = await fetch("/api/second-dev/workflow/info/nodes?workflowId=".concat(baseInfo.workflowid), {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          var errorData = await response.json().catch(function () {
            return {};
          });
          var errorMsg = errorData.msg || errorData.message || "\u83B7\u53D6\u8282\u70B9\u4FE1\u606F\u5931\u8D25 (\u72B6\u6001\u7801: ".concat(response.status, ")");
          message.error(errorMsg);

          _this.setState({
            loading: false
          });

          return;
        }

        var nodeList = await response.json();

        _this.setState({
          nodes: nodeList || [],
          loading: false
        });
      } catch (error) {
        console.error('加载流程节点信息失败:', error);
        message.error('加载流程节点信息失败: ' + error.message);

        _this.setState({
          loading: false
        });
      }
    };

    _this.handleSearchChange = function (e) {
      _this.setState({
        searchText: e.target.value
      });
    };

    _this.getFilteredNodes = function () {
      var _this$state = _this.state,
          nodes = _this$state.nodes,
          searchText = _this$state.searchText;

      if (!searchText) {
        return nodes;
      }

      var searchLower = searchText.toLowerCase();
      return nodes.filter(function (node) {
        var nodeId = node.nodeId ? String(node.nodeId) : '';
        var nodeName = node.nodeName || '';
        return nodeId.includes(searchLower) || nodeName.toLowerCase().includes(searchLower);
      });
    };

    _this.state = {
      nodes: [],
      // 节点列表
      searchText: '',
      // 搜索文本
      loading: false // 加载状态

    };
    return _this;
  }

  _createClass(WorkflowNodesPanel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.loadWorkflowNodes();
    } // 加载流程节点信息

  }, {
    key: "render",
    value: function render() {
      var _this$state2 = this.state,
          searchText = _this$state2.searchText,
          loading = _this$state2.loading;
      var filteredNodes = this.getFilteredNodes();
      var columns = [{
        title: '节点ID',
        dataIndex: 'nodeId',
        key: 'nodeId',
        width: 120
      }, {
        title: '节点名称',
        dataIndex: 'nodeName',
        key: 'nodeName'
      }];
      var dataSource = filteredNodes.map(function (node, index) {
        return {
          key: index,
          nodeId: node.nodeId || '-',
          nodeName: node.nodeName || '-'
        };
      });
      return React.createElement("div", {
        style: {
          padding: '16px',
          overflow: 'auto',
          height: '100%'
        }
      }, React.createElement("div", {
        style: {
          marginBottom: '16px'
        }
      }, React.createElement(Input, {
        placeholder: "\u641C\u7D22\u8282\u70B9\uFF08\u652F\u6301\u8282\u70B9ID\u548C\u8282\u70B9\u540D\u79F0\uFF09",
        value: searchText,
        onChange: this.handleSearchChange,
        prefix: React.createElement(Icon, {
          type: "search"
        }),
        allowClear: true
      })), React.createElement(Table, {
        columns: columns,
        dataSource: dataSource,
        loading: loading,
        pagination: {
          pageSize: 20,
          showSizeChanger: true,
          showTotal: function showTotal(total) {
            return "\u5171 ".concat(total, " \u6761");
          }
        },
        scroll: {
          x: 'max-content'
        },
        size: "small",
        locale: {
          emptyText: filteredNodes.length === 0 && searchText ? '暂无匹配的节点数据' : '暂无节点数据'
        }
      }));
    }
  }]);

  return WorkflowNodesPanel;
}(React.Component);

ecodeSDK.exp(WorkflowNodesPanel);