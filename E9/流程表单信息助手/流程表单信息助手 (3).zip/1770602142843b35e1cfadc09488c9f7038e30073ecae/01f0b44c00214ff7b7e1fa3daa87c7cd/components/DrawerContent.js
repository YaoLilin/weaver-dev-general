const {Tabs} = antd;
const {TabPane} = Tabs;
const FormFieldsInfoTab = ecodeSDK.imp(FormFieldsInfoTab);
const WorkflowInfoPanel = ecodeSDK.imp(WorkflowInfoPanel);
const WorkflowNodesPanel = ecodeSDK.imp(WorkflowNodesPanel);
const AboutPanel = ecodeSDK.imp(AboutPanel);

/**
 * 抽屉内容组件
 * 作为流程表单助手抽屉的主要内容容器，包含四个标签页：
 * 1. 表单字段信息标签页（FormFieldsInfoTab组件）
 * 2. 流程信息标签页（WorkflowInfoPanel组件）
 * 3. 流程节点信息标签页（WorkflowNodesPanel组件）
 * 4. 关于标签页（AboutPanel组件）
 * 
 * @props {Function} onCloseDrawer - 关闭抽屉回调函数
 */
class DrawerContent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            activeTab: '1' // 当前激活的标签页
        };
    }

    // 切换标签页
    handleTabChange = (key) => {
        this.setState({ activeTab: key });
    }

    render() {
        const { onCloseDrawer } = this.props;
        const { activeTab } = this.state;

        return (
            <div style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
                <Tabs
                    activeKey={activeTab}
                    onChange={this.handleTabChange}
                    style={{flex: 1, overflow: 'auto'}}
                >
                    <TabPane tab="表单字段信息" key="1">
                        <FormFieldsInfoTab
                            onCloseDrawer={onCloseDrawer}
                        />
                    </TabPane>
                    <TabPane tab="流程信息" key="2">
                        <div style={{overflow: 'auto', height: '100%'}}>
                            <WorkflowInfoPanel />
                        </div>
                    </TabPane>
                    <TabPane tab="流程节点" key="3">
                        <div style={{overflow: 'auto', height: '100%'}}>
                            <WorkflowNodesPanel />
                        </div>
                    </TabPane>
                    <TabPane tab="关于" key="4">
                        <div style={{overflow: 'auto', height: '100%'}}>
                            <AboutPanel />
                        </div>
                    </TabPane>
                </Tabs>
            </div>
        );
    }
}

ecodeSDK.exp(DrawerContent);
