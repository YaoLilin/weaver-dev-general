const {Table, Input, Icon, message} = antd;

/**
 * 明细表面板组件
 * 用于显示单个明细表的数据，包括：
 * - 明细表标题（显示明细表序号）
 * - 明细表数据表格（使用Antd Table组件）
 * - 分页功能（默认每页20条）
 * - 表格横向滚动支持
 * - 字段编辑功能（鼠标悬停显示编辑图标，点击可编辑字段值）
 * 
 * @props {String} detailIndex - 明细表索引，格式如"detail_1"、"detail_2"
 * @props {Array} columns - 表格列配置数组
 * @props {Array} dataSource - 表格数据源数组
 * @props {Number} requestId - 流程请求ID
 */
class DetailTablePanel extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            editingCell: null, // 正在编辑的单元格 {fieldId, rowId}
            editingValue: '', // 正在编辑的字段值
            hoveredCell: null, // 鼠标悬停的单元格 {fieldId, rowId}
            cellValues: {} // 单元格值缓存（用于更新显示）
        };
    }

    // 开始编辑单元格
    startEdit = (fieldId, rowId, currentValue) => {
        const cellKey = `${fieldId}_${rowId}`;
        const displayValue = this.state.cellValues[cellKey] !== undefined 
            ? this.state.cellValues[cellKey] 
            : currentValue;
        this.setState({
            editingCell: {fieldId, rowId},
            editingValue: displayValue,
            hoveredCell: null
        });
    }

    // 取消编辑
    cancelEdit = () => {
        this.setState({
            editingCell: null,
            editingValue: '',
            hoveredCell: null
        });
    }

    // 保存字段值
    saveFieldValue = async (fieldId, fieldName, rowId) => {
        const {requestId, detailIndex} = this.props;
        const {editingValue, cellValues} = this.state;

        if (!requestId) {
            message.error('无法获取请求ID');
            return;
        }

        // 获取明细表序号（detail_1 -> 1）
        const detailNum = detailIndex.replace('detail_', '');

        try {
            // 调用后端接口保存字段值
            const params = new URLSearchParams();
            params.append('requestId', requestId);
            params.append('detailIndex', detailNum);
            params.append('detailFieldName', fieldName);
            params.append('detailFieldValue', editingValue);
            params.append('detailRowId', rowId);

            const response = await fetch('/api/second-dev/workflow/field/detail-field/change-value', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: params.toString()
            });

            const result = await response.json();

            // 检查响应状态码和结果
            if (response.ok && (result.success || (result.data && result.data.changeSuccess))) {
                message.success('保存成功');
                // 更新单元格值缓存
                const cellKey = `${fieldId}_${rowId}`;
                this.setState({
                    cellValues: {
                        ...cellValues,
                        [cellKey]: editingValue
                    },
                    editingCell: null,
                    editingValue: ''
                });
                // 更新表单中的字段值
                const row = this.props.dataSource.find(r => r.rowId === rowId);
                if (row && row.key) {
                    const rowKey = row.key;
                    const fieldMark = `field${fieldId}_${rowKey.replace('row_', '')}`;
                    const fieldObj = window.WfForm ? window.WfForm.getFieldObj(fieldMark) : null;
                    if (fieldObj) {
                        fieldObj.value = editingValue;
                    }
                }
            } else {
                // 处理错误情况：优先显示返回的错误信息
                const errorMsg = result.msg || 
                               (result.data && result.data.msg) || 
                               result.message || 
                               (result.data && result.data.message) ||
                               `保存失败${response.status ? ' (状态码: ' + response.status + ')' : ''}`;
                message.error(errorMsg);
            }
        } catch (error) {
            console.error('保存字段值失败:', error);
            message.error('保存字段值失败: ' + error.message);
        }
    }

    // 编辑值变化
    handleEditingValueChange = (e) => {
        this.setState({
            editingValue: e.target.value
        });
    }

    render() {
        const {detailIndex, columns, dataSource} = this.props;
        const {editingCell, editingValue, hoveredCell, cellValues} = this.state;
        const detailNum = detailIndex.replace('detail_', '');

        // 如果没有列信息，不显示（即使没有数据也应该显示列信息）
        if (!columns || columns.length === 0) {
            return null;
        }
        
        // 确保 dataSource 是一个数组
        const safeDataSource = dataSource || [];

        // 构建带编辑功能的列
        const editableColumns = columns.map(col => {
            // 序号列不需要编辑
            if (col.key === 'index') {
                return col;
            }

            // 字段列添加编辑功能
            return {
                ...col,
                render: (text, record) => {
                    const fieldData = record[col.dataIndex];
                    const fieldId = col.fieldId;
                    const fieldName = col.fieldName;
                    const rowId = record.rowId;
                    
                    // 如果没有rowId，只显示值，不显示编辑功能
                    if (!rowId) {
                        const displayValue = fieldData && fieldData.value ? fieldData.value : '';
                        return <span>{displayValue}</span>;
                    }

                    const cellKey = `${fieldId}_${rowId}`;
                    const isEditing = editingCell && editingCell.fieldId === fieldId && editingCell.rowId === rowId;
                    const isHovered = hoveredCell && hoveredCell.fieldId === fieldId && hoveredCell.rowId === rowId && !isEditing;
                    // 获取显示值：优先使用缓存值，其次使用字段数据值，最后为空字符串
                    const displayValue = cellValues[cellKey] !== undefined 
                        ? cellValues[cellKey] 
                        : (fieldData && fieldData.value !== undefined && fieldData.value !== null ? fieldData.value : '');

                    return (
                        <div
                            style={{position: 'relative', display: 'flex', alignItems: 'center', gap: '4px', minHeight: '22px'}}
                            onMouseEnter={() => !isEditing && this.setState({hoveredCell: {fieldId, rowId}})}
                            onMouseLeave={() => !isEditing && this.setState({hoveredCell: null})}
                        >
                            {isEditing ? (
                                <>
                                    <Input
                                        value={editingValue}
                                        onChange={this.handleEditingValueChange}
                                        style={{flex: 1, minWidth: '100px'}}
                                        autoFocus
                                        size="small"
                                    />
                                    <Icon
                                        type="check"
                                        style={{cursor: 'pointer', color: '#52c41a', fontSize: '14px', flexShrink: 0}}
                                        onClick={() => this.saveFieldValue(fieldId, fieldName, rowId)}
                                        title="保存"
                                    />
                                    <Icon
                                        type="cross"
                                        style={{cursor: 'pointer', color: '#f5222d', fontSize: '14px', flexShrink: 0}}
                                        onClick={this.cancelEdit}
                                        title="取消"
                                    />
                                </>
                            ) : (
                                <>
                                    <span style={{flex: 1, minWidth: 0, minHeight: '22px', display: 'inline-block'}}>
                                        {displayValue || '\u00A0'}
                                    </span>
                                    {isHovered && (
                                        <Icon
                                            type="edit"
                                            style={{cursor: 'pointer', color: '#1890ff', fontSize: '14px', flexShrink: 0, marginLeft: '4px'}}
                                            onClick={() => this.startEdit(fieldId, rowId, displayValue || '')}
                                            title="编辑"
                                        />
                                    )}
                                </>
                            )}
                        </div>
                    );
                }
            };
        });

        return (
            <div style={{marginBottom: '24px'}}>
                <h3 style={{marginBottom: '12px'}}>明细表{detailNum}</h3>
                <Table
                    columns={editableColumns}
                    dataSource={safeDataSource}
                    pagination={{
                        pageSize: 20,
                        showSizeChanger: true,
                        showTotal: (total) => `共 ${total} 条`
                    }}
                    scroll={{x: 'max-content'}}
                    size="small"
                    locale={{
                        emptyText: '暂无数据'
                    }}
                />
            </div>
        );
    }
}

ecodeSDK.exp(DetailTablePanel);
