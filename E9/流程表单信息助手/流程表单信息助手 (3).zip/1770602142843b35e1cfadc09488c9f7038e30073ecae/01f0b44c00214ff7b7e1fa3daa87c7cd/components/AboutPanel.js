const {WeaFormItem} = ecCom;

/**
 * 关于面板组件
 * 用于显示关于信息，包括：
 * - ecode 应用ID
 */
class AboutPanel extends React.Component {

    render() {
        return (
            <div style={{padding: '20px'}}>
                <WeaFormItem
                    label="ecode 应用id"
                    labelCol={{span: 6}}
                    wrapperCol={{span: 18}}
                    style={{marginBottom: '16px'}}
                >
                    <div style={{lineHeight: '30px'}}>{'${appId}'}</div>
                </WeaFormItem>
            </div>
        );
    }
}

ecodeSDK.exp(AboutPanel);
