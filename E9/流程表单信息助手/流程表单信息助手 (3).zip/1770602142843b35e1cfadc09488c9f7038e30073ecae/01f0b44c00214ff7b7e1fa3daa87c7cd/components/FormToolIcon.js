/**
 * 流程表单助手图标组件
 * 用于显示可拖动的流程表单助手图标，包括：
 * - 固定定位在页面右下角（可拖动到任意位置）
 * - 点击图标打开抽屉
 * - 拖拽功能（可拖动到任意位置）
 * - 位置保存（使用localStorage保存位置）
 * 
 * @props {Function} onClick - 点击图标回调函数
 */
class FormToolIcon extends React.Component {
    constructor(props) {
        super(props);
        // 从localStorage加载保存的位置
        const savedPosition = this.loadIconPosition();
        this.state = {
            iconPosition: savedPosition || { right: 10, bottom: '20vh' }, // 图标位置
            isDragging: false, // 是否正在拖拽
            dragStartPos: { x: 0, y: 0 }, // 拖拽开始时的鼠标位置
            iconStartPos: { right: 0, bottom: 0 }, // 拖拽开始时的图标位置
            hasMoved: false // 是否移动过（用于区分点击和拖拽）
        };
        this.iconRef = React.createRef();
    }

    componentDidMount() {
        // 绑定全局鼠标事件
        document.addEventListener('mousemove', this.handleMouseMove);
        document.addEventListener('mouseup', this.handleMouseUp);
    }

    componentWillUnmount() {
        // 清理事件监听
        document.removeEventListener('mousemove', this.handleMouseMove);
        document.removeEventListener('mouseup', this.handleMouseUp);
    }

    // 从localStorage加载图标位置
    loadIconPosition = () => {
        try {
            const saved = localStorage.getItem('formToolIconPosition');
            if (saved) {
                return JSON.parse(saved);
            }
        } catch (e) {
            console.warn('加载图标位置失败:', e);
        }
        return null;
    }

    // 保存图标位置到localStorage
    saveIconPosition = (position) => {
        try {
            localStorage.setItem('formToolIconPosition', JSON.stringify(position));
        } catch (e) {
            console.warn('保存图标位置失败:', e);
        }
    }

    // 处理鼠标按下事件（开始拖拽）
    handleMouseDown = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (this.iconRef.current) {
            const currentPos = this.state.iconPosition;
            const windowWidth = window.innerWidth;
            const windowHeight = window.innerHeight;
            
            // 将当前位置转换为像素值
            let currentRight, currentBottom;
            if (typeof currentPos.right === 'number') {
                currentRight = currentPos.right;
            } else {
                // 如果是百分比或vh，转换为像素
                currentRight = 10; // 默认值
            }
            
            if (typeof currentPos.bottom === 'number') {
                currentBottom = currentPos.bottom;
            } else {
                // 如果是vh，转换为像素
                const vhValue = parseFloat(currentPos.bottom);
                currentBottom = (windowHeight * vhValue) / 100;
            }
            
            this.setState({
                isDragging: true,
                hasMoved: false,
                dragStartPos: { x: e.clientX, y: e.clientY },
                iconStartPos: { right: currentRight, bottom: currentBottom }
            });
        }
    }

    // 处理鼠标移动事件（拖拽中）
    handleMouseMove = (e) => {
        if (!this.state.isDragging) return;
        
        const { dragStartPos, iconStartPos } = this.state;
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        const iconWidth = 50;
        const iconHeight = 50;
        
        // 计算移动距离
        const deltaX = e.clientX - dragStartPos.x;
        const deltaY = e.clientY - dragStartPos.y;
        
        // 如果移动距离超过5px，认为是拖拽而不是点击
        if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
            this.setState({ hasMoved: true });
        }
        
        // 计算新位置
        let right = iconStartPos.right - deltaX;
        let bottom = iconStartPos.bottom - deltaY; // bottom是距离底部的距离，鼠标向上移动时deltaY为负，bottom应该增加
        
        // 限制在窗口范围内
        right = Math.max(0, Math.min(right, windowWidth - iconWidth));
        bottom = Math.max(0, Math.min(bottom, windowHeight - iconHeight));
        
        const newPosition = { right, bottom };
        this.setState({ iconPosition: newPosition });
        this.saveIconPosition(newPosition);
    }

    // 处理鼠标释放事件（结束拖拽）
    handleMouseUp = () => {
        if (this.state.isDragging) {
            this.setState({ 
                isDragging: false,
                hasMoved: false
            });
        }
    }

    render() {
        const { onClick } = this.props;
        const { iconPosition, isDragging, hasMoved } = this.state;

        return (
            <div
                ref={this.iconRef}
                title="流程表单助手（可拖动）"
                style={{
                    position: 'fixed',
                    right: typeof iconPosition.right === 'number' ? `${iconPosition.right}px` : iconPosition.right,
                    bottom: typeof iconPosition.bottom === 'number' ? `${iconPosition.bottom}px` : iconPosition.bottom,
                    width: '50px',
                    height: '50px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: isDragging ? 'grabbing' : 'grab',
                    zIndex: 1000,
                    userSelect: 'none',
                    WebkitUserSelect: 'none'
                }}
                onMouseDown={this.handleMouseDown}
                onClick={(e) => {
                    // 如果刚刚拖拽过，不触发点击事件
                    if (!hasMoved && onClick) {
                        onClick(e);
                    }
                }}
            >
                <i className="icon-coms-Relevant-workflow" style={{color:'rgb(0, 121, 222)',fontSize:30, pointerEvents: 'none'}} />
            </div>
        );
    }
}

ecodeSDK.exp(FormToolIcon);
