const {toJS} = mobx;
const MainFieldsPanel = ecodeSDK.imp(MainFieldsPanel);
const DetailTablePanel = ecodeSDK.imp(DetailTablePanel);

/**
 * 表单字段信息标签页组件
 * 用于显示流程表单的主表和明细表字段信息，包括：
 * - 主表字段信息（MainFieldsPanel组件）
 * - 明细表字段信息（多个DetailTablePanel组件）
 * 组件内部负责获取表单数据和明细数据
 * 
 * @props {Function} onCloseDrawer - 关闭抽屉回调函数
 */
class FormFieldsInfoTab extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            formInfo: null, // 表单信息
            detailData: null, // 明细数据
            detailTableData: {}, // 明细表数据（用于 Table 显示）
            detailTableColumns: {}, // 明细表列配置
            searchText: '', // 搜索文本
            requestId: null // 请求ID
        };
    }

    componentDidMount() {
        this.loadFormData();
        this.loadRequestId();
    }

    // 获取请求ID
    loadRequestId = () => {
        try {
            const baseInfo = window.WfForm ? window.WfForm.getBaseInfo() : null;
            if (baseInfo && baseInfo.requestid) {
                this.setState({
                    requestId: baseInfo.requestid
                });
            }
        } catch (error) {
            console.error('获取请求ID失败:', error);
        }
    }

    // 加载表单数据
    loadFormData = () => {
        try {
            const layoutStore = window.WfForm ? window.WfForm.getLayoutStore() : null;
            const globalStore = window.WfForm ? window.WfForm.getGlobalStore() : null;
            
            if (!layoutStore || !globalStore) {
                return;
            }

            // 获取主表字段信息
            const fieldAttrMap = layoutStore.fieldAttrMap || new Map();
            const mainFieldInfoMap = {};
            const mainData = {};

            // 遍历字段属性映射，获取主表字段
            fieldAttrMap.forEach((fieldInfo, fieldId) => {
                if (fieldInfo && !fieldInfo.isdetail) {
                    // 构建字段信息对象
                    mainFieldInfoMap[fieldId] = {
                        fieldid: fieldId,
                        fieldname: fieldInfo.fieldname || '',
                        fieldlabel: fieldInfo.fieldlabel || '',
                        detailtype: fieldInfo.detailtype || 0,
                        htmltype: fieldInfo.htmltype || 0,
                        selectattr: fieldInfo.selectattr || null
                    };

                    // 获取字段值
                    const fieldMark = `field${fieldId}`;
                    const fieldObj = window.WfForm ? window.WfForm.getFieldObj(fieldMark) : null;
                    if (fieldObj) {
                        mainData[fieldMark] = {
                            value: fieldObj.value || '',
                            specialobj: fieldObj.specialobj || []
                        };
                    }
                }
            });

            // 获取明细表信息
            const detailMap = layoutStore.detailMap || new Map();
            const tableInfo = {
                main: {
                    fieldinfomap: mainFieldInfoMap
                }
            };
            const detailDataObj = {};

            // 遍历明细表
            detailMap.forEach((detailObj, detailMark) => {
                if (detailMark && detailMark.startsWith('detail_')) {
                    const detailIndex = detailMark;
                    const detailFieldInfoMap = {};
                    const rowDatas = {};

                    // 获取明细字段信息
                    fieldAttrMap.forEach((fieldInfo, fieldId) => {
                        if (fieldInfo && fieldInfo.isdetail && fieldInfo.tableMark === detailMark) {
                            detailFieldInfoMap[fieldId] = {
                                fieldid: fieldId,
                                fieldname: fieldInfo.fieldname || '',
                                fieldlabel: fieldInfo.fieldlabel || '',
                                detailtype: fieldInfo.detailtype || 0,
                                htmltype: fieldInfo.htmltype || 0
                            };
                        }
                    });

                    tableInfo[detailIndex] = {
                        fieldinfomap: detailFieldInfoMap
                    };

                    // 获取明细行数据
                    if (detailObj && detailObj.rowInfo) {
                        detailObj.rowInfo.forEach((rowAttr, rowKey) => {
                            if (rowKey.startsWith('row_')) {
                                const rowData = {};
                                Object.keys(detailFieldInfoMap).forEach(fieldId => {
                                    const fieldMark = `${rowKey}.field${fieldId}`;
                                    const fieldObj = window.WfForm ? window.WfForm.getFieldObj(`field${fieldId}_${rowKey.replace('row_', '')}`) : null;
                                    if (fieldObj) {
                                        rowData[`field${fieldId}`] = {
                                            value: fieldObj.value || '',
                                            specialobj: fieldObj.specialobj || []
                                        };
                                    } else {
                                        rowData[`field${fieldId}`] = {
                                            value: '',
                                            specialobj: []
                                        };
                                    }
                                });
                                if (rowAttr && rowAttr.has && rowAttr.has('keyid')) {
                                    rowData.keyid = rowAttr.get('keyid');
                                }
                                rowDatas[rowKey] = rowData;
                            }
                        });
                    }

                    detailDataObj[detailIndex] = {
                        rowDatas: rowDatas,
                        addRowDefValue: {}
                    };

                    // 构建明细表 Table 数据
                    this.buildDetailTableData(detailIndex, detailFieldInfoMap, rowDatas);
                }
            });

            this.setState({
                formInfo: {
                    tableInfo: tableInfo,
                    maindata: mainData
                },
                detailData: detailDataObj
            });
        } catch (error) {
            console.error('加载表单数据失败:', error);
        }
    }

    // 构建明细表 Table 数据
    buildDetailTableData = (detailIndex, fieldInfoMap, rowDatas) => {
        const columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index',
            width: 60,
            fixed: 'left'
        }];

        // 添加字段列
        Object.keys(fieldInfoMap).forEach(fieldId => {
            const fieldInfo = fieldInfoMap[fieldId];
            columns.push({
                title: `${fieldInfo.fieldlabel}(${fieldInfo.fieldname})`,
                dataIndex: `field${fieldId}`,
                key: `field${fieldId}`,
                fieldId: fieldId,
                fieldName: fieldInfo.fieldname,
                fieldLabel: fieldInfo.fieldlabel,
                render: (text, record) => {
                    const fieldData = record[`field${fieldId}`];
                    if (fieldData) {
                        return fieldData.value || '';
                    }
                    return '';
                }
            });
        });

        // 转换行数据为 Table 格式
        const dataSource = [];
        let index = 1;
        Object.keys(rowDatas).sort().forEach(rowKey => {
            const rowData = rowDatas[rowKey];
            const tableRow = {
                key: rowKey,
                index: index++,
                rowId: rowData.keyid // 保存行ID
            };
            Object.keys(rowData).forEach(key => {
                if (key !== 'keyid') {
                    tableRow[key] = rowData[key];
                }
            });
            dataSource.push(tableRow);
        });

        this.setState(prevState => ({
            detailTableData: {
                ...prevState.detailTableData,
                [detailIndex]: dataSource
            },
            detailTableColumns: {
                ...prevState.detailTableColumns,
                [detailIndex]: columns
            }
        }));
    }

    // 搜索文本变化
    handleSearchChange = (e) => {
        this.setState({ searchText: e.target.value });
    }

    render() {
        const { onCloseDrawer } = this.props;
        const { formInfo, detailData, detailTableData, detailTableColumns, searchText, requestId } = this.state;

        return (
            <div style={{padding: '16px', overflow: 'auto', height: '100%'}}>
                <MainFieldsPanel
                    formInfo={formInfo}
                    searchText={searchText}
                    onSearchChange={this.handleSearchChange}
                    onCloseDrawer={onCloseDrawer}
                    requestId={requestId}
                />
                <div style={{marginTop: '24px'}}>
                    <h3>明细表字段</h3>
                    {!detailData || Object.keys(detailData).length === 0 ? (
                        <div style={{padding: '20px', textAlign: 'center', color: '#999'}}>暂无明细数据</div>
                    ) : (
                        Object.keys(detailData).sort().map(detailIdx => {
                            const columns = detailTableColumns[detailIdx] || [];
                            const dataSource = detailTableData[detailIdx] || [];
                            return (
                                <DetailTablePanel
                                    key={detailIdx}
                                    detailIndex={detailIdx}
                                    columns={columns}
                                    dataSource={dataSource}
                                    requestId={requestId}
                                />
                            );
                        })
                    )}
                </div>
            </div>
        );
    }
}

ecodeSDK.exp(FormFieldsInfoTab);
