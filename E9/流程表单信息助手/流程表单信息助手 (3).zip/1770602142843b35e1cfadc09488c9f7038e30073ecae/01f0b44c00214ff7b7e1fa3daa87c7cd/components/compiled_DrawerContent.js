"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Tabs = _antd.Tabs;
var TabPane = Tabs.TabPane;
var FormFieldsInfoTab = ecodeSDK.imp(FormFieldsInfoTab);
var WorkflowInfoPanel = ecodeSDK.imp(WorkflowInfoPanel);
var WorkflowNodesPanel = ecodeSDK.imp(WorkflowNodesPanel);
var AboutPanel = ecodeSDK.imp(AboutPanel);
/**
 * 抽屉内容组件
 * 作为流程表单助手抽屉的主要内容容器，包含四个标签页：
 * 1. 表单字段信息标签页（FormFieldsInfoTab组件）
 * 2. 流程信息标签页（WorkflowInfoPanel组件）
 * 3. 流程节点信息标签页（WorkflowNodesPanel组件）
 * 4. 关于标签页（AboutPanel组件）
 * 
 * @props {Function} onCloseDrawer - 关闭抽屉回调函数
 */

var DrawerContent =
/*#__PURE__*/
function (_React$Component) {
  _inherits(DrawerContent, _React$Component);

  function DrawerContent(props) {
    var _this;

    _classCallCheck(this, DrawerContent);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(DrawerContent).call(this, props));

    _this.handleTabChange = function (key) {
      _this.setState({
        activeTab: key
      });
    };

    _this.state = {
      activeTab: '1' // 当前激活的标签页

    };
    return _this;
  } // 切换标签页


  _createClass(DrawerContent, [{
    key: "render",
    value: function render() {
      var onCloseDrawer = this.props.onCloseDrawer;
      var activeTab = this.state.activeTab;
      return React.createElement("div", {
        style: {
          height: '100%',
          display: 'flex',
          flexDirection: 'column'
        }
      }, React.createElement(Tabs, {
        activeKey: activeTab,
        onChange: this.handleTabChange,
        style: {
          flex: 1,
          overflow: 'auto'
        }
      }, React.createElement(TabPane, {
        tab: "\u8868\u5355\u5B57\u6BB5\u4FE1\u606F",
        key: "1"
      }, React.createElement(FormFieldsInfoTab, {
        onCloseDrawer: onCloseDrawer
      })), React.createElement(TabPane, {
        tab: "\u6D41\u7A0B\u4FE1\u606F",
        key: "2"
      }, React.createElement("div", {
        style: {
          overflow: 'auto',
          height: '100%'
        }
      }, React.createElement(WorkflowInfoPanel, null))), React.createElement(TabPane, {
        tab: "\u6D41\u7A0B\u8282\u70B9",
        key: "3"
      }, React.createElement("div", {
        style: {
          overflow: 'auto',
          height: '100%'
        }
      }, React.createElement(WorkflowNodesPanel, null))), React.createElement(TabPane, {
        tab: "\u5173\u4E8E",
        key: "4"
      }, React.createElement("div", {
        style: {
          overflow: 'auto',
          height: '100%'
        }
      }, React.createElement(AboutPanel, null)))));
    }
  }]);

  return DrawerContent;
}(React.Component);

ecodeSDK.exp(DrawerContent);