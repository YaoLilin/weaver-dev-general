"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _mobx = mobx,
    toJS = _mobx.toJS;
var MainFieldsPanel = ecodeSDK.imp(MainFieldsPanel);
var DetailTablePanel = ecodeSDK.imp(DetailTablePanel);
/**
 * 表单字段信息标签页组件
 * 用于显示流程表单的主表和明细表字段信息，包括：
 * - 主表字段信息（MainFieldsPanel组件）
 * - 明细表字段信息（多个DetailTablePanel组件）
 * 组件内部负责获取表单数据和明细数据
 * 
 * @props {Function} onCloseDrawer - 关闭抽屉回调函数
 */

var FormFieldsInfoTab =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FormFieldsInfoTab, _React$Component);

  function FormFieldsInfoTab(props) {
    var _this;

    _classCallCheck(this, FormFieldsInfoTab);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(FormFieldsInfoTab).call(this, props));

    _this.loadRequestId = function () {
      try {
        var baseInfo = window.WfForm ? window.WfForm.getBaseInfo() : null;

        if (baseInfo && baseInfo.requestid) {
          _this.setState({
            requestId: baseInfo.requestid
          });
        }
      } catch (error) {
        console.error('获取请求ID失败:', error);
      }
    };

    _this.loadFormData = function () {
      try {
        var layoutStore = window.WfForm ? window.WfForm.getLayoutStore() : null;
        var globalStore = window.WfForm ? window.WfForm.getGlobalStore() : null;

        if (!layoutStore || !globalStore) {
          return;
        } // 获取主表字段信息


        var fieldAttrMap = layoutStore.fieldAttrMap || new Map();
        var mainFieldInfoMap = {};
        var mainData = {}; // 遍历字段属性映射，获取主表字段

        fieldAttrMap.forEach(function (fieldInfo, fieldId) {
          if (fieldInfo && !fieldInfo.isdetail) {
            // 构建字段信息对象
            mainFieldInfoMap[fieldId] = {
              fieldid: fieldId,
              fieldname: fieldInfo.fieldname || '',
              fieldlabel: fieldInfo.fieldlabel || '',
              detailtype: fieldInfo.detailtype || 0,
              htmltype: fieldInfo.htmltype || 0,
              selectattr: fieldInfo.selectattr || null
            }; // 获取字段值

            var fieldMark = "field".concat(fieldId);
            var fieldObj = window.WfForm ? window.WfForm.getFieldObj(fieldMark) : null;

            if (fieldObj) {
              mainData[fieldMark] = {
                value: fieldObj.value || '',
                specialobj: fieldObj.specialobj || []
              };
            }
          }
        }); // 获取明细表信息

        var detailMap = layoutStore.detailMap || new Map();
        var tableInfo = {
          main: {
            fieldinfomap: mainFieldInfoMap
          }
        };
        var detailDataObj = {}; // 遍历明细表

        detailMap.forEach(function (detailObj, detailMark) {
          if (detailMark && detailMark.startsWith('detail_')) {
            var detailIndex = detailMark;
            var detailFieldInfoMap = {};
            var rowDatas = {}; // 获取明细字段信息

            fieldAttrMap.forEach(function (fieldInfo, fieldId) {
              if (fieldInfo && fieldInfo.isdetail && fieldInfo.tableMark === detailMark) {
                detailFieldInfoMap[fieldId] = {
                  fieldid: fieldId,
                  fieldname: fieldInfo.fieldname || '',
                  fieldlabel: fieldInfo.fieldlabel || '',
                  detailtype: fieldInfo.detailtype || 0,
                  htmltype: fieldInfo.htmltype || 0
                };
              }
            });
            tableInfo[detailIndex] = {
              fieldinfomap: detailFieldInfoMap
            }; // 获取明细行数据

            if (detailObj && detailObj.rowInfo) {
              detailObj.rowInfo.forEach(function (rowAttr, rowKey) {
                if (rowKey.startsWith('row_')) {
                  var rowData = {};
                  Object.keys(detailFieldInfoMap).forEach(function (fieldId) {
                    var fieldMark = "".concat(rowKey, ".field").concat(fieldId);
                    var fieldObj = window.WfForm ? window.WfForm.getFieldObj("field".concat(fieldId, "_").concat(rowKey.replace('row_', ''))) : null;

                    if (fieldObj) {
                      rowData["field".concat(fieldId)] = {
                        value: fieldObj.value || '',
                        specialobj: fieldObj.specialobj || []
                      };
                    } else {
                      rowData["field".concat(fieldId)] = {
                        value: '',
                        specialobj: []
                      };
                    }
                  });

                  if (rowAttr && rowAttr.has && rowAttr.has('keyid')) {
                    rowData.keyid = rowAttr.get('keyid');
                  }

                  rowDatas[rowKey] = rowData;
                }
              });
            }

            detailDataObj[detailIndex] = {
              rowDatas: rowDatas,
              addRowDefValue: {}
            }; // 构建明细表 Table 数据

            _this.buildDetailTableData(detailIndex, detailFieldInfoMap, rowDatas);
          }
        });

        _this.setState({
          formInfo: {
            tableInfo: tableInfo,
            maindata: mainData
          },
          detailData: detailDataObj
        });
      } catch (error) {
        console.error('加载表单数据失败:', error);
      }
    };

    _this.buildDetailTableData = function (detailIndex, fieldInfoMap, rowDatas) {
      var columns = [{
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        fixed: 'left'
      }]; // 添加字段列

      Object.keys(fieldInfoMap).forEach(function (fieldId) {
        var fieldInfo = fieldInfoMap[fieldId];
        columns.push({
          title: "".concat(fieldInfo.fieldlabel, "(").concat(fieldInfo.fieldname, ")"),
          dataIndex: "field".concat(fieldId),
          key: "field".concat(fieldId),
          fieldId: fieldId,
          fieldName: fieldInfo.fieldname,
          fieldLabel: fieldInfo.fieldlabel,
          render: function render(text, record) {
            var fieldData = record["field".concat(fieldId)];

            if (fieldData) {
              return fieldData.value || '';
            }

            return '';
          }
        });
      }); // 转换行数据为 Table 格式

      var dataSource = [];
      var index = 1;
      Object.keys(rowDatas).sort().forEach(function (rowKey) {
        var rowData = rowDatas[rowKey];
        var tableRow = {
          key: rowKey,
          index: index++,
          rowId: rowData.keyid // 保存行ID

        };
        Object.keys(rowData).forEach(function (key) {
          if (key !== 'keyid') {
            tableRow[key] = rowData[key];
          }
        });
        dataSource.push(tableRow);
      });

      _this.setState(function (prevState) {
        return {
          detailTableData: _objectSpread({}, prevState.detailTableData, _defineProperty({}, detailIndex, dataSource)),
          detailTableColumns: _objectSpread({}, prevState.detailTableColumns, _defineProperty({}, detailIndex, columns))
        };
      });
    };

    _this.handleSearchChange = function (e) {
      _this.setState({
        searchText: e.target.value
      });
    };

    _this.state = {
      formInfo: null,
      // 表单信息
      detailData: null,
      // 明细数据
      detailTableData: {},
      // 明细表数据（用于 Table 显示）
      detailTableColumns: {},
      // 明细表列配置
      searchText: '',
      // 搜索文本
      requestId: null // 请求ID

    };
    return _this;
  }

  _createClass(FormFieldsInfoTab, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.loadFormData();
      this.loadRequestId();
    } // 获取请求ID

  }, {
    key: "render",
    value: function render() {
      var onCloseDrawer = this.props.onCloseDrawer;
      var _this$state = this.state,
          formInfo = _this$state.formInfo,
          detailData = _this$state.detailData,
          detailTableData = _this$state.detailTableData,
          detailTableColumns = _this$state.detailTableColumns,
          searchText = _this$state.searchText,
          requestId = _this$state.requestId;
      return React.createElement("div", {
        style: {
          padding: '16px',
          overflow: 'auto',
          height: '100%'
        }
      }, React.createElement(MainFieldsPanel, {
        formInfo: formInfo,
        searchText: searchText,
        onSearchChange: this.handleSearchChange,
        onCloseDrawer: onCloseDrawer,
        requestId: requestId
      }), React.createElement("div", {
        style: {
          marginTop: '24px'
        }
      }, React.createElement("h3", null, "\u660E\u7EC6\u8868\u5B57\u6BB5"), !detailData || Object.keys(detailData).length === 0 ? React.createElement("div", {
        style: {
          padding: '20px',
          textAlign: 'center',
          color: '#999'
        }
      }, "\u6682\u65E0\u660E\u7EC6\u6570\u636E") : Object.keys(detailData).sort().map(function (detailIdx) {
        var columns = detailTableColumns[detailIdx] || [];
        var dataSource = detailTableData[detailIdx] || [];
        return React.createElement(DetailTablePanel, {
          key: detailIdx,
          detailIndex: detailIdx,
          columns: columns,
          dataSource: dataSource,
          requestId: requestId
        });
      })));
    }
  }]);

  return FormFieldsInfoTab;
}(React.Component);

ecodeSDK.exp(FormFieldsInfoTab);