const {Table, Input, Icon, message} = antd;

/**
 * 流程节点信息面板组件
 * 用于显示当前流程的所有节点信息，包括：
 * - 节点ID
 * - 节点名称
 * - 搜索功能（支持节点ID和节点名称搜索）
 * 
 * 组件内部负责获取流程节点信息
 */
class WorkflowNodesPanel extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            nodes: [], // 节点列表
            searchText: '', // 搜索文本
            loading: false // 加载状态
        };
    }

    componentDidMount() {
        this.loadWorkflowNodes();
    }

    // 加载流程节点信息
    loadWorkflowNodes = async () => {
        try {
            // 获取流程ID
            const baseInfo = window.WfForm ? window.WfForm.getBaseInfo() : null;
            if (!baseInfo || !baseInfo.workflowid) {
                message.warning('无法获取流程ID');
                return;
            }

            this.setState({ loading: true });

            // 调用后端接口获取节点信息
            const response = await fetch(`/api/second-dev/workflow/info/nodes?workflowId=${baseInfo.workflowid}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                const errorMsg = errorData.msg || errorData.message || `获取节点信息失败 (状态码: ${response.status})`;
                message.error(errorMsg);
                this.setState({ loading: false });
                return;
            }

            const nodeList = await response.json();
            this.setState({
                nodes: nodeList || [],
                loading: false
            });
        } catch (error) {
            console.error('加载流程节点信息失败:', error);
            message.error('加载流程节点信息失败: ' + error.message);
            this.setState({ loading: false });
        }
    }

    // 搜索文本变化
    handleSearchChange = (e) => {
        this.setState({ searchText: e.target.value });
    }

    // 获取过滤后的节点列表
    getFilteredNodes = () => {
        const { nodes, searchText } = this.state;
        if (!searchText) {
            return nodes;
        }

        const searchLower = searchText.toLowerCase();
        return nodes.filter(node => {
            const nodeId = node.nodeId ? String(node.nodeId) : '';
            const nodeName = node.nodeName || '';
            return nodeId.includes(searchLower) || nodeName.toLowerCase().includes(searchLower);
        });
    }

    render() {
        const { searchText, loading } = this.state;
        const filteredNodes = this.getFilteredNodes();

        const columns = [
            {
                title: '节点ID',
                dataIndex: 'nodeId',
                key: 'nodeId',
                width: 120
            },
            {
                title: '节点名称',
                dataIndex: 'nodeName',
                key: 'nodeName'
            }
        ];

        const dataSource = filteredNodes.map((node, index) => ({
            key: index,
            nodeId: node.nodeId || '-',
            nodeName: node.nodeName || '-'
        }));

        return (
            <div style={{padding: '16px', overflow: 'auto', height: '100%'}}>
                <div style={{marginBottom: '16px'}}>
                    <Input
                        placeholder="搜索节点（支持节点ID和节点名称）"
                        value={searchText}
                        onChange={this.handleSearchChange}
                        prefix={<Icon type="search" />}
                        allowClear
                    />
                </div>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    loading={loading}
                    pagination={{
                        pageSize: 20,
                        showSizeChanger: true,
                        showTotal: (total) => `共 ${total} 条`
                    }}
                    scroll={{x: 'max-content'}}
                    size="small"
                    locale={{
                        emptyText: filteredNodes.length === 0 && searchText ? '暂无匹配的节点数据' : '暂无节点数据'
                    }}
                />
            </div>
        );
    }
}

ecodeSDK.exp(WorkflowNodesPanel);
