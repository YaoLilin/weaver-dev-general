"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaSlideModal = _ecCom.WeaSlideModal;
var DrawerContent = ecodeSDK.imp(DrawerContent);
var FormToolIcon = ecodeSDK.imp(FormToolIcon);
/**
 * 流程表单助手主组件
 * 用于在流程表单页面提供表单字段和流程信息的查看功能，包括：
 * - 可拖动的助手图标（FormToolIcon组件）
 * - 抽屉式侧边栏（WeaSlideModal组件）
 * - 抽屉内容（DrawerContent组件）
 */

var FormTool =
/*#__PURE__*/
function (_React$Component) {
  _inherits(FormTool, _React$Component);

  function FormTool(props) {
    var _this;

    _classCallCheck(this, FormTool);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(FormTool).call(this, props));

    _this.handleKeyDown = function (e) {
      // 按下ESC键且抽屉打开时，关闭抽屉
      if (e.keyCode === 27 && _this.state.visible) {
        e.preventDefault();

        _this.closeDrawer();
      }
    };

    _this.toggleDrawer = function () {
      _this.setState(function (prevState) {
        return {
          visible: !prevState.visible
        };
      });
    };

    _this.closeDrawer = function () {
      _this.setState({
        visible: false
      });
    };

    _this.state = {
      visible: false // 控制抽屉显示

    };
    return _this;
  }

  _createClass(FormTool, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      // 添加键盘事件监听
      document.addEventListener('keydown', this.handleKeyDown);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // 移除键盘事件监听
      document.removeEventListener('keydown', this.handleKeyDown);
    } // 处理键盘事件

  }, {
    key: "render",
    value: function render() {
      var visible = this.state.visible;
      return React.createElement("div", null, !visible && React.createElement(FormToolIcon, {
        onClick: this.toggleDrawer
      }), React.createElement(WeaSlideModal, {
        visible: visible,
        direction: "right",
        width: 50,
        measureX: "%",
        height: 100,
        measureY: "%",
        top: 0,
        measureT: "%",
        title: "\u6D41\u7A0B\u8868\u5355\u52A9\u624B",
        showMask: true,
        closeMaskOnClick: true,
        onClose: this.closeDrawer,
        content: React.createElement(DrawerContent, {
          onCloseDrawer: this.closeDrawer
        })
      }));
    }
  }]);

  return FormTool;
}(React.Component);

ecodeSDK.setCom('${appId}', 'FormTool', FormTool);