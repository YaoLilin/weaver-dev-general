const {WeaSlideModal} = ecCom;
const DrawerContent = ecodeSDK.imp(DrawerContent);
const FormToolIcon = ecodeSDK.imp(FormToolIcon);

/**
 * 流程表单助手主组件
 * 用于在流程表单页面提供表单字段和流程信息的查看功能，包括：
 * - 可拖动的助手图标（FormToolIcon组件）
 * - 抽屉式侧边栏（WeaSlideModal组件）
 * - 抽屉内容（DrawerContent组件）
 */
class FormTool extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            visible: false // 控制抽屉显示
        };
    }

    componentDidMount() {
        // 添加键盘事件监听
        document.addEventListener('keydown', this.handleKeyDown);
    }

    componentWillUnmount() {
        // 移除键盘事件监听
        document.removeEventListener('keydown', this.handleKeyDown);
    }

    // 处理键盘事件
    handleKeyDown = (e) => {
        // 按下ESC键且抽屉打开时，关闭抽屉
        if (e.keyCode === 27 && this.state.visible) {
            e.preventDefault();
            this.closeDrawer();
        }
    }

    // 切换抽屉显示
    toggleDrawer = () => {
        this.setState(prevState => ({
            visible: !prevState.visible
        }));
    }

    // 关闭抽屉
    closeDrawer = () => {
        this.setState({
            visible: false
        });
    }

    render() {
        const {visible} = this.state;

        return (
            <div>
                {/* 固定图标按钮 */}
                {!visible && (
                    <FormToolIcon onClick={this.toggleDrawer} />
                )}

                {/* 抽屉组件 */}
                <WeaSlideModal
                    visible={visible}
                    direction="right"
                    width={50}
                    measureX="%"
                    height={100}
                    measureY="%"
                    top={0}
                    measureT="%"
                    title="流程表单助手"
                    showMask={true}
                    closeMaskOnClick={true}
                    onClose={this.closeDrawer}
                    content={
                        <DrawerContent
                            onCloseDrawer={this.closeDrawer}
                        />
                    }
                />
            </div>
        );
    }
}

ecodeSDK.setCom('${appId}','FormTool',FormTool);
