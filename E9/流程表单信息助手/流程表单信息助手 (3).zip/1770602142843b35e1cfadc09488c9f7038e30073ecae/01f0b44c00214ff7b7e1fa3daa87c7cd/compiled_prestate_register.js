"use strict";

var loaded = false;

function getUserId() {
  var user = ecodeSDK.getEcodeParams(['ecode_params'])._user;

  if (!user) {
    return null;
  }

  return user.id;
}

ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop', {
  fn: function fn(props) {
    if (location.href.includes('spa/workflow/static4form/index') && props.buttons && props.buttons.length > 0) {
      var userId = getUserId();

      if (userId && userId === '1' && !loaded) {
        loaded = true; // 添加组件到页面

        loadTool();
      }
    }
  }
});

var FormTool = function FormTool(props) {
  var params = {
    appId: '${appId}',
    name: 'FormTool',
    isPage: false,
    noCss: true,
    props: props
  };
  var NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(params) : React.createElement(NewCom, props);
};

function loadTool() {
  var div = document.getElementById('container'); // 创建子元素

  var node = document.createElement('div');
  div.appendChild(node); // 将自己创建的组件：Main ，渲染到子元素中

  ReactDOM.render(React.createElement(FormTool, null), node);
}