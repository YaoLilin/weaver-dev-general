function getWorkflowConfig() {
    const config = ecodeSDK.getCom('${appId}', 'config');
    const baseInfo = WfForm.getBaseInfo();
    const {formid, workflowid} = baseInfo;
    return config.workflowConfigs.find(i => {
        if (i.formId === formid) {
            if (i.workflowIds.length > 0) {
                return i.workflowIds.includes(workflowid);
            }
            return true;
        }
    });
}

let merged = false;
/**
 * 拦截流程页面组件，流程页面加载后合并明细
 * @date 2025-06-04
 */
ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop', {
    fn: props => {
        if (location.href.includes("spa/workflow/static4form/index.html") && props.buttons.length > 0) {
            const workflowConfig = getWorkflowConfig();
            if (workflowConfig && !merged) {
                workflowConfig.detailConfigs.forEach(i => {
                    onDetailRendered(i.tableIndex, () => mergeTable(i.tableIndex));
                });
                merged = true;
            }
        }
    }
});

// 可从外部调用，合并明细
window.mergeTable = () => {
  const workflowConfig = getWorkflowConfig();
  if (workflowConfig) {
    workflowConfig.detailConfigs.forEach(i => {
      onDetailRendered(i.tableIndex, () => mergeTable(i.tableIndex));
    });
  }
}

// 存储明细表的分页信息
const detailPageMap = new Map();
/**
 * 明细表分页器切换页时，重新对表格进行合并
 * @date 2025-06-04
 */
ecodeSDK.overwritePropsFnQueueMapSet('Pagination', {
    fn: props => {
        if (location.href.includes("spa/workflow/static4form/index.html") && props.symbol) {
            const config = getWorkflowConfig();
            if (config) {
                const detailIndex = Number(props.symbol.split('_')[1]);
                const detailConfig = config.detailConfigs.find(i => i.tableIndex === detailIndex);
                const {pageSize, current} = props;
                detailPageMap.set(detailIndex, {pageSize, current});
                // 如果此明细表有合并配置，则对表格进行合并
                if (detailConfig) {
                    // 切换页面时，重新对表格进行合并
                    const onChange = props.onChange;
                    props.onChange = pageNum => {
                        const table = document.getElementById("oTable" + (detailIndex - 1));
                        // 清除之前的合并状态
                        clearMergeStatus(table);
                        onChange(pageNum);
                        // 等明细表加载完后合并表格
                        waitTableLoadDone(detailIndex, () => mergeTable(detailIndex));
                    }
                    // 改变页数大小时，重新对表格进行合并
                    const onShowSizeChange = props.onShowSizeChange;
                    props.onShowSizeChange = (page, size) => {
                        const table = document.getElementById("oTable" + (detailIndex - 1));
                        // 清除之前的合并状态
                        clearMergeStatus(table);
                        onShowSizeChange(page, size);
                        // 等明细表加载完后合并表格
                        waitTableLoadDone(detailIndex, () => mergeTable(detailIndex));
                    }
                }
            }
        }
    }
});

/**
 * 当明细表渲染完成后，执行回调函数
 * @param detailIndex 明细表索引
 * @param callback 回调函数
 */
function onDetailRendered(detailIndex, callback) {
    const count = WfForm.getDetailRowCount('detail_' + detailIndex);
    if (count > 0) {
        callback();
    }
    let waitCount = 0;
    const intervalId = setInterval(() => {
        const count = WfForm.getDetailRowCount('detail_' + detailIndex);
        if (count > 0) {
            callback();
            clearInterval(intervalId);
        }
        if (waitCount > 80) {
            console.info('等待明细表渲染超时')
            clearInterval(intervalId);
        }
    }, 50);
}

/**
 * 清除表格中所有单元格的合并状态
 * @param {HTMLElement} table - 目标表格元素
 */
function clearMergeStatus(table) {
    const rows = Array.from(table.querySelectorAll("tr.detail_data_row"));
    rows.forEach(row => {
        const tds = row.querySelectorAll("td");
        tds.forEach(td => {
            td.removeAttribute("rowspan"); // 移除 rowspan 属性
            td.style.display = ""; // 恢复显示
        });
    });
}

/**
 * 等待表格加载完成后再执行回调函数
 * @param {number} detailIndex - 表格索引
 * @param {Function} callback - 回调函数
 */
function waitTableLoadDone(detailIndex, callback) {
    const table = document.getElementById("oTable" + (detailIndex - 1));
    const tbody = table.querySelector("tbody");
    let count = null;
    let noChange = false;
    const intervalId = setInterval(() => {
        const rows = Array.from(tbody.querySelectorAll("tr.detail_data_row"));
        let rowCount = rows.length;
        if (rowCount === count && !noChange) {
            noChange = true;
        } else if (rowCount === count) {
            callback(); // 表格加载完成，执行回调
            clearInterval(intervalId);
        }
        count = rowCount;
    }, 50);
}

/**
 * 合并表格中的单元格
 */
function mergeTable(detailIndex) {
    const workflowConfig = getWorkflowConfig();
    const detailConfig = workflowConfig.detailConfigs.find(i => i.tableIndex === detailIndex);
    if (!detailConfig) {
        return;
    }
    const {primaryKeyField, mergeSerialColumn, mergeColFieldNames} = detailConfig;
    const table = document.getElementById("oTable" + (detailIndex - 1)); // 获取目标表格
    const tbody = table.querySelector("tbody");
    const rows = Array.from(tbody.querySelectorAll("tr.detail_data_row")); // 获取所有数据行
    // 序号列索引
    let serialIndex = getOrderColIndex(tbody);
    // 对行按主键进行分组，方便对后续进行合并
    const rowGroups = getRowGroups(rows, primaryKeyField, detailIndex);
    
    // 行序号
    let order = getStartOrder(detailIndex, primaryKeyField);
    rowGroups.forEach(group => {
        const {indices: rowIndices} = group;
        const firstRow = rows[rowIndices[0]];
        // 第一行的所有单元格（字段）
        const firstRowColTds = firstRow.querySelectorAll("td");
        // const allFieldsReadonly = isAllFieldsReadonly(rows, rowIndices[0], firstRowColTds);
        // 遍历表格列
        for (let colIndex = 0; colIndex < firstRowColTds.length; colIndex++) {
            // 判断是否合并序号列
            if (colIndex === serialIndex && mergeSerialColumn) {
                // 合并序号，并重新设置序号的值
                mergeOrderTd(firstRowColTds, colIndex, rowIndices, rows, order);
                order++;
                continue;
            }
            const fieldName = getColFieldName(firstRowColTds[colIndex]);
            // 判断当前列（字段）是否需要合并
            if (mergeColFieldNames.includes(fieldName) || fieldName === primaryKeyField) {
                mergeTd(firstRowColTds, colIndex, rowIndices, rows);
            }
        }
    });
}

/**
 * 获取表格序号列的位置
 * @param {HTMLElement} tbody 表格 tbody 元素
 * @returns {number} 序号列索引
 */
function getOrderColIndex(tbody) {
  let index = -1;
  const rows = tbody.querySelectorAll("tr");
  rows.forEach(r =>{
    if(r.getAttribute('class') !== ''){
      return;
    }
    const tds = r.querySelectorAll("td");
    tds.forEach((td, idx) => {
      if (td.textContent.trim() === "序号") {
        index = idx; // 找到序号列索引
      }
    });
  })
  return index;
}

/**
 * 按主键对行进行分组，如果主键相同则为同一组，每一组包含多个行标识
 * @param {[HTMLElement]} rows 表格行元素
 * @param primaryKeyField 主键字段名
 * @param detailIndex 明细表索引
 * @returns {*[]} 分组数据
 */
function getRowGroups(rows, primaryKeyField, detailIndex) {
    const groups = [];
    let currentGroup = {fieldVal: null, indices: []};

    // 按主键字段值分组
    rows.forEach((row, index) => {
        const rowIndex = row.getAttribute('data-rowindex');
        if (!rowIndex) {
            return;
        }
        const fieldValue = WfForm.getFieldValue(WfForm.convertFieldNameToId(primaryKeyField,
            'detail_' + detailIndex) + '_' + rowIndex);
        if (fieldValue === currentGroup.fieldVal) {
            currentGroup.indices.push(index);
        } else {
            if (currentGroup.fieldVal !== null) {
                groups.push(currentGroup);
            }
            currentGroup = {fieldVal: fieldValue, indices: [index]};
        }
    });

    if (currentGroup.fieldVal !== null) {
        groups.push(currentGroup);
    }
    return groups;
}

/**
 * 合并序号单元格
 * @param firstRowColTds 行td元素集合
 * @param orderColIndex 序号列位置
 * @param rowIndices 该组的行元素索引
 * @param rows 明细表行元素集合
 * @param order 序号值
 */
function mergeOrderTd(firstRowColTds, orderColIndex, rowIndices, rows, order) {
    // 设置序号单元格合并
    firstRowColTds[orderColIndex].setAttribute("rowspan", rowIndices.length);
    for (let i = 0; i < rowIndices.length; i++) {
        const targetTd = rows[rowIndices[i]].querySelectorAll("td")[orderColIndex];
        if (targetTd) {
            // 如果为第一行，则设置序号值，否则隐藏后面的序号单元格
            if (i === 0) {
                // 设置序号值
                targetTd.textContent = order;
            } else {
                // 隐藏后续单元格
                targetTd.style.display = "none";
            }

        }
    }
}

/**
 * 获取表格列对应的字段名
 * @param td 表格 td 元素
 * @returns {string} 表格列对应的字段名
 */
function getColFieldName(td) {
    const div = td.querySelector("div");
    if (div) {
        return div.getAttribute("data-fieldname");
    }
    return '';
}

/**
 * 表格单元格合并
 */
function mergeTd(rowTds, colIndex, rowIndices, rows) {
    rowTds[colIndex].setAttribute("rowspan", rowIndices.length);
    for (let i = 1; i < rowIndices.length; i++) {
        const targetTd = rows[rowIndices[i]].querySelectorAll("td")[colIndex];
        if (targetTd) {
            // 隐藏后续单元格
            targetTd.style.display = "none";
        }
    }
}

/**
 * 获取当前页的起始序号。根据明细表合并，计算出起始序号，例如第一行和第二行合并，序号为1，即合并的行序号相同
 * @param detailIndex 明细表索引
 * @param keyFieldName 主键字段名
 * @returns {number} 当前页的起始序号
 */
function getStartOrder(detailIndex, keyFieldName) {
    const pageInfo = detailPageMap.get(detailIndex);
    if (!pageInfo) {
        return 1;
    }
    const {pageSize, current} = pageInfo;
    if (current === 1) {
        return 1;
    }
    const indices = WfForm.getDetailAllRowIndexStr('detail_' + detailIndex).split(',');
    let page = 0;
    let order = 0;
    let preValue = '';
    for (let i = 0; i < indices.length; i++) {
        if (i % pageSize === 0) {
            page++;
        }
        const fieldValue = WfForm.getFieldValue(WfForm.convertFieldNameToId(keyFieldName,
            'detail_' + detailIndex) + '_' + i);
        if (fieldValue !== preValue || i === 0) {
            order++;
        }
        preValue = fieldValue;
        if (page === current) {
            break;
        }
    }
    return order;
}

/**
 * 判断某一行的所有字段是否都是只读
 * @param {Array} rows - 所有数据行
 * @param {number} rowIndex - 当前行索引
 * @param {NodeList} tds - 当前行的所有单元格
 * @returns {boolean} - 是否所有字段都为只读
 */
function isAllFieldsReadonly(rows, rowIndex, tds) {
    const row = rows[rowIndex];
    const cells = row.querySelectorAll("td");

    for (let i = 0; i < cells.length; i++) {
        const div = cells[i].querySelector("div");
        if (!div) continue;

        const fieldName = div.getAttribute("data-fieldname");
        if (!fieldName) continue;

        // 获取字段 ID
        const fieldId = WfForm.convertFieldNameToId(fieldName, 'detail_1') + "_" + rowIndex;
        const attr = WfForm.getFieldCurViewAttr(fieldId);

        // 如果字段不是只读，则返回 false
        if (attr === 2 || attr === 3) {
            return false;
        }
    }

    return true;
}

/**
 * 获取单元格的字段值
 * @param {HTMLElement} td - 单元格元素
 * @returns {string} - 字段值
 */
function getFieldValue(td) {
    const div = td.querySelector("div");
    if (!div) return "";
    const span = div.querySelector("span");
    return span ? span.textContent.trim() : "";
}
