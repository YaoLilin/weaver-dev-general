"use strict";

var config = {
  // 流程配置项，每个对象表示1个流程配置
  workflowConfigs: [{
    // 流程表单id，比如表单名称为 formtable_main_16，表单id就为 -16
    formId: -16,
    // 流程id，如果为空则不会根据流程id进行判断，如果不为空则还会判断流程id是否符合，适用于按流程版本判断是否启用的场景
    workflowIds: [],
    // 流程明细配置项，可配置多个明细，每个对象表示1个明细
    detailConfigs: [{
      // 明细索引，可根据明细表名判断，formtable_main_16_dt1 明细索引就是1
      tableIndex: 1,
      // 是否合并序号，如果合并序号，则序号的值将以主键为准自增，比如主键相同则序号也会相同，如果不合并序号则按默认的按行数自增
      mergeSerialColumn: true,
      // 明细主键字段名，取此主键字段值，如果值相同则会将相应的行进行合并
      primaryKeyField: 'mc',
      // 需要合并的字段，可不包含主键字段名
      mergeColFieldNames: ['bh', 'factory_code']
    }, {
      // 明细索引，可根据明细表名判断，formtable_main_16_dt1 明细索引就是1
      tableIndex: 2,
      // 是否合并序号，如果合并序号，则序号的值将以主键为准自增，比如主键相同则序号也会相同，如果不合并序号则按默认的按行数自增
      mergeSerialColumn: true,
      // 明细主键字段名，取此主键字段值，如果值相同则会将相应的行进行合并
      primaryKeyField: 'bm',
      // 需要合并的字段，可不包含主键字段名
      mergeColFieldNames: ['sl', 'szgs', '']
    }]
  }]
}; // 以下为配置示例

var configDemo = {
  // 流程配置项，每个对象表示1个流程配置
  workflowConfigs: [// 流程1
  {
    formId: -16,
    // 填了此项后，如果流程表单id为 -16，流程id为 56或57，将会启用本开发
    workflowIds: [56, 57],
    detailConfigs: [// 第一个明细
    {
      tableIndex: 1,
      mergeSerialColumn: true,
      primaryKeyField: 'mc',
      mergeColFieldNames: ['bh', 'factory_code']
    }, // 第二个明细
    {
      tableIndex: 2,
      // 不合并序号
      mergeSerialColumn: false,
      primaryKeyField: 'code',
      mergeColFieldNames: ['mc', 'text']
    }]
  }, // 流程2
  {
    formId: -17,
    workflowIds: [],
    detailConfigs: [// 第一个明细
    {
      tableIndex: 1,
      mergeSerialColumn: true,
      primaryKeyField: 'mc',
      mergeColFieldNames: ['bh', 'factory_code']
    }]
  }]
};
ecodeSDK.setCom('${appId}', 'config', config);