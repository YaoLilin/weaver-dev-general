

ecodeSDK.overwritePropsFnQueueMapSet('WeaFormItem', {
  fn: (props) => {
    if (!location.href.includes('cubeengine/app/modebatchimport')) {
      return;
    }
    try {
      const modeId = getUrlParam('modeid');
      const config = ecodeSDK.getCom('${appId}', 'config');
      if (!config) {
        return;
      }
      if (config.modeId === Number(modeId)) {
        props.labelCol.span = 12;
        props.wrapperCol.span = 12;
        addText();
      }
    } catch (e) {
      console.error(e);
    }
  }
})

let changed = false;
function addText() {
  if (changed) {
    return;
  }
  // 获取目标元素
  const targetElement = document.querySelector('.cube-mode-import-content');
  if (targetElement) {
    changed = true;
    // 创建两个新的 div 元素
    const containerDiv = document.createElement('div');
    const textDiv = document.createElement('div');

    // 设置样式使它们并列显示，宽度各占一半
    containerDiv.style.display = 'flex';
    containerDiv.style.width = '100%';

    const innerContainerDiv = document.createElement('div');
    innerContainerDiv.style.flex = '1'; // 宽度各占一半

    const config = ecodeSDK.getCom('${appId}', 'config');
    textDiv.style.flex = '1'; // 宽度各占一半
    textDiv.style.color = 'red';
    textDiv.textContent = config.text; // 设置要显示的文本

    // 将原目标元素的所有子节点移动到新的 innerContainerDiv 中
    while (targetElement.firstChild) {
      innerContainerDiv.appendChild(targetElement.firstChild);
    }

    // 将新的 div 添加到目标元素中
    containerDiv.appendChild(innerContainerDiv);
    containerDiv.appendChild(textDiv);

    targetElement.appendChild(containerDiv);
  }

}

/**
 * 获取浏览器链接地址的参数值
 * @params name 参数名
 */
function getUrlParam(name) {
  const urlString = location.href;
  const hashIndex = urlString.indexOf('#');
  if (hashIndex === -1) {
    return '';
  } else {
    const hashFragment = urlString.substring(hashIndex + 1);
    const hashParams = new URLSearchParams(hashFragment.split('?')[1]);
    return hashParams.get('modeid');
  }
}