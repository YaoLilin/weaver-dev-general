"use strict";

var config = {
  modeId: 114,
  text: '提示内容'
};
ecodeSDK.setCom('${appId}', 'config', config);