"use strict";

ecodeSDK.overwritePropsFnQueueMapSet('WeaFormItem', {
  fn: function fn(props) {
    if (!location.href.includes('cubeengine/app/modebatchimport')) {
      return;
    }

    try {
      var modeId = getUrlParam('modeid');
      var config = ecodeSDK.getCom('${appId}', 'config');

      if (!config) {
        return;
      }

      if (config.modeId === Number(modeId)) {
        props.labelCol.span = 12;
        props.wrapperCol.span = 12;
        addText();
      }
    } catch (e) {
      console.error(e);
    }
  }
});
var changed = false;

function addText() {
  if (changed) {
    return;
  } // 获取目标元素


  var targetElement = document.querySelector('.cube-mode-import-content');

  if (targetElement) {
    changed = true; // 创建两个新的 div 元素

    var containerDiv = document.createElement('div');
    var textDiv = document.createElement('div'); // 设置样式使它们并列显示，宽度各占一半

    containerDiv.style.display = 'flex';
    containerDiv.style.width = '100%';
    var innerContainerDiv = document.createElement('div');
    innerContainerDiv.style.flex = '1'; // 宽度各占一半

    var config = ecodeSDK.getCom('${appId}', 'config');
    textDiv.style.flex = '1'; // 宽度各占一半

    textDiv.style.color = 'red';
    textDiv.textContent = config.text; // 设置要显示的文本
    // 将原目标元素的所有子节点移动到新的 innerContainerDiv 中

    while (targetElement.firstChild) {
      innerContainerDiv.appendChild(targetElement.firstChild);
    } // 将新的 div 添加到目标元素中


    containerDiv.appendChild(innerContainerDiv);
    containerDiv.appendChild(textDiv);
    targetElement.appendChild(containerDiv);
  }
}
/**
 * 获取浏览器链接地址的参数值
 * @params name 参数名
 */


function getUrlParam(name) {
  var urlString = location.href;
  var hashIndex = urlString.indexOf('#');

  if (hashIndex === -1) {
    return '';
  } else {
    var hashFragment = urlString.substring(hashIndex + 1);
    var hashParams = new URLSearchParams(hashFragment.split('?')[1]);
    return hashParams.get('modeid');
  }
}