"use strict";

/**
 * 流程签字意见填写添加格式刷
 * @author 姚礼林
 */
ecodeSDK.overwritePropsFnQueueMapSet('WeaRichText', {
  fn: function fn(props) {
    if (location.href.includes('spa/workflow/static4form/index.html') && props.id && props.id === 'remark') {
      props.ckConfig.toolbar.forEach(function (i) {
        if (i.name === 'basicstyles') {
          if (!i.items.includes('CopyFormatting')) {
            i.items.push('CopyFormatting');
          }
        }
      });
    }
  }
});