/**
 * 流程签字意见输入框粘贴时去掉格式
 * @author 姚礼林
 */
ecodeSDK.overwritePropsFnQueueMapSet('WeaRichText',{
  fn:(props)=>{
    if(location.href.includes('spa/workflow/static4form/index.html') && props.id 
        && props.id === 'remark'){
        props.ckConfig.forcePasteAsPlainText = true;
    }
  }
})