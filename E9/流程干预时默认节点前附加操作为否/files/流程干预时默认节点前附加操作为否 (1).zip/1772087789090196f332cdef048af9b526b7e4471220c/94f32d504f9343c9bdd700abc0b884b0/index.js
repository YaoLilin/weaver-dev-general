
const {WeaSelect} = ecCom;

class CustomSelect extends React.Component{
  
  constructor(props){
    super(props);
    this.state={
      value:'0'
    }
  }

  componentDidMount(){
    this.props.onChange('0','否');
  }

  handleChange = (v,t)=>{
    this.props.onChange(v,t);
    this.setState({value:v})
  }

  render(){
    const {value} = this.state;
    return <WeaSelect {...this.props} value={value} onChange={this.handleChange} _noOverwrite/>
  }
}

ecodeSDK.setCom('${appId}','CustomSelect',CustomSelect);