"use strict";

var isChange = false;
/**
 * 流程干预时默认节点前附加操作为否
 * 替换原来的组件，在自己写的组件中将否设为默认选项
 */

ecodeSDK.overwriteClassFnQueueMapSet('WeaSelect', {
  fn: function fn(Com, props) {
    var url = location.href;

    if (url.includes('main/workflow/') && url.includes('isintervenor=1') && props.fieldName === 'enableIntervenor' && !props._noOverwrite) {
      return {
        props: props,
        com: CustomSelect
      };
    }

    return {
      props: props,
      com: Com
    };
  }
});

var CustomSelect = function CustomSelect(props) {
  var params = {
    appId: '${appId}',
    name: 'CustomSelect',
    isPage: false,
    noCss: true,
    props: props
  };
  var NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(params) : React.createElement(NewCom, props);
};