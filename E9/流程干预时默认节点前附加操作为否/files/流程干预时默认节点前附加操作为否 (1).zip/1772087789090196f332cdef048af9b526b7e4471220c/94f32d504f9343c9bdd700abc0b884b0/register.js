
let isChange = false

/**
 * 流程干预时默认节点前附加操作为否
 * 替换原来的组件，在自己写的组件中将否设为默认选项
 */
ecodeSDK.overwriteClassFnQueueMapSet('WeaSelect',{
  fn:(Com,props)=>{
    const url = location.href;
    if(url.includes('main/workflow/') && url.includes('isintervenor=1') && props.fieldName === 'enableIntervenor'
     && !props._noOverwrite){
        return {props,com:CustomSelect}
    }
    return {props,com:Com}
  }
});

const CustomSelect = (props)=>{
  const params ={
    appId:'${appId}',
    name:'CustomSelect',
    isPage:false,
    noCss:true,
    props
  }
  const NewCom = props.Com;
  return window.comsMobx?ecodeSDK.getAsyncCom(params):(<NewCom {...props}/>);
}