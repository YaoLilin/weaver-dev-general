"use strict";

// 存储每个门户元素的标签页参数
var currentTabIdMap = new Map(); // 获取元素标签页的参数,获取tabId

ecodeSDK.rewritePortalCusEleTabQueue.push({
  fn: function fn(params) {
    var _params$props = params.props,
        props = _params$props === void 0 ? {} : _params$props,
        _params$options = params.options,
        options = _params$options === void 0 ? {} : _params$options; // 存储当前选中的tab页和参数

    currentTabIdMap.set(Number(options.eid), {
      currentTabId: options.tabid,
      params: params
    });
  }
});
/**
 * 获取当前元素的ecode配置
 */

function getConfigItemByEcId(ecId) {
  var config = ecodeSDK.getCom('${appId}', 'config');

  if (!config) {
    return null;
  }

  var elementConfigs = config.elementConfigs;

  for (var i = 0; i < elementConfigs.length; i++) {
    var item = elementConfigs[i];

    if (ecId.includes('element-' + item.eId + '_')) {
      return item;
    }
  }

  return null;
}

function isTabInConfig(currentTabId, tabIds, tabTitles, configItem) {
  var tabIndex = tabIds.indexOf(currentTabId);
  var currentTabName = tabTitles[tabIndex];
  return configItem.tabNames.includes(currentTabName);
}

function enable(props) {
  // 获取当前元素的ecode配置
  var configItem = getConfigItemByEcId(props.ecId);

  if (!configItem) {
    return false;
  } // 没有配置tabNames表示全部tab都生效


  if (configItem.tabNames.length === 0) {
    return true;
  } // 找到当前元素的tab页参数


  var tabData = currentTabIdMap.get(configItem.eId);

  if (tabData == null) {
    return false;
  }

  var currentTabId = tabData.currentTabId,
      params = tabData.params;
  var tabTitles = params.props.datas.titles;
  var tabIds = params.props.datas.tabids;

  if (!tabTitles || !tabIds) {
    return false;
  } // 判断当前选中的tab页是否在ecode配置中


  return isTabInConfig(currentTabId, tabIds, tabTitles, configItem);
}

function isOvertime(requestId) {
  var isOvertime = false;
  $.ajax({
    url: '/api/second-dev/workflow/overtime/is-overtime?requestId=' + requestId,
    type: 'GET',
    async: false,
    success: function success(result) {
      isOvertime = result.overTime;
    },
    error: function error(e) {
      console.error('获取流程超时信息失败', e);
    }
  });
  return isOvertime;
}

function isTargetElement(eid) {
  var config = ecodeSDK.getCom('${appId}', 'config');
  var elementConfigs = config.elementConfigs;
  return elementConfigs.some(function (i) {
    return i.eId === Number(eid);
  });
}

function isTargetTab(eid, currentTabId, tabIds, workflowListTabNames) {
  var config = ecodeSDK.getCom('${appId}', 'config');
  var configItem = config.elementConfigs.find(function (i) {
    return i.eId === Number(eid);
  });

  if (configItem === undefined) {
    return false;
  }

  var tabNames = configItem.tabNames;

  if (tabNames.length === 0) {
    return true;
  }

  return isTabInConfig(currentTabId, tabIds, workflowListTabNames, configItem);
}

var apiDatas = [];

function sortAndRecordData(data) {
  data.forEach(function (i) {
    i.isOvertime = isOvertime(i.requestname.requestid);
  });
  data.sort(function (a, b) {
    return b.isOvertime - a.isOvertime;
  });
  apiDatas = data.map(function (i) {
    return {
      requestid: i.requestname.requestid,
      isOvertime: i.isOvertime
    };
  }); // 删除属性，不然表格会多出一列

  data.forEach(function (i) {
    return delete i.isOvertime;
  });
}

var workflowListTabNames = [];
/**
 * 拦截门户流程元素数据接口，获取门户流程元素标签页名称以及对数据按是否超时进行排序
 */

ecodeSDK.rewriteApiDataQueueSet({
  fn: function fn(url, params, datas) {
    try {
      if (location.href.includes('main/portal/portal') && url === '/api/portal/element/workflow') {
        var eid = params.eid;
        var tabids = datas.data.tabids;
        var titles = datas.titles;

        if (isTargetElement(eid)) {
          workflowListTabNames = titles;
        }

        if (isTargetTab(eid, tabids[0], tabids, titles)) {
          sortAndRecordData(datas.data.data);
        }
      }
    } catch (e) {
      console.error('接口拦截出错', e);
    }

    return datas;
  },
  desc: '获取门户流程元素标签页名称'
});
/**
 * 拦截门户流程元素数据接口，实现按超时排序
 */

ecodeSDK.rewriteApiDataQueueSet({
  fn: function fn(url, params, datas) {
    try {
      if (location.href.includes('main/portal/portal') && url === '/api/portal/element/workflowtab') {
        var eid = params.eid,
            tabid = params.tabid;
        var tabids = datas.tabids,
            data = datas.data;

        if (isTargetTab(eid, tabid, tabids, workflowListTabNames)) {
          sortAndRecordData(data);
        }
      }
    } catch (e) {
      console.error('接口拦截出错', e);
    }

    return datas;
  },
  desc: '拦截门户流程元素数据接口，实现按超时排序'
});
ecodeSDK.overwritePropsFnQueueMapSet('WeaTable', {
  fn: function fn(props) {
    if (!location.href.includes('main/portal/portal') || !props.ecId || !props.ecId.includes('WeaTable@x9vk4c')) {
      return;
    }

    if (enable(props)) {
      props.dataSource.forEach(function (i) {
        var requestId = i.requestname.requestid;
        i.isOvertime = isOvertime(requestId);
      });
      props.columns.forEach(function (i) {
        // 在标题后面添加超时标记
        if (i.dataIndex === 'requestname') {
          var _antd = antd,
              Tag = _antd.Tag;
          var render = i.render;
          i.className = 'show-overtime-col';

          i.render = function (data, record) {
            var isOvertime = apiDatas.some(function (d) {
              return d.requestid === data.requestid && d.isOvertime;
            });

            if (isOvertime) {
              // 在原组件后面加上超时标记
              return React.createElement("div", {
                style: {
                  display: 'flex',
                  alignItems: 'center'
                }
              }, React.createElement("div", {
                style: {
                  overflow: 'hidden'
                }
              }, " ", render(data, record), " "), React.createElement("div", {
                style: {
                  marginLeft: 10,
                  flexShrink: '0'
                }
              }, React.createElement(Tag, null, "\u5DF2\u8D85\u65F6 ")));
            } // 渲染原组件


            return render(data, record);
          };
        }
      });
    }
  }
});