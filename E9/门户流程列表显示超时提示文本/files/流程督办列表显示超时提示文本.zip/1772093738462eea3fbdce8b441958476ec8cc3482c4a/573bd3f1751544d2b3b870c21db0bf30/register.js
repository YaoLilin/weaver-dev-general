
// 存储每个门户元素的标签页参数
const currentTabIdMap = new Map();
// 获取元素标签页的参数,获取tabId
ecodeSDK.rewritePortalCusEleTabQueue.push({
    fn: (params) => {
        const { props = {}, options = {} } = params;
        // 存储当前选中的tab页和参数
        currentTabIdMap.set(Number(options.eid), { currentTabId: options.tabid, params });
    }
});

/**
 * 获取当前元素的ecode配置
 */
function getConfigItemByEcId(ecId) {
    const config = ecodeSDK.getCom('${appId}', 'config');
    if (!config) {
        return null;
    }
    const elementConfigs = config.elementConfigs;
    for (let i = 0; i < elementConfigs.length; i++) {
        const item = elementConfigs[i];
        if (ecId.includes('element-' + item.eId + '_')) {
            return item;
        }
    }
    return null;
}

function isTabInConfig(currentTabId, tabIds, tabTitles, configItem) {
    const tabIndex = tabIds.indexOf(currentTabId);
    const currentTabName = tabTitles[tabIndex];
    return configItem.tabNames.includes(currentTabName);
}

function enable(props) {
    // 获取当前元素的ecode配置
    const configItem = getConfigItemByEcId(props.ecId)
    if (!configItem) {
        return false;
    }
    // 没有配置tabNames表示全部tab都生效
    if (configItem.tabNames.length === 0) {
        return true;
    }
    // 找到当前元素的tab页参数
    const tabData = currentTabIdMap.get(configItem.eId)
    if (tabData == null) {
        return false;
    }
    const { currentTabId, params } = tabData;
    const tabTitles = params.props.datas.titles;
    const tabIds = params.props.datas.tabids;
    if (!tabTitles || !tabIds) {
        return false;
    }
    // 判断当前选中的tab页是否在ecode配置中
    return isTabInConfig(currentTabId, tabIds, tabTitles, configItem);
}

function isOvertime(requestId) {
    let isOvertime = false;
    $.ajax({
        url: '/api/second-dev/workflow/overtime/is-overtime?requestId=' + requestId,
        type: 'GET',
        async: false,
        success: result => {
            isOvertime = result.overTime;
        },
        error: e => {
            console.error('获取流程超时信息失败', e)
        }
    });
    return isOvertime;
}

function isTargetElement(eid) {
    const config = ecodeSDK.getCom('${appId}', 'config');
    const elementConfigs = config.elementConfigs;
    return elementConfigs.some(i => i.eId === Number(eid));
}

function isTargetTab(eid, currentTabId, tabIds, workflowListTabNames) {
    const config = ecodeSDK.getCom('${appId}', 'config');
    const configItem = config.elementConfigs.find(i => i.eId === Number(eid));
    if (configItem === undefined) {
        return false;
    }
    const { tabNames } = configItem;
    if (tabNames.length === 0) {
        return true;
    }
    return isTabInConfig(currentTabId, tabIds, workflowListTabNames, configItem);
}

let apiDatas = [];
function sortAndRecordData(data){
    data.forEach(i => {
        i.isOvertime = isOvertime(i.requestname.requestid);
    });
    data.sort((a, b) => {
        return b.isOvertime - a.isOvertime;
    });
    apiDatas = data.map(i => {return {requestid:i.requestname.requestid,isOvertime:i.isOvertime}});
    // 删除属性，不然表格会多出一列
    data.forEach( i => delete i.isOvertime);
}

let workflowListTabNames = [];
/**
 * 拦截门户流程元素数据接口，获取门户流程元素标签页名称以及对数据按是否超时进行排序
 */
ecodeSDK.rewriteApiDataQueueSet({
    fn: (url, params, datas) => {
        try{
            if (location.href.includes('main/portal/portal') && url === '/api/portal/element/workflow') {
                const { eid } = params;
                const tabids = datas.data.tabids;
                const titles = datas.titles;
                if (isTargetElement(eid)) {
                    workflowListTabNames = titles;
                }
                if (isTargetTab(eid, tabids[0], tabids, titles)) {
                    sortAndRecordData(datas.data.data);
                }
            }
        }catch(e){
            console.error('接口拦截出错', e);
        }

        return datas;
    },
    desc: '获取门户流程元素标签页名称'
});

/**
 * 拦截门户流程元素数据接口，实现按超时排序
 */
ecodeSDK.rewriteApiDataQueueSet({
    fn: (url, params, datas) => {
        try {
            if (location.href.includes('main/portal/portal') && url === '/api/portal/element/workflowtab') {
                const { eid, tabid } = params;
                const { tabids, data } = datas;
                if (isTargetTab(eid, tabid, tabids, workflowListTabNames)) {
                    sortAndRecordData(data);
                }
            }
        } catch (e) {
            console.error('接口拦截出错', e);
        }
        return datas;
    },
    desc: '拦截门户流程元素数据接口，实现按超时排序'
});

ecodeSDK.overwritePropsFnQueueMapSet('WeaTable', {
    fn: (props) => {
        if (!location.href.includes('main/portal/portal') || !props.ecId || !props.ecId.includes('WeaTable@x9vk4c')) {
            return;
        }
        if (enable(props)) {
            props.dataSource.forEach(i => {
                const requestId = i.requestname.requestid;
                i.isOvertime = isOvertime(requestId);
            });
            props.columns.forEach(i => {
                // 在标题后面添加超时标记
                if (i.dataIndex === 'requestname') {
                    const { Tag } = antd;
                    const render = i.render;
                    i.className = 'show-overtime-col'
                    i.render = (data, record) => {
                        let isOvertime = apiDatas.some(d => d.requestid === data.requestid && d.isOvertime);
                        if (isOvertime) {
                            // 在原组件后面加上超时标记
                            return(
                            <div style={ { display: 'flex', alignItems: 'center' } }>
                                <div style={ { overflow: 'hidden' } }> { render(data, record) } < /div>
                                < div style = {{ marginLeft: 10, flexShrink: '0' }}>
                                    <Tag>已超时 < /Tag>
                                < /div>
                            < /div>
                            )
                        }
                        // 渲染原组件
                        return render(data, record);
                    }
                }
            })
        }
    }
});

