const { WeaTable } = ecCom;

class NewTable extends React.Component {

    isOvertime = (requestId) => {
        let isOvertime = false;
        $.ajax({
            url: '/api/second-dev/workflow/overtime/is-overtime?requestId=' + requestId,
            type: 'GET',
            async: false,
            success: result => {
                isOvertime = result.overTime;
            },
            error: e => {
                console.error('获取流程超时信息失败', e)
            }
        });
        return isOvertime;
    }

    render() {
        console.log('render')
        const { dataSource } = this.props;
        const overtimeWorkflows = [];
        dataSource.forEach(i => {
            const requestId = i.requestname.requestid;
            const isOvertime = this.isOvertime(requestId);
            if(isOvertime){
              overtimeWorkflows.push(requestId);
            }
            i.isOvertime = isOvertime;
        });
        dataSource.sort((a, b) => {
          return b.isOvertime - a.isOvertime; 
        });

        this.props.columns.forEach(i => {
            // 在标题后面添加超时标记
            if (i.dataIndex === 'requestname') {
                const { Tag } = antd;
                const render = i.render;
                i.className = 'show-overtime-col'
                i.render = (data, record) => {
                    if (overtimeWorkflows.includes(data.requestid)) {
                        // 在原组件后面加上超时标记
                        return <div style={ { display: 'flex', alignItems: 'center' } }>
                            <div style={ { overflow: 'hidden' } }> { render(data, record) } < /div>
                            < div style = {{ marginLeft: 10, flexShrink: '0' }
                            }>
                                <Tag>已超时 < /Tag>
                            < /div>
                        < /div>
                    }
                    // 渲染原组件
                    return render(data, record);
                }
            }
        })

        return<WeaTable {...this.props } _noOverwrite/>
    }
}

ecodeSDK.setCom('${appId}','NewTable',NewTable);