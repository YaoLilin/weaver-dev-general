"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaTable = _ecCom.WeaTable;

var NewTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewTable, _React$Component);

  function NewTable() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, NewTable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(NewTable)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _this.isOvertime = function (requestId) {
      var isOvertime = false;
      $.ajax({
        url: '/api/second-dev/workflow/overtime/is-overtime?requestId=' + requestId,
        type: 'GET',
        async: false,
        success: function success(result) {
          isOvertime = result.overTime;
        },
        error: function error(e) {
          console.error('获取流程超时信息失败', e);
        }
      });
      return isOvertime;
    };

    return _this;
  }

  _createClass(NewTable, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      console.log('render');
      var dataSource = this.props.dataSource;
      var overtimeWorkflows = [];
      dataSource.forEach(function (i) {
        var requestId = i.requestname.requestid;

        var isOvertime = _this2.isOvertime(requestId);

        if (isOvertime) {
          overtimeWorkflows.push(requestId);
        }

        i.isOvertime = isOvertime;
      });
      dataSource.sort(function (a, b) {
        return b.isOvertime - a.isOvertime;
      });
      this.props.columns.forEach(function (i) {
        // 在标题后面添加超时标记
        if (i.dataIndex === 'requestname') {
          var _antd = antd,
              Tag = _antd.Tag;
          var render = i.render;
          i.className = 'show-overtime-col';

          i.render = function (data, record) {
            if (overtimeWorkflows.includes(data.requestid)) {
              // 在原组件后面加上超时标记
              return React.createElement("div", {
                style: {
                  display: 'flex',
                  alignItems: 'center'
                }
              }, React.createElement("div", {
                style: {
                  overflow: 'hidden'
                }
              }, " ", render(data, record), " "), React.createElement("div", {
                style: {
                  marginLeft: 10,
                  flexShrink: '0'
                }
              }, React.createElement(Tag, null, "\u5DF2\u8D85\u65F6 ")));
            } // 渲染原组件


            return render(data, record);
          };
        }
      });
      return React.createElement(WeaTable, _extends({}, this.props, {
        _noOverwrite: true
      }));
    }
  }]);

  return NewTable;
}(React.Component);

ecodeSDK.setCom('${appId}', 'NewTable', NewTable);