
const {Modal,message,Select} =antd;
const {WeaTransfer,WeaTools} = ecCom;
const Option = Select.Option;

/**
 * 自定义排序对话框
 * props:sessionkey
 */
class CustomOrderDialog extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      visible: false,
      data: [],
      selectedKeys: [],
      orderType:'desc'
    }
    this.sessionkey = '';
  }

  componentDidMount(){
    window.showCustomOrderDialog = ()=>{
      this.setState({visible : true})
    }
    window.changeSessionKey = (key)=>{
      this.sessionkey = key;
      this.getData();
    }
    window.cleanCustomOrder = ()=>{
      this.setState({selectedKeys:[]});
    }
  }

  getData=()=>{
    // 获取列表字段，将字段数据添加到排序字段数据中
    WeaTools.callApi('/api/ec/dev/table/showCol?dataKey='+this.sessionkey,'GET').then(result =>{
      if(result.status){
        const data = [];
        result.destdatas.filter(i => i.title).forEach(i =>{
          data.push({
            id:i._index,
            orderkey:i.orderkey,
            name:i.title
          });
        });
        result.srcdatas.filter(i => i.title).forEach(i =>{
          data.push({
            id:i._index,
            orderkey:i.orderkey,
            name:i.title
          });
        });
        this.setState({data});
      }
    }).catch(e=>{
      message.error('获取列字段数据失败');
    })
  }

  handleOk =()=>{
    this.setState({visible : false});
    this.changeTableOrder();
  }

  handleCancel=()=>{
    this.setState({visible : false})
  }

  changeTableOrder = ()=>{
    const {data,selectedKeys,orderType} = this.state;
    const orderFields = [];
    selectedKeys.forEach(i =>{
      const value = data.find( d => d.id === i);
      if(value){
        orderFields.push(value.orderkey);
      }
    });
    this.props.changeTableOrder(orderFields,orderType);
  }

  render() {
    const {visible,data,selectedKeys,orderType} = this.state;
    return (
      <div>
        <Modal title="自定义排序" width={700} visible={visible}
          onOk={this.handleOk} onCancel={this.handleCancel}
        >
          <WeaTransfer 
						      data={data}
			            selectedKeys={selectedKeys}
                  leftHeader={<p style={{paddingLeft:10}}>待排序字段</p>}
                  rightHeader={<p style={{paddingLeft:10}}>排序字段</p>}
			            onChange={(keys, datas)=> this.setState({selectedKeys: keys})}
					/>
          <div style={{paddingTop:10}}>
            <span>排序类型：</span>
            <Select defaultValue="desc" 
                    value={orderType} 
                    style={{ width: 120 }} 
                    onChange={(v) => this.setState({orderType:v})}>
              <Option value="desc">降序</Option>
              <Option value="asc">升序</Option>
            </Select>
          </div>
        </Modal>
      </div>
    );
  }
}

ecodeSDK.setCom('${appId}','CustomOrderDialog',CustomOrderDialog);
