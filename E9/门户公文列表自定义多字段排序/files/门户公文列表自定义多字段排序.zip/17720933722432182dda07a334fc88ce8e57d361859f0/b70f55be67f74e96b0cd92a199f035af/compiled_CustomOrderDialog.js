"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Modal = _antd.Modal,
    message = _antd.message,
    Select = _antd.Select;
var _ecCom = ecCom,
    WeaTransfer = _ecCom.WeaTransfer,
    WeaTools = _ecCom.WeaTools;
var Option = Select.Option;
/**
 * 自定义排序对话框
 * props:sessionkey
 */

var CustomOrderDialog =
/*#__PURE__*/
function (_React$Component) {
  _inherits(CustomOrderDialog, _React$Component);

  function CustomOrderDialog(props) {
    var _this;

    _classCallCheck(this, CustomOrderDialog);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(CustomOrderDialog).call(this, props));

    _this.getData = function () {
      // 获取列表字段，将字段数据添加到排序字段数据中
      WeaTools.callApi('/api/ec/dev/table/showCol?dataKey=' + _this.sessionkey, 'GET').then(function (result) {
        if (result.status) {
          var data = [];
          result.destdatas.filter(function (i) {
            return i.title;
          }).forEach(function (i) {
            data.push({
              id: i._index,
              orderkey: i.orderkey,
              name: i.title
            });
          });
          result.srcdatas.filter(function (i) {
            return i.title;
          }).forEach(function (i) {
            data.push({
              id: i._index,
              orderkey: i.orderkey,
              name: i.title
            });
          });

          _this.setState({
            data: data
          });
        }
      }).catch(function (e) {
        message.error('获取列字段数据失败');
      });
    };

    _this.handleOk = function () {
      _this.setState({
        visible: false
      });

      _this.changeTableOrder();
    };

    _this.handleCancel = function () {
      _this.setState({
        visible: false
      });
    };

    _this.changeTableOrder = function () {
      var _this$state = _this.state,
          data = _this$state.data,
          selectedKeys = _this$state.selectedKeys,
          orderType = _this$state.orderType;
      var orderFields = [];
      selectedKeys.forEach(function (i) {
        var value = data.find(function (d) {
          return d.id === i;
        });

        if (value) {
          orderFields.push(value.orderkey);
        }
      });

      _this.props.changeTableOrder(orderFields, orderType);
    };

    _this.state = {
      visible: false,
      data: [],
      selectedKeys: [],
      orderType: 'desc'
    };
    _this.sessionkey = '';
    return _this;
  }

  _createClass(CustomOrderDialog, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      window.showCustomOrderDialog = function () {
        _this2.setState({
          visible: true
        });
      };

      window.changeSessionKey = function (key) {
        _this2.sessionkey = key;

        _this2.getData();
      };

      window.cleanCustomOrder = function () {
        _this2.setState({
          selectedKeys: []
        });
      };
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var _this$state2 = this.state,
          visible = _this$state2.visible,
          data = _this$state2.data,
          selectedKeys = _this$state2.selectedKeys,
          orderType = _this$state2.orderType;
      return React.createElement("div", null, React.createElement(Modal, {
        title: "\u81EA\u5B9A\u4E49\u6392\u5E8F",
        width: 700,
        visible: visible,
        onOk: this.handleOk,
        onCancel: this.handleCancel
      }, React.createElement(WeaTransfer, {
        data: data,
        selectedKeys: selectedKeys,
        leftHeader: React.createElement("p", {
          style: {
            paddingLeft: 10
          }
        }, "\u5F85\u6392\u5E8F\u5B57\u6BB5"),
        rightHeader: React.createElement("p", {
          style: {
            paddingLeft: 10
          }
        }, "\u6392\u5E8F\u5B57\u6BB5"),
        onChange: function onChange(keys, datas) {
          return _this3.setState({
            selectedKeys: keys
          });
        }
      }), React.createElement("div", {
        style: {
          paddingTop: 10
        }
      }, React.createElement("span", null, "\u6392\u5E8F\u7C7B\u578B\uFF1A"), React.createElement(Select, {
        defaultValue: "desc",
        value: orderType,
        style: {
          width: 120
        },
        onChange: function onChange(v) {
          return _this3.setState({
            orderType: v
          });
        }
      }, React.createElement(Option, {
        value: "desc"
      }, "\u964D\u5E8F"), React.createElement(Option, {
        value: "asc"
      }, "\u5347\u5E8F")))));
    }
  }]);

  return CustomOrderDialog;
}(React.Component);

ecodeSDK.setCom('${appId}', 'CustomOrderDialog', CustomOrderDialog);