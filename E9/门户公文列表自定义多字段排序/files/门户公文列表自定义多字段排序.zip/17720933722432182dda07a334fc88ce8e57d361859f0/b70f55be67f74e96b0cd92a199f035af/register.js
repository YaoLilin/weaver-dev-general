

function isTargetPage(){
  const config = ecodeSDK.getCom('${appId}','config');
  for(const url of config.pageUrls){
    if(location.href.includes(url)){
      return true;
    }
  }
  return false;
}

let count = 0;
/**
 * 传入表格sessionkey，在自定义排序对话框组件中获取列表字段，因为刚开始加载页面时window.changeSessionKey可能不存在（来自自定义排序组件），
 * 所以需要循环判断
 */
function setCustomOrderFields(sessionkey){
  if(!window.changeSessionKey && count < 40){
    window.setTimeout(()=> setCustomOrderFields(sessionkey),100);
    return;
  }else if(count >= 40 && !window.changeSessionKey){
    console.error('无法找到 window.changeSessionKey');
    return;
  }
  count = 0;
  window.changeSessionKey(sessionkey);
}

function cleanCustomOrder(){
    if(window.cleanCustomOrder){
      window.cleanCustomOrder();
    }
    if(window.changeOrderEnable){
      window.changeOrderEnable(false);
    }
    orderFields = [];
}

/**
 * 获取表格sessionKey，自定义排序中获取列表字段
 * @author 姚礼林
 */
ecodeSDK.rewriteApiDataQueueSet({
   fn:(url,params,datas)=>{
    if(url === '/api/odoc/odocCustomPage/getCustomPageList' && isTargetPage()){
      setCustomOrderFields(datas.sessionkey)
    }
    return datas;
  },
  desc:'获取表格sessionKey，自定义排序中获取列表字段'
});

/**
 * 流程待办页面,获取表格sessionKey，自定义排序中获取列表字段
 * @author 姚礼林
 */
ecodeSDK.rewriteApiDataQueueSet({
   fn:(url,params,datas)=>{
    if(url === '/api/workflow/customQuery/getQueryResultKey' && isTargetPage()){
      setCustomOrderFields(datas.sessionkey)
    }
    return datas;
  },
  desc:'获取表格sessionKey，自定义排序中获取列表字段'
});


/**
 * 表格重新加载时清除自定义排序，避免切换到其它列表页面时使用上一个列表的排序
 * @author 姚礼林
 */
ecodeSDK.rewriteApiDataQueueSet({
   fn:(url,params,datas)=>{
    if(url === '/api/workflow/reqlist/splitPageKey' && isTargetPage()){
      cleanCustomOrder();
      // 让自定义排序组件能重新渲染
      isAddCom = false;
    }
    return datas;
  },
  desc:'表格重新加载时清除自定义排序'
});


let orderFields=[];
let orderType = 'desc';
/**
 * 拦截表格数据接口，添加排序参数，实现多字段自定义排序。当表格刷新后会调用此接口
 * @author 姚礼林
 */
ecodeSDK.rewriteApiParamsQueueSet({
  fn: (url, method, params) => {
    try {
      if (url === '/api/ec/dev/table/datas' && isTargetPage()) {
        if (orderFields.length > 0) {
          const sortOrder = orderType === 'desc' ? 'descend' : 'ascend';
          const sortParams = [];
          orderFields.forEach(i => {
            sortParams.push({
              orderkey: i,
              sortOrder
            })
          });
          params.sortParams = JSON.stringify(sortParams);
        }
      }
    } catch (e) {
      console.error('接口拦截出错，自定义排序出错', e);
    }

    return {
      url: url,
      method: method,
      params: params,
    }
  },
  desc: '拦截表格数据接口，实现多字段自定义排序'
});

const CustomOrderDialog = (props) => {
    const params = {
        appId: '${appId}',
        name: 'CustomOrderDialog',
        isPage: false,
        noCss: true,
        props
    }
    const NewCom = props.Com;
    return window.comsMobx ? ecodeSDK.getAsyncCom(params) : (<NewCom {...props}/>);
}

let isAddCom = false;
function addCustomOrderDialogCom(tableStore){
  if(!isAddCom && tableStore){
      console.log('添加组件')
      const div = document.createElement("div");
      document.getElementById('container').appendChild(div);
      ReactDOM.render(<CustomOrderDialog changeTableOrder={(fields,type)=>{
         orderFields = fields;
         orderType = type;
         tableStore.getDatas();
         window.changeOrderEnable(fields.length > 0);
      }}
      />, div);
      isAddCom = true;
  }
}

const CustomOrderButton = (props) => {
    const params = {
        appId: '${appId}',
        name: 'CustomOrderButton',
        isPage: false,
        noCss: true,
        props
    }
    const NewCom = props.Com;
    return window.comsMobx ? ecodeSDK.getAsyncCom(params) : (<NewCom {...props}/>);
}

/**
 * 添加自定义排序按钮
 * @author 姚礼林
 */
ecodeSDK.overwritePropsFnQueueMapSet('WeaTop',{
  fn:(props)=>{
    if(isTargetPage()){
      props.buttons.push(<CustomOrderButton onClick={() => window.showCustomOrderDialog()} />)
    }
  }
});

/**
 * 添加自定义排序组件
 * @author 姚礼林
 */
ecodeSDK.overwritePropsFnQueueMapSet('Table',{
  fn:(props)=>{
    if(isTargetPage()){
      addCustomOrderDialogCom(props.comsWeaTableStore);
    }
  }
});