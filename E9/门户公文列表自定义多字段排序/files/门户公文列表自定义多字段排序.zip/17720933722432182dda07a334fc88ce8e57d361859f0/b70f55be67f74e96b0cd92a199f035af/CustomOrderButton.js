
const {Button} = antd;

/**
 * 自定义排序按钮
 */
class CustomOrderButton extends React.Component{

  constructor(props){
    super(props);
    this.state = {
      orderEnable : false
    }
  }

  componentDidMount(){
    window.changeOrderEnable = (enable)=>{
      this.setState({orderEnable :enable })
    }
  }

  render(){
    const {orderEnable} = this.state;

    return <Button type={'primary'} icon={ orderEnable ? 'check-circle' :''} 
                            onClick={this.props.onClick}>自定义排序</Button>
  }
}

ecodeSDK.setCom('${appId}','CustomOrderButton',CustomOrderButton);
