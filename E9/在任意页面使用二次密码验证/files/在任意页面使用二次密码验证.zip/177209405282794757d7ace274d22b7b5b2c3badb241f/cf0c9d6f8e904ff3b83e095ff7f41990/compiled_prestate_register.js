"use strict";

function isTargetPage() {
  var config = ecodeSDK.getCom('${appId}', 'config');
  var urls = config.urls;
  return urls.some(function (i) {
    return location.href.includes(i) && !location.href.includes('${appId}');
  });
}

function isNeedAuth(callback) {
  var config = ecodeSDK.getCom('${appId}', 'config');
  var searchId = config.searchId,
      noSettingSkip = config.noSettingSkip;
  var _ecCom = ecCom,
      WeaTools = _ecCom.WeaTools;
  var params = {
    mouldCode: 'FORMMODE',
    itemCode: 'PAGE',
    customid: searchId
  };
  WeaTools.callApi('/api/encrypt/secondauthsetting/getSecondAuthForm', 'POST', params).then(function (result) {
    if (noSettingSkip && result.notSetting) {
      callback(false);
    } else {
      callback(!result.token);
    }
  }).catch(function (e) {
    callback(false);
  });
}

function checkAuth() {
  // 判断是否需要二次验证，如果需要则跳到中转页面进行验证
  isNeedAuth(function (result) {
    if (result) {
      console.log('跳到新页面');
      var url = encodeURIComponent(location.href);
      location.replace('/spa/custom/static/index.html#/main/cs/app/cf0c9d6f8e904ff3b83e095ff7f41990_index?url=' + url);
    }
  });
} // 页面载入时触发，判断是否需要二次验证


$(function () {
  if (isTargetPage() && getUrlParam('second_auth') !== '1' && ecCom) {
    checkAuth();
  }
}); // 页面链接发生变化时触发，判断是否需要二次验证

window.addEventListener('popstate', function (event) {
  if (isTargetPage() && ecCom) {
    checkAuth();
  }
}); // 注册新页面

ecodeSDK.rewriteRouteQueue.push({
  fn: function fn(params) {
    var Com = params.Com,
        Route = params.Route,
        nextState = params.nextState;
    params.originalUrl = location.href;
    var cpParams = {
      path: 'main/cs/app',
      //路由地址
      appId: '${appId}',
      name: 'index',
      //具体页面应用id
      node: 'app',
      //渲染的路由节点，这里渲染的是app这个节点
      Route: Route,
      nextState: nextState
    };

    if (ecodeSDK.checkPath(cpParams)) {
      //判断地址是否是要注入的地址
      var acParams = {
        appId: cpParams.appId,
        name: cpParams.name,
        //模块名称
        props: params,
        //参数
        isPage: true,
        //是否是路由页面
        noCss: true //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
        //异步加载模块${appId}下的子模块pageSimple

      };
      return ecodeSDK.getAsyncCom(acParams);
    }

    return null; //这里一定要返回空，不然会干扰到其它新页面
  },
  order: 10,
  desc: '二次验证页面'
});

function getUrlParam(name) {
  var urlString = location.href;
  var hashIndex = urlString.indexOf('#');

  if (hashIndex === -1) {
    return '';
  } else {
    var hashFragment = urlString.substring(hashIndex + 1);
    var hashParams = new URLSearchParams(hashFragment.split('?')[1]);
    return hashParams.get(name);
  }
}