"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var Index =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Index, _React$Component);

  function Index() {
    _classCallCheck(this, Index);

    return _possibleConstructorReturn(this, _getPrototypeOf(Index).apply(this, arguments));
  }

  _createClass(Index, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var config = ecodeSDK.getCom('${appId}', 'config');
      var searchId = config.searchId;
      var originalUrl = decodeURIComponent(this.getUrlParam('url'));
      window.doCheckSecondaryVerify4ec({
        // 对应 /api/encrypt/secondauthsetting/isNeedSecondAuth 接口的参数
        mouldCode: "FORMMODE",
        itemCode: 'PAGE',
        customid: searchId
      }, function (v) {
        // 通过验证（或者不需要验证）后的回调，可以执行继续加载页面等操作
        if (v.status === '-1') {
          // 关闭验证窗口后刷新页面
          location.reload();
          return;
        }

        location.href = originalUrl.includes('?') ? originalUrl + '&second_auth=1' : originalUrl + '?second_auth=1';
      });
    }
  }, {
    key: "getUrlParam",
    value: function getUrlParam(name) {
      var urlString = location.href;
      var hashIndex = urlString.indexOf('#');

      if (hashIndex === -1) {
        return '';
      } else {
        var hashFragment = urlString.substring(hashIndex + 1);
        var hashParams = new URLSearchParams(hashFragment.split('?')[1]);
        return hashParams.get(name);
      }
    }
  }, {
    key: "render",
    value: function render() {
      return React.createElement("div", null, "\u8BF7\u5B8C\u6210\u4E8C\u6B21\u9A8C\u8BC1");
    }
  }]);

  return Index;
}(React.Component);

ecodeSDK.setCom("${appId}", 'index', Index);