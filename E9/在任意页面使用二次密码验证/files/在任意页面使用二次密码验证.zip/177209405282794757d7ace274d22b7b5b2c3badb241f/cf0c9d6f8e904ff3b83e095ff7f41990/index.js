class Index extends React.Component{

  componentDidMount(){
    const config = ecodeSDK.getCom('${appId}','config');
    const {searchId} = config;
    const originalUrl = decodeURIComponent(this.getUrlParam('url'));

     window.doCheckSecondaryVerify4ec({
      // 对应 /api/encrypt/secondauthsetting/isNeedSecondAuth 接口的参数
      mouldCode: "FORMMODE", itemCode: 'PAGE',customid:searchId
    }, (v) => {
      // 通过验证（或者不需要验证）后的回调，可以执行继续加载页面等操作
      if(v.status === '-1'){
        // 关闭验证窗口后刷新页面
        location.reload();
        return;
      }
      location.href = originalUrl.includes('?') ? originalUrl+'&second_auth=1' : originalUrl +'?second_auth=1';
     });
  }

  getUrlParam(name) {
    const urlString = location.href;
    const hashIndex = urlString.indexOf('#');
    if (hashIndex === -1) {
      return '';
    } else {
      const hashFragment = urlString.substring(hashIndex + 1);
      const hashParams = new URLSearchParams(hashFragment.split('?')[1]);
      return hashParams.get(name);
    }
  }

  render(){
    return <div>请完成二次验证</div>
  }
}

ecodeSDK.setCom("${appId}",'index',Index);
