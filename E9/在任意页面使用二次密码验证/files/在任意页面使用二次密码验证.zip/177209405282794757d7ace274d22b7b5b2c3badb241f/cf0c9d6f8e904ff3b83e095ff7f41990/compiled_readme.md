"use strict";

var config = {
  // 需要进行验证的地址片段，不需要完整路径，如果链接中包含此片段则进行身份验证
  urls: ['/main/hrm/addressBook', '/main/document/search'],
  // 建模查询id，即 customid
  searchId: 22
};
ecodeSDK.setCom('${appId}', 'config', config);
