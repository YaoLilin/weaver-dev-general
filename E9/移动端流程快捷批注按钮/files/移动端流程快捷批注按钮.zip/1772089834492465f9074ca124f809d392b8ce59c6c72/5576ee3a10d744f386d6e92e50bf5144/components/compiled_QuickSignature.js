"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _WeaverMobile = WeaverMobile,
    Button = _WeaverMobile.Button;
/**
 * 快捷批注组件，包含一个按钮和显示签名的图片
 */

var QuickSignature =
/*#__PURE__*/
function (_React$Component) {
  _inherits(QuickSignature, _React$Component);

  function QuickSignature(props) {
    var _this;

    _classCallCheck(this, QuickSignature);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(QuickSignature).call(this, props));
    _this.state = {
      imageSrc: window.signImgSrc ? window.signImgSrc : '',
      canSign: false
    };
    return _this;
  }

  _createClass(QuickSignature, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      var canSign = document.querySelector('.sign-bottom-item-remark') !== null;
      this.setState({
        canSign: canSign
      });

      window.onSign = function (fieldId) {
        var imageSrc = 'http://localhost/weaver/weaver.file.FileDownload?fileid=' + fieldId;

        _this2.setState({
          imageSrc: imageSrc
        });
      };

      window.updateSignImageSrc = function (src) {
        _this2.setState({
          imageSrc: src
        });
      };
    }
    /**
     * 通过触发表单上的系统按钮点击事件，打开批注界面
     */

  }, {
    key: "handleClickSign",
    value: function handleClickSign() {
      var comThis = this;
      window.setTimeout(function () {
        $('.sign-bottom-item-remark').click();
        $('.sign-bottom-item-remark').click();
        comThis.clickAddBt();
        $('.wm-signature').children().click();
      }, 10);
    }
  }, {
    key: "clickAddBt",
    value: function clickAddBt() {
      var signActionList = document.querySelector('.sign-action-list');

      if (signActionList) {
        var children = signActionList.children;

        for (var i = 0; i < children.length; i++) {
          var child = children[i];
          var svgElement = child.querySelector('svg.am-icon-tianjia');

          if (svgElement) {
            child.click();
            break;
          }
        }
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var _this$state = this.state,
          imageSrc = _this$state.imageSrc,
          canSign = _this$state.canSign;
      return React.createElement("div", {
        style: {
          display: 'flex'
        }
      }, canSign && React.createElement(Button, {
        style: {
          flex: 1
        },
        onClick: function onClick() {
          return _this3.handleClickSign();
        }
      }, " \u6279\u6CE8 "), imageSrc ? React.createElement("img", {
        src: imageSrc,
        style: {
          maxHeight: 50
        }
      }) : null);
    }
  }]);

  return QuickSignature;
}(React.Component);

ecodeSDK.setCom('${appId}', 'QuickSignature', QuickSignature);
