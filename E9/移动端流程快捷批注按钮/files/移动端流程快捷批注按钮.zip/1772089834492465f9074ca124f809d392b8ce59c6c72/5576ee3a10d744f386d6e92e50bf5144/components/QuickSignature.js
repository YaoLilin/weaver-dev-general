const { Button } = WeaverMobile;

/**
 * 快捷批注组件，包含一个按钮和显示签名的图片
 */
class QuickSignature extends React.Component {
  constructor(props){
    super(props);
    this.state={
      imageSrc : window.signImgSrc ? window.signImgSrc : '',
      canSign : false
    }
  }

  componentDidMount(){
    const canSign = document.querySelector('.sign-bottom-item-remark') !== null;
    this.setState({canSign});
    window.onSign = (fieldId)=>{
      const imageSrc ='http://localhost/weaver/weaver.file.FileDownload?fileid='+fieldId;
      this.setState({imageSrc});
    }
    window.updateSignImageSrc = (src)=>{
      this.setState({imageSrc:src});
    }
  }

  /**
   * 通过触发表单上的系统按钮点击事件，打开批注界面
   */
  handleClickSign() {
    const comThis = this;
    window.setTimeout(() => {
      $('.sign-bottom-item-remark').click();
      $('.sign-bottom-item-remark').click();
      comThis.clickAddBt();
      $('.wm-signature').children().click();
    }, 10)
  }

  clickAddBt() {
    const signActionList = document.querySelector('.sign-action-list');
    if (signActionList) {
      const children = signActionList.children;
      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        const svgElement = child.querySelector('svg.am-icon-tianjia');
        if (svgElement) {
          child.click();
          break; 
        }
      }
    }
  }

  render() {
    const {imageSrc,canSign} = this.state;
    return (
      <div style={{display:'flex'}}>
        {
          canSign && <Button style={{flex:1}} onClick= {()=> this.handleClickSign()} > 批注 < /Button>
        }
        {
          imageSrc ? <img src={imageSrc} style={{maxHeight:50}}/> : null
        }
      </div>
      
    )
  }
}

ecodeSDK.setCom('${appId}', 'QuickSignature', QuickSignature);
