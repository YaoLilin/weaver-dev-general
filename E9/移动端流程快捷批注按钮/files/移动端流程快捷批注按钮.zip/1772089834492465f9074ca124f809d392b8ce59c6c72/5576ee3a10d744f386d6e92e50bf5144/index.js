
// 表单加载快捷批注按钮
var params = {
    domId:'dev-sign-bt', 
    id:'5576ee3a10d744f386d6e92e50bf5144', 
    name:'QuickSignature', 
    cb:function() {
    },
    noCss:true, 
    props:{} 
}
ecodeSDK.render(params);

