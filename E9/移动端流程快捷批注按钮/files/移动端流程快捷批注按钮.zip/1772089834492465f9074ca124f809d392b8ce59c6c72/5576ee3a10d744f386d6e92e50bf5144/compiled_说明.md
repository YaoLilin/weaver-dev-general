"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/**
 * 待办列表添加自定义字段
 * @author 姚礼林
 * @date 2025-02-10
 */
ecodeSDK.overwriteClassFnQueueMapSet('Table', {
  fn: function fn(Com, props) {
    var isTargetPage = location.href.includes('main/workflow/listDoing') || location.href.includes('main/workflow/queryFlowResult');

    if (isTargetPage && props.ecId && (props.ecId.includes('WeaTable@gpscn3') || props.ecId.includes('WeaTable@i3x0ma'))) {
      if (!props._noOverwrite) {
        props.selectedWorkflowId = selectedWorkflowId;
        changeProps(props);
        return {
          com: customTable,
          props: props
        };
      }
    }

    return {
      com: Com,
      props: props
    };
  }
});

function changeProps(props) {
  var config = ecodeSDK.getCom('${appId}', 'config');

  if (!selectedWorkflowId) {
    return;
  }

  var formName = changeTableData(props, config);

  if (!formName) {
    return;
  }

  var workflowConfig = config.workflows.find(function (i) {
    return i.formName === formName;
  });
  addColumns(workflowConfig.fields, props);
}

function changeTableData(props, config) {
  var formName;
  props.datas.forEach(function (i) {
    var requestId = i.subwflink;
    var customFieldData = getCustomFieldData(requestId, i.workflowid, config);

    if (customFieldData) {
      Object.assign(i, customFieldData.fieldData);
      formName = customFieldData.formName;
    }
  });
  return formName;
}

function addColumns(customFields, props) {
  var _newCol;

  if (!props.columns || props.columns.length === 0) {
    return;
  }

  var newCol = [];

  if (customFields) {
    customFields.forEach(function (f) {
      var col = {
        dataIndex: f.fieldName,
        title: f.showName,
        width: f.width ? f.width : '140px'
      };

      if (!f.lineFeed) {
        col.className = 'a4e9220c764247b9a219e7f30196c8c1-nowrap';
      }

      newCol.push(col);
    });
  }

  (_newCol = newCol).push.apply(_newCol, _toConsumableArray(props.columns)); // 不需要显示流程标题


  var removeCols = ['requestlevel', 'creater', 'subwflink', 'receivedate', 'status', 'unoperators', 'workflowid', 'requestmark'];
  newCol = newCol.filter(function (i) {
    return !removeCols.includes(i.dataIndex);
  });
  props.columns = newCol;
}

var cache = new Map();

function getCustomFieldData(requestId, workflowId, config) {
  if (cache.has(workflowId) && !cache.get(workflowId)) {
    return null;
  }

  var _antd = antd,
      message = _antd.message;
  var params = {
    config: config,
    requestId: requestId
  };
  var result;
  $.ajax({
    url: '/api/second-dev/workflow/todo/cus-field-data',
    type: 'post',
    contentType: 'application/json',
    data: JSON.stringify(params),
    async: false,
    success: function success(res) {
      cache.set(workflowId, res.showCustomField);

      if (res.showCustomField) {
        result = {
          fieldData: res.fieldData,
          fields: res.fields,
          formName: res.formName
        };
      }
    },
    error: function error(xhr, status, _error) {
      message.error('获取自定义字段失败');
    }
  });
  return result;
}

var customTable = function customTable(props) {
  var params = {
    appId: '${appId}',
    name: 'CustomTable',
    isPage: false,
    noCss: true,
    props: props
  };
  var NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(params) : React.createElement(NewCom, props);
};

var selectedWorkflowId;
ecodeSDK.rewriteApiParamsQueueSet({
  fn: function fn(url, method, params) {
    if (url.indexOf('api/workflow/reqlist/splitPageKey') !== -1) {
      selectedWorkflowId = params.workflowid;
    }

    return {
      url: url,
      method: method,
      params: params
    };
  },
  desc: '获取待办流程列表的指定流程id'
});
