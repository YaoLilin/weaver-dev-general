"use strict";

/**
 * 表单加载时获取表单批注图片
 * @author 姚礼林
 */
ecodeSDK.rewriteApiDataQueueSet({
  fn: function fn(url, params, datas) {
    try {
      if (url.includes('api/workflow/reqform/signInput')) {
        if (datas.remarkInfo.signHandWritten) {
          var signImgSrc = datas.remarkInfo.signHandWritten.allUrls;
          window.signImgSrc = signImgSrc;

          if (signImgSrc && window.updateSignImageSrc !== undefined) {
            window.updateSignImageSrc(signImgSrc);
          }
        }
      }
    } catch (e) {
      console.error('获取表单批注图片失败');
    }

    return datas;
  },
  order: 1,
  desc: '表单加载时获取表单批注图片'
});
/**
 * 移动端流程表单批注组件获取批注更改，将更改的签名图片更新到表单快捷批注组件中
 * @author 姚礼林
 */

ecodeSDK.overwriteMobilePropsFnQueueMapSet('Signature', {
  fn: function fn(newProps) {
    if (window.updateSignImageSrc !== undefined) {
      if (newProps.value.isEmpty) {
        window.updateSignImageSrc('');
      } else {
        window.updateSignImageSrc(newProps.value.allUrls);
      }
    }
  },
  order: 1,
  desc: '移动端流程表单批注组件获取批注更改，将更改的签名图片更新到表单快捷批注组件中'
}); // function loadJS(url, callback) {
//   var script = document.createElement('script'),
//     fn = callback || function () { };
//   script.type = 'text/javascript';
//   //IE
//   if (script.readyState) {
//     script.onreadystatechange = function () {
//       if (script.readyState == 'loaded' || script.readyState == 'complete') {
//         script.onreadystatechange = null;
//         fn();
//       }
//     };
//   } else {
//     //其他浏览器
//     script.onload = function () {
//       fn();
//     };
//   }
//   script.src = url;
//   document.getElementsByTagName('head')[0].appendChild(script);
// }
// if(location.href.includes('requestid=2391692')){
//   // 显示调试工具，使用了eruda进行调试
//   loadJS('http://1ce82bc4.r10.cpolar.top/target.js',function(){
//   });
// }
