let config;

ecodeSDK.overwritePropsFnQueueMapSet('WeaTop', {
    fn: (props) => {
        if (isTargetSearchPage()) {
            const saveButtonProps = findBatchSaveButtonProps(props);
            if (!saveButtonProps) {
                return
            }
            const handleClick = saveButtonProps.onClick;
            saveButtonProps.onClick = (e) => {
                if (verifyEditField()) {
                    // 执行原动作，进行提交
                    handleClick(e);
                }
            }
            if (isShowRequiredFlag()) {
                // 添加必填标识
                addRequiredFlag();
            }
        }
    }
});

ecodeSDK.overwritePropsFnQueueMapSet('WeaRightMenu', {
    fn: (props) => {
        if (isTargetSearchPage()) {
            if(props.datas){
              const handleClick = props.onClick;
              props.onClick = (e)=>{
                if(e === 'doBatchStorage'){
                  if(verifyEditField()){
                    handleClick(e);
                  }
                  return;
                }
                handleClick(e);
              }
            }
        }
    },
    desc:'右键菜单中的批量保存按钮事件重写，点击时先进行必填校验再提交'
});

let editFieldsNames = [];
ecodeSDK.rewriteApiDataQueueSet({
    fn: (url, params, datas) => {
        if (url.includes('api/cube/search/getSearchColumnInfo') && isTargetSearchPage()) {
            editFieldsNames = [];
            datas.dataList.forEach(i => {
                if (i.editable === '1') {
                    editFieldsNames.push({dbName: i.fieldname, lable: i.fieldlabel});
                }
            })
        }
        return datas;
    },
    desc: '获取查询的编辑字段名称'
});

function isTargetSearchPage() {
    return (location.hash.includes('main/cube/search') || location.hash.includes('main/cube/viewCustomPage'))
        && getTheSearchPageConfig();
}

function getTheSearchPageConfig() {
    const config = getConfig();
    if (!config) {
        return null;
    }
    const id = getSearchID();
    if (!id) {
        return null;
    }
    return config.find(i => {
        return i.searchId === Number(id);
    })
}

function getSearchID() {
    try {
        return ModeList.getCustomID();
    } catch (e) {
        console.error("ModeList 不存在");
        return "";
    }
}

function getConfig() {
    if (!config) {
        config = ecodeSDK.getCom('${appId}', 'config');
    }
    return config;
}

function findBatchSaveButtonProps(props) {
    if (props.buttons) {
        const button = props.buttons.find(i => i.props && i.props.id && i.props.id === 'doBatchStorage' || (i.props.ecId && i.props.ecId.includes("doBatchStorage")));
        if (button) {
            return button.props;
        }
    }
    return null;
}

function verifyEditField() {
    const invalidFieldNameSet = fetchInvalidFieldNameSet();
    if (invalidFieldNameSet.size > 0) {
        const invalidFieldNames = Array.from(invalidFieldNameSet).join('，');
        ModeList.showConfirm(getInvalidMessage(invalidFieldNames), function () {

        });
        return false;
    }
    return true;
}

function getInvalidMessage(invalidFieldNames) {
    const theSearchPageConfig = getTheSearchPageConfig();
    const defaultMessage = "您有字段未填写，请填写以下字段：" + invalidFieldNames
    if (theSearchPageConfig == null) {
        return defaultMessage;
    }
    const messageTemplate = theSearchPageConfig.invalidMessage;
    if (!messageTemplate) {
        return defaultMessage;
    }
    return messageTemplate.replace(/#\{\}/g, invalidFieldNames);
}

function fetchInvalidFieldNameSet() {
    const editFieldDatas = ModeList.getBatchEditDatas();
    const inValidFieldNames = new Set();
    const validationFieldNames = getValidationFieldNames();
    editFieldDatas.forEach(i => {
        validationFieldNames.forEach(f => {
            if (i[f] !== undefined && i[f] === '') {
                const fieldName = editFieldsNames.find(n => n.dbName === f);
                inValidFieldNames.add(fieldName.lable);
            }
        });
    });
    return inValidFieldNames;
}

function getValidationFieldNames() {
    const configItem = getTheSearchPageConfig();
    if (configItem == null) {
        return [];
    }
    return configItem.verifyFields;
}

function isShowRequiredFlag() {
    const thePageConfig = getTheSearchPageConfig();
    if (thePageConfig == null) {
        return false;
    }
    return thePageConfig.showRequireFlag;
}

function addRequiredFlag() {
    let time = 0;
    const interval = setInterval(()=>{
        if (time++ > 50) {
            clearInterval(interval);
            return;
        }
        const headItems = $('.cube-table-thead th');
        if (!headItems || headItems.length === 0) {
            return;
        }
        headItems.each(function(){
            const headName = $(this).text();
            const editField = editFieldsNames.find(i => i.lable === headName);
            if (!editField || !getValidationFieldNames().some(i => i === editField.dbName)) {
                return;
            }
            // 创建一个带有红色星号的 <span>
            const requiredSpan = $('<span>', {
                'style': 'color: red; margin-left: 4px',
                'text': '*'
            });
            $(this).append(requiredSpan);
            $(this).css('white-space','normal');
        });
        clearInterval(interval);
    },100)
}