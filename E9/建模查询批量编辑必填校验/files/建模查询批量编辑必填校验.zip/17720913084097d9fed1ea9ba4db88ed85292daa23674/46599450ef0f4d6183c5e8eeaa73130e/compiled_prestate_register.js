"use strict";

var config;
ecodeSDK.overwritePropsFnQueueMapSet('WeaTop', {
  fn: function fn(props) {
    if (isTargetSearchPage()) {
      var saveButtonProps = findBatchSaveButtonProps(props);

      if (!saveButtonProps) {
        return;
      }

      var handleClick = saveButtonProps.onClick;

      saveButtonProps.onClick = function (e) {
        if (verifyEditField()) {
          // 执行原动作，进行提交
          handleClick(e);
        }
      };

      if (isShowRequiredFlag()) {
        // 添加必填标识
        addRequiredFlag();
      }
    }
  }
});
ecodeSDK.overwritePropsFnQueueMapSet('WeaRightMenu', {
  fn: function fn(props) {
    if (isTargetSearchPage()) {
      if (props.datas) {
        var handleClick = props.onClick;

        props.onClick = function (e) {
          if (e === 'doBatchStorage') {
            if (verifyEditField()) {
              handleClick(e);
            }

            return;
          }

          handleClick(e);
        };
      }
    }
  },
  desc: '右键菜单中的批量保存按钮事件重写，点击时先进行必填校验再提交'
});
var editFieldsNames = [];
ecodeSDK.rewriteApiDataQueueSet({
  fn: function fn(url, params, datas) {
    if (url.includes('api/cube/search/getSearchColumnInfo') && isTargetSearchPage()) {
      editFieldsNames = [];
      datas.dataList.forEach(function (i) {
        if (i.editable === '1') {
          editFieldsNames.push({
            dbName: i.fieldname,
            lable: i.fieldlabel
          });
        }
      });
    }

    return datas;
  },
  desc: '获取查询的编辑字段名称'
});

function isTargetSearchPage() {
  return (location.hash.includes('main/cube/search') || location.hash.includes('main/cube/viewCustomPage')) && getTheSearchPageConfig();
}

function getTheSearchPageConfig() {
  var config = getConfig();

  if (!config) {
    return null;
  }

  var id = getSearchID();

  if (!id) {
    return null;
  }

  return config.find(function (i) {
    return i.searchId === Number(id);
  });
}

function getSearchID() {
  try {
    return ModeList.getCustomID();
  } catch (e) {
    console.error("ModeList 不存在");
    return "";
  }
}

function getConfig() {
  if (!config) {
    config = ecodeSDK.getCom('${appId}', 'config');
  }

  return config;
}

function findBatchSaveButtonProps(props) {
  if (props.buttons) {
    var button = props.buttons.find(function (i) {
      return i.props && i.props.id && i.props.id === 'doBatchStorage' || i.props.ecId && i.props.ecId.includes("doBatchStorage");
    });

    if (button) {
      return button.props;
    }
  }

  return null;
}

function verifyEditField() {
  var invalidFieldNameSet = fetchInvalidFieldNameSet();

  if (invalidFieldNameSet.size > 0) {
    var invalidFieldNames = Array.from(invalidFieldNameSet).join('，');
    ModeList.showConfirm(getInvalidMessage(invalidFieldNames), function () {});
    return false;
  }

  return true;
}

function getInvalidMessage(invalidFieldNames) {
  var theSearchPageConfig = getTheSearchPageConfig();
  var defaultMessage = "您有字段未填写，请填写以下字段：" + invalidFieldNames;

  if (theSearchPageConfig == null) {
    return defaultMessage;
  }

  var messageTemplate = theSearchPageConfig.invalidMessage;

  if (!messageTemplate) {
    return defaultMessage;
  }

  return messageTemplate.replace(/#\{\}/g, invalidFieldNames);
}

function fetchInvalidFieldNameSet() {
  var editFieldDatas = ModeList.getBatchEditDatas();
  var inValidFieldNames = new Set();
  var validationFieldNames = getValidationFieldNames();
  editFieldDatas.forEach(function (i) {
    validationFieldNames.forEach(function (f) {
      if (i[f] !== undefined && i[f] === '') {
        var fieldName = editFieldsNames.find(function (n) {
          return n.dbName === f;
        });
        inValidFieldNames.add(fieldName.lable);
      }
    });
  });
  return inValidFieldNames;
}

function getValidationFieldNames() {
  var configItem = getTheSearchPageConfig();

  if (configItem == null) {
    return [];
  }

  return configItem.verifyFields;
}

function isShowRequiredFlag() {
  var thePageConfig = getTheSearchPageConfig();

  if (thePageConfig == null) {
    return false;
  }

  return thePageConfig.showRequireFlag;
}

function addRequiredFlag() {
  var time = 0;
  var interval = setInterval(function () {
    if (time++ > 50) {
      clearInterval(interval);
      return;
    }

    var headItems = $('.cube-table-thead th');

    if (!headItems || headItems.length === 0) {
      return;
    }

    headItems.each(function () {
      var headName = $(this).text();
      var editField = editFieldsNames.find(function (i) {
        return i.lable === headName;
      });

      if (!editField || !getValidationFieldNames().some(function (i) {
        return i === editField.dbName;
      })) {
        return;
      } // 创建一个带有红色星号的 <span>


      var requiredSpan = $('<span>', {
        'style': 'color: red; margin-left: 4px',
        'text': '*'
      });
      $(this).append(requiredSpan);
      $(this).css('white-space', 'normal');
    });
    clearInterval(interval);
  }, 100);
}