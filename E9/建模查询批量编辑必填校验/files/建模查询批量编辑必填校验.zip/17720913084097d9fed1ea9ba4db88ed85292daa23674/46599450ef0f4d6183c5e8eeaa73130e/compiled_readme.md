"use strict";

var config = [{
  // 查询页面id，customid
  searchId: 10,
  // 必填字段的字段数据库名称
  verifyFields: ['xmgly', 'yfr'],
  // 是否显示必填标识
  showRequireFlag: true,
  // 未填写必填字段时提交的提醒内容，#{}将会被替换成未填写的字段名称
  invalidMessage: '您有字段未填写，请填写以下字段：#{}'
}];
ecodeSDK.setCom('${appId}', 'config', config);