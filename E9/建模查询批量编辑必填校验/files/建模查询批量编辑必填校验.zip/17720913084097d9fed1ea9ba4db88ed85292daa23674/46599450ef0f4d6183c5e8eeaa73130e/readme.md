作者：姚礼林
日期：2024-06-04
需求编号：FW20240603-0167
# 功能说明
可对查询台账的批量编辑字段进行必填校验，如果没有填写必填字段提交时可弹出提示，只对列表的当前页起效，如果后面的页中的字段没有填写，不会进行校验。
![](${appRes}/file_1717491403000.png)
![](${appRes}/file_1717491432000.png)
# 配置说明
编辑 config/config.js 文件
配置示例：
```javascript
const config =[
  {
    // 查询页面id，customid
    searchId : 10,
    // 必填字段的字段数据库名称
    verifyFields:['xmgly','yfr'],
    // 是否显示必填标识
    showRequireFlag:true,
    // 未填写必填字段时提交的提醒内容，#{}将会被替换成未填写的字段名称
    invalidMessage:'您有字段未填写，请填写以下字段：#{}'
  },
  {
   // ...其它查询页面的配置
  }
]
```

