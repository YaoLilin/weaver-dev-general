作者：姚礼林
日期：2024-10-18
# 功能说明
- 门户流程元素支持批量提交
- 可配置到任意一个流程元素
- 可配置到流程元素里的任意标签页
![](${appRes}/file_1729237073000.png)

# 配置说明
编辑 config/config.js 文件
配置示例：
```javascript
const config ={
  canSubmitElements: [
    {
      // 元素id
      eid: '13', 
      // 提交按钮名称
      submitBtName: '提交', 
      // 批量提交按钮名称
      batchSubmitBtName: '批量提交',
      // 提交按钮列的宽度
      submitColWidth:'80px',
      // 如果流程列表元素有标签页，且多个标签页里的列表需要批量提交，或需要批量提交的列表不在第一个标签页当中，
      // 则需要填写 tabIds 属性，值为一个数组，数组里填写标签页id，否则填 null ，如 tabIds:null
      tabIds:[1,3]
    },
    {
      eid: '25', 
      submitBtName: '提交', 
      batchSubmitBtName: '批量提交',
      submitColWidth:'80px',
      tabIds:null
    },
  ]
}
```
canSubmitElements 里可配置多个流程元素，数组里的一个对象表示一个流程元素
## 注意
流程元素需要显示表头，不然不会显示批量提交按钮
![](${appRes}/file_1729240722000.png)
## eid 获取方式
打开流程元素设置，点击小问号就能查看到eid
![](${appRes}/file_1729237429000.png)
![](${appRes}/file_1729237442000.png)
## 标签页id获取方式
将鼠标移动到标签页当中，右键点击检查，在下方的开发者工具中，查看当前元素的上级元素，找到data-tabid，这个就是标签页id
![](${appRes}/file_1729237825000.png)
![](${appRes}/file_1729237871000.png)
或按 f12 打开浏览器开发者工具，点击该按钮审查元素，将鼠标移动到标签页并点击，在下方的开发者工具中，查看当前元素的上级元素，找到data-tabid
![](${appRes}/file_1729237546000.png)
![](${appRes}/file_1729238008000.png)
