
function isSupportBatchSubmit(eid) {
    const config = ecodeSDK.getCom('${appId}', 'config');
    const canSubmitElements = config.canSubmitElements;
    for (let i = 0; i < canSubmitElements.length; i++) {
        const item = canSubmitElements[i];
        if (item.eid === eid) {
            return true;
        }
    }
    return false;
}

function getConfigItem(eid){
    const config = ecodeSDK.getCom('${appId}', 'config');
    return config.canSubmitElements.find(i => i.eid === eid);
}

function getConfigItemByEcId(ecId){
    const config = ecodeSDK.getCom('${appId}', 'config');
    const canSubmitElements = config.canSubmitElements;
    for (let i = 0; i < canSubmitElements.length; i++) {
        const item = canSubmitElements[i];
        if (ecId.indexOf('element-' + item.eid+'_') !== -1) {
            return item;
        }
    }
    return null;
}

let toolBarOption;
/**
 *  获取工具栏的选项，用于调用工具栏的刷新选项来刷新元素
 *  @author 姚礼林
 */
ecodeSDK.rewritePortalCusEleToolbarQueue.push({
    fn: (params) => {
        const {props = {}, options = {}} = params;
        // 检查这个元素是否支持批量提交
        if (isSupportBatchSubmit(options.eid)) {
            toolBarOption = options;
        }
        return null;
    }
});

const currentTabIdMap = new Map();
// 获取元素标签页的参数,获取能够进行批量提交的门户元素的当前标签页id
ecodeSDK.rewritePortalCusEleTabQueue.push({
    fn: (params) => {
        const { props = {}, options = {} } = params;
        currentTabIdMap.set(options.eid, Number(options.tabid));
        return null;
    }
});


/**
 * @desc 门户流程列表元素添加批量提交按钮
 * @author 姚礼林
 */
ecodeSDK.overwriteClassFnQueueMapSet('Table', {
  fn: (Com, props) => {
    try {
      if (!location.href.includes('main/portal/') || !props.ecId || !props.columns || props._noOverwrite){
         return ;
      }
      const configItem = getConfigItemByEcId(props.ecId);
      if (configItem == null) {
        return ;
      }
      const { eid, tabIds, submitBtName, batchSubmitBtName } = configItem;
      props.submitBtName = submitBtName;
      props.batchSubmitBtName = batchSubmitBtName;
      props.eid = eid;
      props.toolbarOptions = toolBarOption;
      console.log('table tabid:' + currentTabIdMap.get(eid));
      const isTargetTab = tabIds == null || tabIds !== null && tabIds.some(i => currentTabIdMap.get(eid) === i);
      if (isTargetTab) {
        return {
          com: newTable,
          props: props,
        }
      }
    } catch (e) {
      console.log('复写table组件出错', e)
    }
  },order:1
});

const newTable = (props) => {
    const acParams = {
        appId: '${appId}',
        name: 'CustomTodoListTable',
        isPage: false,
        noCss: true,
        props: props,
    }
    return ecodeSDK.getAsyncCom(acParams);
}
