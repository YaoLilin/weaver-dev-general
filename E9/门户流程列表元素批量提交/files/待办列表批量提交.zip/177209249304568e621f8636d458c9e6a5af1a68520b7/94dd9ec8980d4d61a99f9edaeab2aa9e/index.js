const {Table, message, Button} = antd;
const {WeaTools} = ecCom;
const SubmitBt = ecodeSDK.imp(SubmitBt);

/**
 * 重写table组件，实现显示领导和批量提交
 */
class NewTable extends React.Component {
    constructor(props) {
        super(props);
        const {
            columns, dataSource, isSupportBatchSubmit, batchSubmitBtName, submitBtName, isAddLeaderCol, toolbarOptions,
            otherToolbarOptions
        } = this.props;
        // submittingItems：批量提交的项目，用于更新按钮状态
        this.state = {
            submittingItems: [],
            columns: columns,
            isBatchSubmitting: false,
            disabled: false
        }

        // 批量提交时返回的结果集合
        this.result = [];
        // 是否在批量提交
        this.isOnBatchSubmit = false;
    }

    componentDidMount() {
        // 清空选择的项目
        selectedKeys = [];

        // 以下都是对原有组件数据进行修改
        const {columns, dataSource, batchSubmitBtName, submitBtName} = this.props;
        const config = this.getConfigItem();
        // 创建提交列
        const submitCol = {
            dataIndex: 'submit',
            key: 'submit',
            title: <Button onClick={() => this.onBatchSubmit()}
                           disabled={this.state.disabled}>
                {batchSubmitBtName}
            < /Button>,
            width: config.submitColWidth,
            render: (text, record) => {
                if (record.requestname === undefined || record.requestname.requestid === undefined) return;
                const requestid = record.requestname.requestid;
                let isLoading = this.state.submittingItems.indexOf(requestid) !== -1;
                return (
                    <SubmitBt isLoading={isLoading}
                              onClick={() => {
                                  this.onClickSubmit(requestid, false)
                              }
                              }
                              name={submitBtName}
                              requestid={requestid}
                              disabled={this.state.disabled}/>
                )
            }
        }
        columns.push(submitCol);
        this.setState({
            columns: columns,
        })
    }

    getConfigItem(){
       const config = ecodeSDK.getCom('${appId}', 'config');
       return config.canSubmitElements.find(i => i.eid === this.props.eid);
    }

    /**
     * 点击批量提交时
     */
    onBatchSubmit() {
        if (selectedKeys.length === 0) {
            message.warning('请选择项目');
            return;
        }
        if (this.state.isBatchSubmitting) {
            message.warning('请等待提交完成');
            return;
        }
        this.setState({isBatchSubmitting: true})
        // 批量提交按钮不能重复点击
        if (this.isOnBatchSubmit) {
            message.warning('请等待批量处理完成');
            return;
        }
        this.isOnBatchSubmit = true;
        // 列表数据
        const data = this.props.dataSource;
        if (data.length === 0 || selectedKeys.length === 0) return;
        const submittingItems = this.state.submittingItems;

        // 添加选中项目到提交序列
        for (let i = 0; i < data.length; i++) {
            // 判断数据的key是否在选中项目中
            if (selectedKeys.includes(data[i].key)) {
                const requestid = data[i].requestname.requestid;
                submittingItems.push(requestid);
            }
        }
        this.setState({
            submittingItems: submittingItems
        })
        // 进行批量提交
        for (let i = 0; i < submittingItems.length; i++) {
            const requestid = submittingItems[i];
            this.onClickSubmit(requestid, true);
        }
    }

    /**
     * 进行提交
     * @param requestid 流程请求id
     * @param isBatch 是否批量提交，如果是点击单个项目的提交按钮，则为false,如果点的是批量提交按钮则为true
     */
    onClickSubmit(requestid, isBatch) {
        this.setState({disabled: true})
        if (!isBatch) {
            const submittingItems = this.state.submittingItems;
            submittingItems.push(requestid);
            this.setState({submittingItems});
        }
        WeaTools.callApi('/api/workflow/paService/submitRequest', 'POST', {requestId: requestid}).then(result => {
            // 不属于批量提交的则提交成功后刷新元素，如果是批量提交则等待所有提交完成后再刷新元素
            if (!this.isOnBatchSubmit) {
                if (!result) {
                    message.error('处理失败');
                    return;
                }
                if (result.code === 'SUCCESS') {
                    message.success('处理成功');
                } else {
                    message.error('提交失败：' + result.code);
                }
                // 刷新元素
                this.refresh();
            } else {
                this.addResult(requestid, result.code === 'SUCCESS');
                // 判断是否全部已完成提交动作
                if (this.result.length === this.state.submittingItems.length) {
                    let isAllSuc = true;
                    this.result.forEach(item => {
                        if (!item.result) {
                            isAllSuc = false;
                        }
                    });
                    if (!isAllSuc) {
                        message.error('部分处理失败');
                    } else {
                        message.success('全部处理成功');
                    }
                    this.refresh();
                }
            }
        });
    }

    /**
     * 刷新元素
     */
    refresh() {
        this.props.toolbarOptions.handleRefresh();
    }

    /**
     * 添加提交结果
     * @param requestId 请求id
     * @param result 结果
     */
    addResult(requestId, result) {
        let resultObj = {requestId: requestId, result: result};
        this.result.push(resultObj);
    }

    render() {
        const columns = this.state.columns;
        const {dataSource, isSupportBatchSubmit, batchSubmitBtName} = this.props;
        if (isSupportBatchSubmit) {
            columns.forEach(i => {
                if (i.key === 'submit') {
                    i.title = <Button onClick={() => this.onBatchSubmit()}
                                      className={'fenzhuan-bt'}
                                      disabled={this.state.disabled}>
                        {batchSubmitBtName}
                    </Button>
                }
            })
        }

        return (<Table columns={columns} _noOverwrite dataSource={dataSource} _noOverwrite pagination={false}
                       showHeader={this.props.showHeader} rowSelection={rowSelection}/>)
    }
}

// 用于设置列表选中时的相关动作
let selectedKeys = [];
const rowSelection = {
    onChange(selectedRowKeys, selectedRows) {
        // 得到选中的key
        selectedKeys = selectedRowKeys;
    }
};

ecodeSDK.setCom('${appId}', 'CustomTodoListTable', NewTable);
