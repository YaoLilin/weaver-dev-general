"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    message = _antd.message,
    Button = _antd.Button;
var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools;
var SubmitBt = ecodeSDK.imp(SubmitBt);
/**
 * 重写table组件，实现显示领导和批量提交
 */

var NewTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewTable, _React$Component);

  function NewTable(props) {
    var _this;

    _classCallCheck(this, NewTable);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(NewTable).call(this, props));
    var _this$props = _this.props,
        columns = _this$props.columns,
        dataSource = _this$props.dataSource,
        isSupportBatchSubmit = _this$props.isSupportBatchSubmit,
        batchSubmitBtName = _this$props.batchSubmitBtName,
        submitBtName = _this$props.submitBtName,
        isAddLeaderCol = _this$props.isAddLeaderCol,
        toolbarOptions = _this$props.toolbarOptions,
        otherToolbarOptions = _this$props.otherToolbarOptions; // submittingItems：批量提交的项目，用于更新按钮状态

    _this.state = {
      submittingItems: [],
      columns: columns,
      isBatchSubmitting: false,
      disabled: false // 批量提交时返回的结果集合

    };
    _this.result = []; // 是否在批量提交

    _this.isOnBatchSubmit = false;
    return _this;
  }

  _createClass(NewTable, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      // 清空选择的项目
      selectedKeys = []; // 以下都是对原有组件数据进行修改

      var _this$props2 = this.props,
          columns = _this$props2.columns,
          dataSource = _this$props2.dataSource,
          batchSubmitBtName = _this$props2.batchSubmitBtName,
          submitBtName = _this$props2.submitBtName;
      var config = this.getConfigItem(); // 创建提交列

      var submitCol = {
        dataIndex: 'submit',
        key: 'submit',
        title: React.createElement(Button, {
          onClick: function onClick() {
            return _this2.onBatchSubmit();
          },
          disabled: this.state.disabled
        }, batchSubmitBtName),
        width: config.submitColWidth,
        render: function render(text, record) {
          if (record.requestname === undefined || record.requestname.requestid === undefined) return;
          var requestid = record.requestname.requestid;
          var isLoading = _this2.state.submittingItems.indexOf(requestid) !== -1;
          return React.createElement(SubmitBt, {
            isLoading: isLoading,
            onClick: function onClick() {
              _this2.onClickSubmit(requestid, false);
            },
            name: submitBtName,
            requestid: requestid,
            disabled: _this2.state.disabled
          });
        }
      };
      columns.push(submitCol);
      this.setState({
        columns: columns
      });
    }
  }, {
    key: "getConfigItem",
    value: function getConfigItem() {
      var _this3 = this;

      var config = ecodeSDK.getCom('${appId}', 'config');
      return config.canSubmitElements.find(function (i) {
        return i.eid === _this3.props.eid;
      });
    }
    /**
     * 点击批量提交时
     */

  }, {
    key: "onBatchSubmit",
    value: function onBatchSubmit() {
      if (selectedKeys.length === 0) {
        message.warning('请选择项目');
        return;
      }

      if (this.state.isBatchSubmitting) {
        message.warning('请等待提交完成');
        return;
      }

      this.setState({
        isBatchSubmitting: true
      }); // 批量提交按钮不能重复点击

      if (this.isOnBatchSubmit) {
        message.warning('请等待批量处理完成');
        return;
      }

      this.isOnBatchSubmit = true; // 列表数据

      var data = this.props.dataSource;
      if (data.length === 0 || selectedKeys.length === 0) return;
      var submittingItems = this.state.submittingItems; // 添加选中项目到提交序列

      for (var i = 0; i < data.length; i++) {
        // 判断数据的key是否在选中项目中
        if (selectedKeys.includes(data[i].key)) {
          var requestid = data[i].requestname.requestid;
          submittingItems.push(requestid);
        }
      }

      this.setState({
        submittingItems: submittingItems
      }); // 进行批量提交

      for (var _i = 0; _i < submittingItems.length; _i++) {
        var _requestid = submittingItems[_i];
        this.onClickSubmit(_requestid, true);
      }
    }
    /**
     * 进行提交
     * @param requestid 流程请求id
     * @param isBatch 是否批量提交，如果是点击单个项目的提交按钮，则为false,如果点的是批量提交按钮则为true
     */

  }, {
    key: "onClickSubmit",
    value: function onClickSubmit(requestid, isBatch) {
      var _this4 = this;

      this.setState({
        disabled: true
      });

      if (!isBatch) {
        var submittingItems = this.state.submittingItems;
        submittingItems.push(requestid);
        this.setState({
          submittingItems: submittingItems
        });
      }

      WeaTools.callApi('/api/workflow/paService/submitRequest', 'POST', {
        requestId: requestid
      }).then(function (result) {
        // 不属于批量提交的则提交成功后刷新元素，如果是批量提交则等待所有提交完成后再刷新元素
        if (!_this4.isOnBatchSubmit) {
          if (!result) {
            message.error('处理失败');
            return;
          }

          if (result.code === 'SUCCESS') {
            message.success('处理成功');
          } else {
            message.error('提交失败：' + result.code);
          } // 刷新元素


          _this4.refresh();
        } else {
          _this4.addResult(requestid, result.code === 'SUCCESS'); // 判断是否全部已完成提交动作


          if (_this4.result.length === _this4.state.submittingItems.length) {
            var isAllSuc = true;

            _this4.result.forEach(function (item) {
              if (!item.result) {
                isAllSuc = false;
              }
            });

            if (!isAllSuc) {
              message.error('部分处理失败');
            } else {
              message.success('全部处理成功');
            }

            _this4.refresh();
          }
        }
      });
    }
    /**
     * 刷新元素
     */

  }, {
    key: "refresh",
    value: function refresh() {
      this.props.toolbarOptions.handleRefresh();
    }
    /**
     * 添加提交结果
     * @param requestId 请求id
     * @param result 结果
     */

  }, {
    key: "addResult",
    value: function addResult(requestId, result) {
      var resultObj = {
        requestId: requestId,
        result: result
      };
      this.result.push(resultObj);
    }
  }, {
    key: "render",
    value: function render() {
      var _this5 = this,
          _React$createElement;

      var columns = this.state.columns;
      var _this$props3 = this.props,
          dataSource = _this$props3.dataSource,
          isSupportBatchSubmit = _this$props3.isSupportBatchSubmit,
          batchSubmitBtName = _this$props3.batchSubmitBtName;

      if (isSupportBatchSubmit) {
        columns.forEach(function (i) {
          if (i.key === 'submit') {
            i.title = React.createElement(Button, {
              onClick: function onClick() {
                return _this5.onBatchSubmit();
              },
              className: 'fenzhuan-bt',
              disabled: _this5.state.disabled
            }, batchSubmitBtName);
          }
        });
      }

      return React.createElement(Table, (_React$createElement = {
        columns: columns,
        _noOverwrite: true,
        dataSource: dataSource
      }, _defineProperty(_React$createElement, "_noOverwrite", true), _defineProperty(_React$createElement, "pagination", false), _defineProperty(_React$createElement, "showHeader", this.props.showHeader), _defineProperty(_React$createElement, "rowSelection", rowSelection), _React$createElement));
    }
  }]);

  return NewTable;
}(React.Component); // 用于设置列表选中时的相关动作


var selectedKeys = [];
var rowSelection = {
  onChange: function onChange(selectedRowKeys, selectedRows) {
    // 得到选中的key
    selectedKeys = selectedRowKeys;
  }
};
ecodeSDK.setCom('${appId}', 'CustomTodoListTable', NewTable);