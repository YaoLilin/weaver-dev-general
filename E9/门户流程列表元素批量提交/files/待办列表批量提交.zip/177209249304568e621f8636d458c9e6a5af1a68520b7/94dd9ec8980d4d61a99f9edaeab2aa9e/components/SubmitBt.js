
const {Button} =antd;
const {WeaTools} = ecCom;

/**
 * 提交按钮
 */
class SubmitBt extends React.Component{
  constructor(props){
    super(props);
    this.state={isLastSecertary : false}
  }

  render(){
    const showText = this.props.name;
    const {isLoading,disabled} = this.props;

    return (
      <Button onClick={this.props.onClick} type={'primary'} size={'small'} loading={isLoading} disabled={disabled}>{showText}</Button>
    )
  }
}

ecodeSDK.exp(SubmitBt);
