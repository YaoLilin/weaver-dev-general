"use strict";

function isSupportBatchSubmit(eid) {
  var config = ecodeSDK.getCom('${appId}', 'config');
  var canSubmitElements = config.canSubmitElements;

  for (var i = 0; i < canSubmitElements.length; i++) {
    var item = canSubmitElements[i];

    if (item.eid === eid) {
      return true;
    }
  }

  return false;
}

function getConfigItem(eid) {
  var config = ecodeSDK.getCom('${appId}', 'config');
  return config.canSubmitElements.find(function (i) {
    return i.eid === eid;
  });
}

function getConfigItemByEcId(ecId) {
  var config = ecodeSDK.getCom('${appId}', 'config');
  var canSubmitElements = config.canSubmitElements;

  for (var i = 0; i < canSubmitElements.length; i++) {
    var item = canSubmitElements[i];

    if (ecId.indexOf('element-' + item.eid + '_') !== -1) {
      return item;
    }
  }

  return null;
}

var toolBarOption;
/**
 *  获取工具栏的选项，用于调用工具栏的刷新选项来刷新元素
 *  @author 姚礼林
 */

ecodeSDK.rewritePortalCusEleToolbarQueue.push({
  fn: function fn(params) {
    var _params$props = params.props,
        props = _params$props === void 0 ? {} : _params$props,
        _params$options = params.options,
        options = _params$options === void 0 ? {} : _params$options; // 检查这个元素是否支持批量提交

    if (isSupportBatchSubmit(options.eid)) {
      toolBarOption = options;
    }

    return null;
  }
});
var currentTabIdMap = new Map(); // 获取元素标签页的参数,获取能够进行批量提交的门户元素的当前标签页id

ecodeSDK.rewritePortalCusEleTabQueue.push({
  fn: function fn(params) {
    var _params$props2 = params.props,
        props = _params$props2 === void 0 ? {} : _params$props2,
        _params$options2 = params.options,
        options = _params$options2 === void 0 ? {} : _params$options2;
    currentTabIdMap.set(options.eid, Number(options.tabid));
    return null;
  }
});
/**
 * @desc 门户流程列表元素添加批量提交按钮
 * @author 姚礼林
 */

ecodeSDK.overwriteClassFnQueueMapSet('Table', {
  fn: function fn(Com, props) {
    try {
      if (!location.href.includes('main/portal/') || !props.ecId || !props.columns || props._noOverwrite) {
        return;
      }

      var configItem = getConfigItemByEcId(props.ecId);

      if (configItem == null) {
        return;
      }

      var eid = configItem.eid,
          tabIds = configItem.tabIds,
          submitBtName = configItem.submitBtName,
          batchSubmitBtName = configItem.batchSubmitBtName;
      props.submitBtName = submitBtName;
      props.batchSubmitBtName = batchSubmitBtName;
      props.eid = eid;
      props.toolbarOptions = toolBarOption;
      console.log('table tabid:' + currentTabIdMap.get(eid));
      var isTargetTab = tabIds == null || tabIds !== null && tabIds.some(function (i) {
        return currentTabIdMap.get(eid) === i;
      });

      if (isTargetTab) {
        return {
          com: newTable,
          props: props
        };
      }
    } catch (e) {
      console.log('复写table组件出错', e);
    }
  },
  order: 1
});

var newTable = function newTable(props) {
  var acParams = {
    appId: '${appId}',
    name: 'CustomTodoListTable',
    isPage: false,
    noCss: true,
    props: props
  };
  return ecodeSDK.getAsyncCom(acParams);
};