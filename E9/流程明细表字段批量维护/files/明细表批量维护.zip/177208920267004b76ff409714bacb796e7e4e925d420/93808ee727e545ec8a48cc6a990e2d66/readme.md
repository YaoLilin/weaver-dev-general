作者：姚礼林

#功能说明
可批量编辑明细字段
批量编辑字段支持文本框、日期、建模浏览框类型
![](${appRes}/file_1706253880000.png)
![](${appRes}/file_1706253911000.png)
#配置说明
- 在流程中插入以下代码
```javaScript
const fields =[
    {
      name:'物料组编号',
      dbName:'wlzbh',
      type:'browser',
      browserType:'browser.prwlzbh_wlzbh',
      browserTitle:'物料组编号',
      conditionField:'zclb'
    }
  ]
  var params = {
    domId:'batch-edit', //渲染位置的domId，也就是表单上创建的
    id:'93808ee727e545ec8a48cc6a990e2d66', //appId，也就是根目录的UUID，发布ID
    name:'batchEdit', //调用的组件名字，setCom时定义的
    cb:function() { //渲染完成回调
     },
    noCss:true, //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
    props:{fields,detailName:'detail_1'} //表单的参数传入组件的方法
}
// 在渲染组件
ecodeSDK.render(params);
```
- 上面代码中需要配置fields 和 detailName ，fields是配置需要批量编辑的字段，detailName是需要批量编辑的明细的明细名称，上面代码只支持一个明细批量编辑，如需多个可以复制几份上面的代码，改一下配置
- 以下是fields的参数说明
	- name ：字段中文名
	- dbName ：字段数据库名
	- type：字段类型，文本框：input，日期：date，建模浏览框：browser
	- browserType ：如果字段类型为建模浏览框，需要配置此字段，配置为''browser."加建模浏览框的名称，建模浏览框名称可在表单字段设置中查看
	- browserTitle ：如果字段类型为建模浏览框，需要配置此字段，配置浏览对话框的标题，一般为字段中文名就行了
	- conditionField ：如果字段类型为建模浏览框，并且该浏览框使用了表单字段作为查询条件，需要配置此字段，配置作为查询条件的表单字段的字段数据库名
- 以下是一个fields的配置例子
```javaScript
const fields =[
    {
      name:'申请类型',
      dbName:'sqlx',
      type:'input'
    },
    {
      name:'是否冻结',
      dbName:'SFDJ',
      type:'input'
    },
    {
      name:'物料分类',
      dbName:'WLFL1',
      type:'input'
    },
     {
      name:'物料编码',
      dbName:'WLBM',
      type:'input'
    }
]
```
- 需要在明细上方的单元格中设置一个id，用来渲染此组件，id为 batch-edit
![](${appRes}/file_1706255048000.png)
![](${appRes}/file_1706255085000.png)



