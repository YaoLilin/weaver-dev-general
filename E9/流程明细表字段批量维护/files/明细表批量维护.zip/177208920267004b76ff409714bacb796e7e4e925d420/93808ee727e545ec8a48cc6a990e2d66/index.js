const {Button,Modal,Col,Row,message} = antd;
const {WeaSlideModal,WeaBrowser,WeaInput,WeaFormItem,WeaDatePicker} = ecCom;
const SupplierTable = ecodeSDK.imp(SupplierTable);


const FIELD_TYPE = {
    INPUT:'input',
    BROWSER:'browser',
    DATE:'date'
}

/**
 * @author 姚礼林
 */
class BatchChangeDialog extends React.Component{
    constructor(props){
        super(props);
        this.state={
            visible :false,
            data:[],
            loading:false
        }
        const {fields,detailName} = this.props;
        // 存储对话框中的字段数据
        this.fieldData = new Map();
    }

    cleanFieldData(){
        this.fieldData = new Map();
    }

    handleOk= ()=>{
        this.batchChange();
    }

    handleCancel = ()=>{
        this.setState({visible:false});
    }

    // 批量更新明细数据
    batchChange(){
        const {fields,detailName} = this.props;
        this.setState({loading:true});
        window.setTimeout(()=>{
            const indexs = WfForm.getDetailAllRowIndexStr(detailName).split(",");
            const selectedItems = WfForm.getDetailCheckedRowIndexStr(detailName).split(',').filter(i => i!=='');

            // 遍历对话框里的字段数据
            fields.forEach(item => {
                // 遍历明细数据，批量更新
                for (let i = 0; i < indexs.length; i++) {
                    // 没选中的数据不更新
                    if(selectedItems.indexOf(indexs[i]) === -1){
                      continue;
                    }
                    if (!this.fieldData.get(item.dbName)) continue;
                    const valueItem = this.fieldData.get(item.dbName);
                    if (valueItem.value === '') return;
                    if (valueItem.type === FIELD_TYPE.BROWSER){
                      // 为浏览框需要赋值显示名
                        WfForm.changeFieldValue(WfForm.convertFieldNameToId(item.dbName, detailName) + '_' + indexs[i],
                            { value: valueItem.value, specialobj: [{ id: valueItem.value, name: valueItem.showName }] });
                    }else{
                      WfForm.changeFieldValue(WfForm.convertFieldNameToId(item.dbName, detailName) + '_' + indexs[i],
                            { value: valueItem.value});
                    }
                }
            })
            this.setState({loading:false});
            this.setState({visible:false});
        },20);
    }

    onFieldChange(value,showName,fieldType,fieldDbName){
        let valueItem = this.fieldData.get(fieldDbName);
        if (!valueItem){
            valueItem={
                value,type:fieldType,dbName:fieldDbName
            }
        }
        valueItem.value = value;
        if (fieldType === FIELD_TYPE.BROWSER){
            valueItem.showName = showName;
        }
        this.fieldData.set(fieldDbName,valueItem);
    }

    // 渲染字段
    getFieldElement(fieldName,fieldType,browserType,browserTitle,fieldDbName,conditionField){
        if (fieldType === FIELD_TYPE.INPUT){
            // 渲染文本输入框字段
            return (
                <Col span={6}>
                    <WeaFormItem label={fieldName} labelCol={{span: 10}}
                                 wrapperCol={{span: 14}}
                                 style={{padding: '10px'}}>
                        <WeaInput onChange={(v)=>{
                            this.onFieldChange(v,null,fieldType,fieldDbName)
                        }}/>
                    </WeaFormItem>
                </Col>
            )
        }else if(fieldType === FIELD_TYPE.DATE){
          return <Col span={6}>
                    <WeaFormItem label={fieldName} labelCol={{span: 10}}
                                 wrapperCol={{span: 14}}
                                 style={{padding: '10px'}}>
                        <WeaDatePicker onChange={(v)=>{
                            this.onFieldChange(v,null,fieldType,fieldDbName)
                        }}/>
                    </WeaFormItem>
                </Col>
        }else if (fieldType === FIELD_TYPE.BROWSER) {
            const time = new Date().getTime();
            const otherParams ={};
            if(conditionField){
              otherParams[conditionField+'_'+time] = WfForm.getFieldValue(WfForm.convertFieldNameToId(conditionField));
            }
            
            // 渲染浏览框字段
            return (
              <Col span={6}>
                <WeaFormItem
                    label={fieldName}
                    labelCol={{span: 10}}
                    wrapperCol={{span: 14}}
                    style={{padding: '10px'}}>
                    <WeaBrowser
                        style={{lineHeight: '30px'}}
                        type={161}
                        title={browserTitle}
                        viewAttr={2}
                        displaySearchAd={true}
                        hasAdvanceSerach={true}
                        displaySearchAdInBar={true}
                        dataParams={{
                            type: browserType,
                            fielddbtype: browserType,
                            ...otherParams
                        }}
                        conditionDataParams={{
                            type: browserType,
                            fielddbtype: browserType,
                            disabledConditionCache: true,
                            fromModule: 'workflow',
                            viewtype: '1',
                        }}
                        completeParams={{
                            type: browserType,
                            fielddbtype: browserType,
                            disabledConditionCache: true,
                            fromModule: 'workflow',
                            viewtype: '1',
                        }}
                        dataURL='/api/public/browser/data/161'
                        onChange={(ids, names, datas) => {
                            this.onFieldChange(ids,names,fieldType,fieldDbName)
                        }}
                    />
                </WeaFormItem>
                </Col>
            )
        }
    }

    render(){
        const {fields,detailName} = this.props;
        return(
            <>
                <Button size={'small'} style={{color:'white'}} onClick={()=> {
                    const checked = WfForm.getDetailCheckedRowIndexStr(detailName);
                    if(!checked){
                      message.error('请勾选明细数据',5);
                      return
                    }
                    this.setState({visible:true});
                    // 每次弹出对话框时都要清空对话框中的字段数据
                    this.cleanFieldData();
                }
                }>批量编辑</Button>
                <Modal title="批量编辑" visible={this.state.visible} onCancel={this.handleCancel}
                       onOk={this.handleOk}
                       width={'1200px'}
                       confirmLoading={this.state.loading}
                >
                    <div>
                      <Row>
                        {
                            fields.map ( (item,index) =>{
                                return this.getFieldElement(item.name,item.type,item.browserType,item.browserTitle,item.dbName,item.conditionField)
                            })
                        }
                      </Row>
                    </div>
                </Modal>
            </>
        )
    }
}

ecodeSDK.setCom('${appId}','batchEdit',BatchChangeDialog)
