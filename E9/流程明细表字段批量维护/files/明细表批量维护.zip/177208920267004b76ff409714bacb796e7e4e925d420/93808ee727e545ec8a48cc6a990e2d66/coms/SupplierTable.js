const {Table,Input} = antd;
const {WeaBrowser, WeaSelect, WeaFormItem} = ecCom;

class SupplierTable extends React.Component {

    constructor(props) {
        super(props);
    }

    isRepeat(index, value) {
        let isExist = false;
        this.props.data.forEach(item => {
            if (value && item === value) {
                isExist = true;
            }
        });
        return isExist;
    }

    render() {
        const attr = this.props.isEdit ? 2 : 1;
        const {data, onChange, index: rowIndex,isLimitValue} = this.props;
        const options=[
          {
            key: "0",
            selected: false,
            showname: "否"
          },
          {
            key: "1",
            selected: false,
            showname: "是"
          },
        ]
        return (
            <div style={{overflow: 'scroll'}}>
                <WeaFormItem
                    label={"车型"}
                    labelCol={{span: 6}}
                    wrapperCol={{span: 18}}
                    style={{width: '50%', padding: '10px'}}>
                    <WeaBrowser
                        style={{lineHeight: '30px'}}
                        type={161}
                        title="车型"
                        viewAttr={attr}
                        displaySearchAd={true}
                        hasAdvanceSerach={true}
                        displaySearchAdInBar={true}
                        value={this.props.cx}
                        valueSpan={this.props.cxShowName}
                        dataParams={{
                            type: 'browser.cx_dxxlk',
                            fielddbtype: 'browser.cx_dxxlk',
                        }}
                        conditionDataParams={{
                            type: 'browser.cx_dxxlk',
                            fielddbtype: 'browser.cx_dxxlk',
                            disabledConditionCache: true,
                            fromModule: 'workflow',
                            viewtype: '1',
                        }}
                        dataURL='/api/public/browser/data/161'
                        onChange={(ids, names, datas) => {
                            WfForm.changeFieldValue(WfForm.convertFieldNameToId('cxllk', 'detail_1') + '_' + this.props.index, {
                                value: ids,
                                specialobj: [{id: ids, name: names}]
                            });
                        }}
                    />
                </WeaFormItem>
                <WeaFormItem
                    label={"零件所属总成"}
                    labelCol={{span: 6}}
                    wrapperCol={{span: 18}}
                    style={{width: '50%', padding: '10px'}}>
                    <WeaInput value={this.props.ljsszc} viewAttr={attr} onChange={(v) => {
                        WfForm.changeFieldValue(WfForm.convertFieldNameToId('ljsszc', 'detail_1') + '_' + this.props.index, {value: v})
                    }}/>
                </WeaFormItem>
                <WeaFormItem
                    label={"分包号"}
                    labelCol={{span: 6}}
                    wrapperCol={{span: 18}}
                    style={{width: '50%', padding: '10px'}}>
                    <WeaInput value={this.props.fbh} viewAttr={attr} onChange={(v) => {
                        WfForm.changeFieldValue(WfForm.convertFieldNameToId('fbh', 'detail_1') + '_' + this.props.index, {value: v})
                    }}/>
                </WeaFormItem>
                <WeaFormItem
                    label={"零件图号"}
                    labelCol={{span: 6}}
                    wrapperCol={{span: 18}}
                    style={{width: '50%', padding: '10px'}}>
                    <WeaInput value={this.props.ljth} viewAttr={attr} onChange={(v) => {
                        WfForm.changeFieldValue(WfForm.convertFieldNameToId('ljth', 'detail_1') + '_' + this.props.index, {value: v})
                    }}/>
                </WeaFormItem>
                <WeaFormItem
                    label={"零件名称"}
                    labelCol={{span: 6}}
                    wrapperCol={{span: 18}}
                    style={{width: '50%', padding: '10px'}}>
                    <WeaInput value={this.props.ljmc} viewAttr={attr} onChange={(v) => {
                        WfForm.changeFieldValue(WfForm.convertFieldNameToId('ljmc', 'detail_1') + '_' + this.props.index, {value: v})
                    }}/>
                </WeaFormItem>
                {
                    data.map((item, index) => {
                        console.log('item:' + item);
                        return (
                          <div style={{display:'flex'}}>
                            <WeaFormItem
                                key={index}
                                label={"入围供应商" + (index + 1)}
                                labelCol={{span: 6}}
                                wrapperCol={{span: 18}}
                                style={{width: '50%', padding: '10px'}}>
                                <WeaBrowser
                                    key={index}
                                    style={{lineHeight: '30px'}}
                                    type={161}
                                    title="供应商编码"
                                    viewAttr={attr}
                                    displaySearchAd={true}
                                    hasAdvanceSerach={true}
                                    displaySearchAdInBar={true}
                                    value={item}
                                    valueSpan={this.props.showName[index]}
                                    dataParams={{
                                        type: 'browser.qzhggys',
                                        fielddbtype: 'browser.qzhggys',
                                    }}
                                    conditionDataParams={{
                                        type: 'browser.qzhggys',
                                        fielddbtype: 'browser.qzhggys',
                                        disabledConditionCache: true,
                                        fromModule: 'workflow',
                                        viewtype: '1',
                                    }}
                                    dataURL='/api/public/browser/data/161'
                                    onChange={(ids, names, datas) => {
                                        if(this.isRepeat(index,ids)){
                                          this.props.onChange(index,'','');
                                          WfForm.showMessage("供应商不允许重复", 2, 3);
                                        }
                                        WfForm.changeFieldValue(WfForm.convertFieldNameToId(this.props.fieldNames[index], 'detail_1') + '_' + rowIndex, {
                                            value: ids,
                                            specialobj: [{id: ids, name: names}]
                                        });
                                    }}
                                />
                            </WeaFormItem>
                             <WeaFormItem
                                key={index}
                                label={"限制新业务"}
                                labelCol={{span: 6}}
                                wrapperCol={{span: 18}}
                                style={{width: '50%', padding: '10px'}}>
                                    <WeaSelect
                                      hasBorder
                                      options={options}
                                      value={isLimitValue[index]}
                                      viewAttr={1}
                                    />
                            </WeaFormItem>
                            </div>
                        )
                    })
                }
            </div>
        )
    }
}

ecodeSDK.exp(SupplierTable);
