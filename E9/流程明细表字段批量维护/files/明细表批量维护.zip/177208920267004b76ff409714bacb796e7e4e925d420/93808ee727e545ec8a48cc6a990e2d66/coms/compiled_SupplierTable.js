"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Table = _antd.Table,
    Input = _antd.Input;
var _ecCom = ecCom,
    WeaBrowser = _ecCom.WeaBrowser,
    WeaSelect = _ecCom.WeaSelect,
    WeaFormItem = _ecCom.WeaFormItem;

var SupplierTable =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SupplierTable, _React$Component);

  function SupplierTable(props) {
    _classCallCheck(this, SupplierTable);

    return _possibleConstructorReturn(this, _getPrototypeOf(SupplierTable).call(this, props));
  }

  _createClass(SupplierTable, [{
    key: "isRepeat",
    value: function isRepeat(index, value) {
      var isExist = false;
      this.props.data.forEach(function (item) {
        if (value && item === value) {
          isExist = true;
        }
      });
      return isExist;
    }
  }, {
    key: "render",
    value: function render() {
      var _this = this;

      var attr = this.props.isEdit ? 2 : 1;
      var _this$props = this.props,
          data = _this$props.data,
          onChange = _this$props.onChange,
          rowIndex = _this$props.index,
          isLimitValue = _this$props.isLimitValue;
      var options = [{
        key: "0",
        selected: false,
        showname: "否"
      }, {
        key: "1",
        selected: false,
        showname: "是"
      }];
      return React.createElement("div", {
        style: {
          overflow: 'scroll'
        }
      }, React.createElement(WeaFormItem, {
        label: "车型",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        style: {
          width: '50%',
          padding: '10px'
        }
      }, React.createElement(WeaBrowser, {
        style: {
          lineHeight: '30px'
        },
        type: 161,
        title: "\u8F66\u578B",
        viewAttr: attr,
        displaySearchAd: true,
        hasAdvanceSerach: true,
        displaySearchAdInBar: true,
        value: this.props.cx,
        valueSpan: this.props.cxShowName,
        dataParams: {
          type: 'browser.cx_dxxlk',
          fielddbtype: 'browser.cx_dxxlk'
        },
        conditionDataParams: {
          type: 'browser.cx_dxxlk',
          fielddbtype: 'browser.cx_dxxlk',
          disabledConditionCache: true,
          fromModule: 'workflow',
          viewtype: '1'
        },
        dataURL: "/api/public/browser/data/161",
        onChange: function onChange(ids, names, datas) {
          WfForm.changeFieldValue(WfForm.convertFieldNameToId('cxllk', 'detail_1') + '_' + _this.props.index, {
            value: ids,
            specialobj: [{
              id: ids,
              name: names
            }]
          });
        }
      })), React.createElement(WeaFormItem, {
        label: "零件所属总成",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        style: {
          width: '50%',
          padding: '10px'
        }
      }, React.createElement(WeaInput, {
        value: this.props.ljsszc,
        viewAttr: attr,
        onChange: function onChange(v) {
          WfForm.changeFieldValue(WfForm.convertFieldNameToId('ljsszc', 'detail_1') + '_' + _this.props.index, {
            value: v
          });
        }
      })), React.createElement(WeaFormItem, {
        label: "分包号",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        style: {
          width: '50%',
          padding: '10px'
        }
      }, React.createElement(WeaInput, {
        value: this.props.fbh,
        viewAttr: attr,
        onChange: function onChange(v) {
          WfForm.changeFieldValue(WfForm.convertFieldNameToId('fbh', 'detail_1') + '_' + _this.props.index, {
            value: v
          });
        }
      })), React.createElement(WeaFormItem, {
        label: "零件图号",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        style: {
          width: '50%',
          padding: '10px'
        }
      }, React.createElement(WeaInput, {
        value: this.props.ljth,
        viewAttr: attr,
        onChange: function onChange(v) {
          WfForm.changeFieldValue(WfForm.convertFieldNameToId('ljth', 'detail_1') + '_' + _this.props.index, {
            value: v
          });
        }
      })), React.createElement(WeaFormItem, {
        label: "零件名称",
        labelCol: {
          span: 6
        },
        wrapperCol: {
          span: 18
        },
        style: {
          width: '50%',
          padding: '10px'
        }
      }, React.createElement(WeaInput, {
        value: this.props.ljmc,
        viewAttr: attr,
        onChange: function onChange(v) {
          WfForm.changeFieldValue(WfForm.convertFieldNameToId('ljmc', 'detail_1') + '_' + _this.props.index, {
            value: v
          });
        }
      })), data.map(function (item, index) {
        console.log('item:' + item);
        return React.createElement("div", {
          style: {
            display: 'flex'
          }
        }, React.createElement(WeaFormItem, {
          key: index,
          label: "入围供应商" + (index + 1),
          labelCol: {
            span: 6
          },
          wrapperCol: {
            span: 18
          },
          style: {
            width: '50%',
            padding: '10px'
          }
        }, React.createElement(WeaBrowser, {
          key: index,
          style: {
            lineHeight: '30px'
          },
          type: 161,
          title: "\u4F9B\u5E94\u5546\u7F16\u7801",
          viewAttr: attr,
          displaySearchAd: true,
          hasAdvanceSerach: true,
          displaySearchAdInBar: true,
          value: item,
          valueSpan: _this.props.showName[index],
          dataParams: {
            type: 'browser.qzhggys',
            fielddbtype: 'browser.qzhggys'
          },
          conditionDataParams: {
            type: 'browser.qzhggys',
            fielddbtype: 'browser.qzhggys',
            disabledConditionCache: true,
            fromModule: 'workflow',
            viewtype: '1'
          },
          dataURL: "/api/public/browser/data/161",
          onChange: function onChange(ids, names, datas) {
            if (_this.isRepeat(index, ids)) {
              _this.props.onChange(index, '', '');

              WfForm.showMessage("供应商不允许重复", 2, 3);
            }

            WfForm.changeFieldValue(WfForm.convertFieldNameToId(_this.props.fieldNames[index], 'detail_1') + '_' + rowIndex, {
              value: ids,
              specialobj: [{
                id: ids,
                name: names
              }]
            });
          }
        })), React.createElement(WeaFormItem, {
          key: index,
          label: "限制新业务",
          labelCol: {
            span: 6
          },
          wrapperCol: {
            span: 18
          },
          style: {
            width: '50%',
            padding: '10px'
          }
        }, React.createElement(WeaSelect, {
          hasBorder: true,
          options: options,
          value: isLimitValue[index],
          viewAttr: 1
        })));
      }));
    }
  }]);

  return SupplierTable;
}(React.Component);

ecodeSDK.exp(SupplierTable);
