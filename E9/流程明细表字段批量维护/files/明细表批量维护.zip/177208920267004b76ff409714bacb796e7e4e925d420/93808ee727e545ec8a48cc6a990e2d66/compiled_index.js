"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Button = _antd.Button,
    Modal = _antd.Modal,
    Col = _antd.Col,
    Row = _antd.Row,
    message = _antd.message;
var _ecCom = ecCom,
    WeaSlideModal = _ecCom.WeaSlideModal,
    WeaBrowser = _ecCom.WeaBrowser,
    WeaInput = _ecCom.WeaInput,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaDatePicker = _ecCom.WeaDatePicker;
var SupplierTable = ecodeSDK.imp(SupplierTable);
var FIELD_TYPE = {
  INPUT: 'input',
  BROWSER: 'browser',
  DATE: 'date'
  /**
   * @author 姚礼林
   */

};

var BatchChangeDialog =
/*#__PURE__*/
function (_React$Component) {
  _inherits(BatchChangeDialog, _React$Component);

  function BatchChangeDialog(props) {
    var _this;

    _classCallCheck(this, BatchChangeDialog);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(BatchChangeDialog).call(this, props));

    _this.handleOk = function () {
      _this.batchChange();
    };

    _this.handleCancel = function () {
      _this.setState({
        visible: false
      });
    };

    _this.state = {
      visible: false,
      data: [],
      loading: false
    };
    var _this$props = _this.props,
        fields = _this$props.fields,
        detailName = _this$props.detailName; // 存储对话框中的字段数据

    _this.fieldData = new Map();
    return _this;
  }

  _createClass(BatchChangeDialog, [{
    key: "cleanFieldData",
    value: function cleanFieldData() {
      this.fieldData = new Map();
    }
  }, {
    key: "batchChange",
    // 批量更新明细数据
    value: function batchChange() {
      var _this2 = this;

      var _this$props2 = this.props,
          fields = _this$props2.fields,
          detailName = _this$props2.detailName;
      this.setState({
        loading: true
      });
      window.setTimeout(function () {
        var indexs = WfForm.getDetailAllRowIndexStr(detailName).split(",");
        var selectedItems = WfForm.getDetailCheckedRowIndexStr(detailName).split(',').filter(function (i) {
          return i !== '';
        }); // 遍历对话框里的字段数据

        fields.forEach(function (item) {
          // 遍历明细数据，批量更新
          for (var i = 0; i < indexs.length; i++) {
            // 没选中的数据不更新
            if (selectedItems.indexOf(indexs[i]) === -1) {
              continue;
            }

            if (!_this2.fieldData.get(item.dbName)) continue;

            var valueItem = _this2.fieldData.get(item.dbName);

            if (valueItem.value === '') return;

            if (valueItem.type === FIELD_TYPE.BROWSER) {
              // 为浏览框需要赋值显示名
              WfForm.changeFieldValue(WfForm.convertFieldNameToId(item.dbName, detailName) + '_' + indexs[i], {
                value: valueItem.value,
                specialobj: [{
                  id: valueItem.value,
                  name: valueItem.showName
                }]
              });
            } else {
              WfForm.changeFieldValue(WfForm.convertFieldNameToId(item.dbName, detailName) + '_' + indexs[i], {
                value: valueItem.value
              });
            }
          }
        });

        _this2.setState({
          loading: false
        });

        _this2.setState({
          visible: false
        });
      }, 20);
    }
  }, {
    key: "onFieldChange",
    value: function onFieldChange(value, showName, fieldType, fieldDbName) {
      var valueItem = this.fieldData.get(fieldDbName);

      if (!valueItem) {
        valueItem = {
          value: value,
          type: fieldType,
          dbName: fieldDbName
        };
      }

      valueItem.value = value;

      if (fieldType === FIELD_TYPE.BROWSER) {
        valueItem.showName = showName;
      }

      this.fieldData.set(fieldDbName, valueItem);
    } // 渲染字段

  }, {
    key: "getFieldElement",
    value: function getFieldElement(fieldName, fieldType, browserType, browserTitle, fieldDbName, conditionField) {
      var _this3 = this;

      if (fieldType === FIELD_TYPE.INPUT) {
        // 渲染文本输入框字段
        return React.createElement(Col, {
          span: 6
        }, React.createElement(WeaFormItem, {
          label: fieldName,
          labelCol: {
            span: 10
          },
          wrapperCol: {
            span: 14
          },
          style: {
            padding: '10px'
          }
        }, React.createElement(WeaInput, {
          onChange: function onChange(v) {
            _this3.onFieldChange(v, null, fieldType, fieldDbName);
          }
        })));
      } else if (fieldType === FIELD_TYPE.DATE) {
        return React.createElement(Col, {
          span: 6
        }, React.createElement(WeaFormItem, {
          label: fieldName,
          labelCol: {
            span: 10
          },
          wrapperCol: {
            span: 14
          },
          style: {
            padding: '10px'
          }
        }, React.createElement(WeaDatePicker, {
          onChange: function onChange(v) {
            _this3.onFieldChange(v, null, fieldType, fieldDbName);
          }
        })));
      } else if (fieldType === FIELD_TYPE.BROWSER) {
        var time = new Date().getTime();
        var otherParams = {};

        if (conditionField) {
          otherParams[conditionField + '_' + time] = WfForm.getFieldValue(WfForm.convertFieldNameToId(conditionField));
        } // 渲染浏览框字段


        return React.createElement(Col, {
          span: 6
        }, React.createElement(WeaFormItem, {
          label: fieldName,
          labelCol: {
            span: 10
          },
          wrapperCol: {
            span: 14
          },
          style: {
            padding: '10px'
          }
        }, React.createElement(WeaBrowser, {
          style: {
            lineHeight: '30px'
          },
          type: 161,
          title: browserTitle,
          viewAttr: 2,
          displaySearchAd: true,
          hasAdvanceSerach: true,
          displaySearchAdInBar: true,
          dataParams: _objectSpread({
            type: browserType,
            fielddbtype: browserType
          }, otherParams),
          conditionDataParams: {
            type: browserType,
            fielddbtype: browserType,
            disabledConditionCache: true,
            fromModule: 'workflow',
            viewtype: '1'
          },
          completeParams: {
            type: browserType,
            fielddbtype: browserType,
            disabledConditionCache: true,
            fromModule: 'workflow',
            viewtype: '1'
          },
          dataURL: "/api/public/browser/data/161",
          onChange: function onChange(ids, names, datas) {
            _this3.onFieldChange(ids, names, fieldType, fieldDbName);
          }
        })));
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this4 = this;

      var _this$props3 = this.props,
          fields = _this$props3.fields,
          detailName = _this$props3.detailName;
      return React.createElement(React.Fragment, null, React.createElement(Button, {
        size: 'small',
        style: {
          color: 'white'
        },
        onClick: function onClick() {
          var checked = WfForm.getDetailCheckedRowIndexStr(detailName);

          if (!checked) {
            message.error('请勾选明细数据', 5);
            return;
          }

          _this4.setState({
            visible: true
          }); // 每次弹出对话框时都要清空对话框中的字段数据


          _this4.cleanFieldData();
        }
      }, "\u6279\u91CF\u7F16\u8F91"), React.createElement(Modal, {
        title: "\u6279\u91CF\u7F16\u8F91",
        visible: this.state.visible,
        onCancel: this.handleCancel,
        onOk: this.handleOk,
        width: '1200px',
        confirmLoading: this.state.loading
      }, React.createElement("div", null, React.createElement(Row, null, fields.map(function (item, index) {
        return _this4.getFieldElement(item.name, item.type, item.browserType, item.browserTitle, item.dbName, item.conditionField);
      })))));
    }
  }]);

  return BatchChangeDialog;
}(React.Component);

ecodeSDK.setCom('${appId}', 'batchEdit', BatchChangeDialog);