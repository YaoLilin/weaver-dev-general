作者：泛微柳州 姚礼林
日期：2025-08-27

# 实现效果
移动端流程上传图片文件可以进行压缩处理，防止上传文件和浏览文件过慢。
- 可实现在特定流程启用是否压缩图像
- 可对图像分辨率和质量进行压缩
- 可对压缩质量进行配置

# 使用方法
ecode应用发布即可启用，采用组件参数拦截的方法，重写添加文件函数

# 配置说明
编辑 config/config.js 中的配置  
配置示例：
```javascript
const config = {
  // 启用上传图片压缩的流程表单id，流程表单id获取方式，如果表名为 formtable_main_16 ，则表单id为：-16
  enableWorkflowFormIds: [-16],
  // 图像压缩配置
  compressorConfig: {
    // 图像分辨率压缩百分比 (0-1)
    resolutionScale: 1,

    // 质量压缩百分比 (0-1)
    quality: 0.6,

    // 图像分辨率超过多少启用压缩 (像素)
    minResolution: 800,

    // 文件大小超过多少后启用压缩 (字节)
    minFileSize: 500 * 1024,

    // 是否自动转换为JPG格式
    autoConvertToJpg: true,

    // 输出格式
    outputFormat: 'jpeg',

    // 是否启用日志输出
    enableLogging: true
  }
}
```
- enableWorkflowFormIds :可配置哪些流程启用图像压缩功能，如配置为空则所有流程启用
- compressorConfig ：图像压缩相关配置