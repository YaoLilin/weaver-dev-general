# ImageCompressor 通用图片压缩组件

## 概述

`ImageCompressor` 是一个通用的图片压缩组件，支持自定义压缩参数，可处理各种文件对象类型。该组件完全解耦，可以集成到任何需要图片压缩功能的项目中。

## 特性

- **智能压缩**: 支持分辨率和质量双重压缩
- **可配置参数**: 分辨率压缩比例、质量压缩比例、最小分辨率阈值、最小文件大小阈值
- **多格式支持**: 支持 JPEG、PNG、WebP 等格式
- **移动端优化**: 针对移动端场景优化
- **批量处理**: 支持批量压缩和进度回调
- **错误处理**: 完善的错误处理和重试机制
- **性能监控**: 内置性能统计和监控功能

## 快速开始

### 1. 引入组件

```javascript
const ImageCompressor = ecodeSDK.getCom('72b82b4e77374be6ab3fe6d193e9e87d','ImageCompressor');
```

### 2. 基础使用

```javascript
// 创建压缩器实例（使用默认配置）
const compressor = new ImageCompressor();

// 压缩单个图片文件
const result = await compressor.compress(file);
if (result.compressed) {
    console.log('压缩成功:', result);
    // result.file 是压缩后的File对象
}
```

### 3. 自定义配置

```javascript
// 创建自定义配置的压缩器
const compressor = new ImageCompressor({
    resolutionScale: 0.3,        // 分辨率压缩到30%
    quality: 0.8,                // 质量压缩到80%
    minResolution: 1200,         // 分辨率超过1200px才压缩
    minFileSize: 100 * 1024,     // 文件大小超过100KB才压缩
    autoConvertToJpg: true,      // 自动转换为JPG格式
    outputFormat: 'jpeg',        // 输出格式为JPEG
    enableLogging: true          // 启用日志输出
});
```

## 配置选项

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `resolutionScale` | number | 0.5 | 图像分辨率压缩百分比 (0-1) |
| `quality` | number | 0.7 | 质量压缩百分比 (0-1) |
| `minResolution` | number | 800 | 图像分辨率超过多少启用压缩 (像素) |
| `minFileSize` | number | 50KB | 文件大小超过多少后启用压缩 (字节) |
| `autoConvertToJpg` | boolean | true | 是否自动转换为JPG格式 |
| `outputFormat` | string | 'jpeg' | 输出格式 ('jpeg', 'png', 'webp') |
| `enableLogging` | boolean | true | 是否启用日志输出 |

## API 参考
### 构造函数

```javascript
new ImageCompressor(options)
```

### 实例方法

#### `compress(file, fileName)`
压缩单个图片文件

**参数:**
- `file`: File|Blob|string - 要压缩的文件
- `fileName`: string (可选) - 文件名

**返回值:** Promise<Object> - 压缩结果对象

**结果对象结构:**
```javascript
{
    file: File,                    // 压缩后的File对象
        name: string,                  // 文件名
        size: number,                  // 文件大小
        type: string,                  // 文件类型
        compressed: boolean,           // 是否已压缩
        base64: string,              // base64 URL (需要时生成)
        metadata: {                    // 压缩元数据
        originalSize: number,      // 原始大小
            compressedSize: number,    // 压缩后大小
            compressionRatio: string   // 压缩比例
    }
}
```

#### `compressBatch(files, progressCallback)`
批量压缩图片文件

**参数:**
- `files`: Array - 文件数组
- `progressCallback`: Function (可选) - 进度回调函数

**返回值:** Promise<Array> - 压缩结果数组

#### `updateConfig(newOptions)`
更新压缩器配置

**参数:**
- `newOptions`: Object - 新的配置选项

#### `getConfig()`
获取当前配置

**返回值:** Object - 当前配置对象

### 静态方法

#### `checkCompatibility()`
检查浏览器兼容性

**返回值:** Object - 兼容性检查结果

```javascript
{
    canvas: boolean,      // 是否支持Canvas
        context2d: boolean,   // 是否支持2D上下文
        fileAPI: boolean,     // 是否支持File API
        blobAPI: boolean,     // 是否支持Blob API
        fileReader: boolean,  // 是否支持FileReader
        urlAPI: boolean       // 是否支持URL API
}
```

## 使用示例

### 示例1: FilePicker组件集成

```javascript
// 使用预定义的集成示例
const { filePickerIntegrationExample } = window.ImageCompressorExamples;
const compressor = filePickerIntegrationExample();
```

### 示例2: 通用文件上传组件

```javascript
// 使用预定义的通用上传示例
const { genericUploadIntegrationExample } = window.ImageCompressorExamples;
const { compressor, processFilesBeforeUpload } = genericUploadIntegrationExample();

// 在上传前处理文件
const compressedFiles = await processFilesBeforeUpload(fileList);
```

### 示例3: 动态配置更新

```javascript
// 使用预定义的动态配置示例
const { dynamicConfigExample } = window.ImageCompressorExamples;
const { compressor, adjustCompressionForNetwork } = dynamicConfigExample();

// 手动调整配置
compressor.updateConfig({
    resolutionScale: 0.4,
    quality: 0.6
});
```

### 示例4: 错误处理和重试

```javascript
// 使用预定义的重试机制示例
const { errorHandlingExample } = window.ImageCompressorExamples;
const { compressWithRetry } = errorHandlingExample();

// 带重试的压缩
const result = await compressWithRetry(file, 3); // 最多重试3次
```

### 示例5: 性能监控

```javascript
// 使用预定义的性能监控示例
const { performanceMonitoringExample } = window.ImageCompressorExamples;
const { compressWithMonitoring, getStatsReport } = performanceMonitoringExample();

// 压缩并监控性能
const result = await compressWithMonitoring(file);

// 获取统计报告
const stats = getStatsReport();
console.log('压缩统计:', stats);
```

## 集成到现有项目

### 1. 直接使用组件

```javascript
// 创建压缩器实例
const compressor = new ImageCompressor({
    resolutionScale: 0.5,
    quality: 0.7,
    minResolution: 800,
    minFileSize: 50 * 1024
});

// 在文件上传前压缩
async function handleFileUpload(file) {
    try {
        const result = await compressor.compress(file);
        if (result.compressed) {
            // 使用压缩后的文件
            uploadFile(result.file);
        } else {
            // 使用原始文件
            uploadFile(file);
        }
    } catch (error) {
        console.error('压缩失败:', error);
        // 使用原始文件
        uploadFile(file);
    }
}
```

### 2. 集成到表单组件

```javascript
// 监听文件输入变化
document.getElementById('fileInput').addEventListener('change', async (event) => {
    const files = event.target.files;
    if (files.length === 0) return;

    const compressor = new ImageCompressor();

    for (let file of files) {
        if (file.type.startsWith('image/')) {
            try {
                const result = await compressor.compress(file);
                // 处理压缩后的文件
                console.log('压缩结果:', result);
            } catch (error) {
                console.error('压缩失败:', error);
            }
        }
    }
});
```

## 网络自适应

组件支持根据网络状况自动调整压缩参数：

```javascript
// 启用网络自适应
if (navigator.connection) {
    navigator.connection.addEventListener('change', () => {
        const connection = navigator.connection;

        if (connection.effectiveType === 'slow-2g' || connection.effectiveType === '2g') {
            // 慢速网络：激进压缩
            compressor.updateConfig({
                resolutionScale: 0.3,
                quality: 0.5,
                minFileSize: 20 * 1024
            });
        } else if (connection.effectiveType === '3g') {
            // 中等网络：中等压缩
            compressor.updateConfig({
                resolutionScale: 0.4,
                quality: 0.6,
                minFileSize: 30 * 1024
            });
        } else {
            // 快速网络：轻微压缩
            compressor.updateConfig({
                resolutionScale: 0.6,
                quality: 0.8,
                minFileSize: 100 * 1024
            });
        }
    });
}
```

## 浏览器兼容性

- ? Chrome 50+
- ? Firefox 45+
- ? Safari 10+
- ? Edge 12+
- ? 移动端浏览器

## 注意事项

1. **文件类型检查**: 组件会自动检查文件类型，只压缩图片文件
2. **内存管理**: 大文件压缩时注意内存使用，建议设置合理的文件大小阈值
3. **异步处理**: 所有压缩操作都是异步的，需要使用 async/await 或 Promise
4. **错误处理**: 建议始终使用 try-catch 包装压缩操作
5. **性能考虑**: 批量压缩时建议使用进度回调，避免阻塞UI

## 故障排除

### 常见问题

**Q: 压缩后文件类型变成了Object？**
A: 确保使用 `result.file` 而不是整个 `result` 对象

**Q: 压缩失败但没有错误信息？**
A: 检查浏览器控制台，确保 `enableLogging: true`

**Q: 某些图片无法压缩？**
A: 检查文件大小和分辨率是否满足压缩条件

**Q: 压缩后文件反而变大了？**
A: 调整 `quality` 和 `resolutionScale` 参数

### 调试模式

```javascript
// 启用详细日志
const compressor = new ImageCompressor({
    enableLogging: true
});

// 检查浏览器兼容性
const compatibility = ImageCompressor.checkCompatibility();
console.log('兼容性检查:', compatibility);
```


