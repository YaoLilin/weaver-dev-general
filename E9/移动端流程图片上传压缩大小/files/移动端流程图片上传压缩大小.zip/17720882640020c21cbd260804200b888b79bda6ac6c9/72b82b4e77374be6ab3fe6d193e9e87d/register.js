

function getCompressorConfig() {
    try {
        const config = getConfig();
        return config.compressorConfig;
    } catch (e) {
        console.error("无法找到图像压缩配置，请检查配置文件");
        return null;
    }
}


// 创建图片压缩器
function createImageCompressor() {
    try {
        const ImageCompressor = ecodeSDK.getCom('${appId}', 'ImageCompressor');
        if (!ImageCompressor) {
            console.error("引入 ImageCompressor 组件失败");
            return null;
        }

        // 创建压缩器实例
        const imageCompressor = new ImageCompressor(getCompressorConfig());

        // 检查浏览器兼容性
        const compatibility = ImageCompressor.checkCompatibility();
        console.log('浏览器兼容性检查:', compatibility);

        if (!compatibility.canvas || !compatibility.context2d) {
            console.warn('浏览器不支持Canvas，图片压缩功能可能无法正常工作');
        }

        console.log('图片压缩器初始化成功:', imageCompressor.getConfig());
        return imageCompressor;

    } catch (error) {
        console.error('图片压缩器初始化失败:', error);
        return null;
    }
}

// 重写FilePicker组件
ecodeSDK.overwriteMobilePropsFnQueueMapSet('FilePicker', {
    fn: (props) => {
        try {
            if (!location.href.includes('spa/workflow/static4mobileform/index.html') || !currentWorkflowEnable()) {
                return;
            }

            // 保存原始的onAdd函数
            const imageCompressor = createImageCompressor();
            overwriteOnAddFn(props, imageCompressor);

            console.log('FilePicker 组件已重写，集成图片压缩功能');
        } catch (e) {
            console.error('FilePicker 组件重写失败:', e)
        }
    }
});

function getConfig() {
    return ecodeSDK.getCom('${appId}', 'config');
}

function currentWorkflowEnable() {
    try {
        const baseInfo = WfForm.getBaseInfo();
        const formId = baseInfo.formid;
        const config = getConfig();
        if(config.enableWorkflowFormIds.length === 0){
          return true;
        }
        return config.enableWorkflowFormIds.includes(formId);
    } catch (e) {
        console.error("判断当前流程是否生效失败", e);
        return false;
    }
}

function overwriteOnAddFn(props, imageCompressor) {
    const originalOnAdd = props.onAdd;
    // 重写onAdd函数，添加图片压缩功能
    props.onAdd = async (file, files) => {
        console.log('FilePicker onAdd 被调用，文件信息:', file);
        console.log('原始file.file类型:', typeof file.file, file.file instanceof File);

        try {
            // 检查是否为图片文件
            if (file.name && isImageFile(file.name)) {
                // 压缩图片
                await compressImageFile(file, imageCompressor);
            } else {
                console.log('非图片文件，跳过压缩:', file.name);
            }

            // 调用原始的onAdd函数
            if (originalOnAdd) {
                originalOnAdd(file, files);
            }

        } catch (error) {
            console.error('FilePicker onAdd 处理异常:', error);
            hideCompressionProgress(loadingToast);
            showCompressionError('图片处理异常，将使用原始图片');

            // 即使出错也要调用原始函数
            if (originalOnAdd) {
                originalOnAdd(file, files);
            }
        }
    };
}


// 辅助函数
function isImageFile(fileName) {
    if (!fileName) return false;
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg'];
    const extension = fileName.toLowerCase().substring(fileName.lastIndexOf('.'));
    return imageExtensions.includes(extension);
}

async function compressImageFile(file, imageCompressor) {
    console.log('检测到图片文件，开始压缩:', file.name);

    // 显示压缩进度提示
    const loadingToast = showCompressionProgress();

    // 使用压缩器压缩图片
    const result = await imageCompressor.compress(file.file || file);

    // 隐藏压缩进度提示
    hideCompressionProgress(loadingToast);

    if (result.compressed) {
        console.log('图片压缩成功:', result);

        // 更新file对象的文件数据
        file.file = result.file;
        file.name = result.name;

        // 如果需要base64 URL
        if (result.base64) {
            file.url = result.base64;
        }

        console.log('压缩后的文件信息:', {
            originalSize: result.metadata.originalSize,
            compressedSize: result.metadata.compressedSize,
            compressionRatio: result.metadata.compressionRatio
        });

        // 验证file.file的类型
        console.log('压缩后file.file的类型:', typeof file.file, file.file instanceof File);
        console.log('压缩后file.file的详细信息:', file.file);

        // 显示压缩成功提示
        const compressionRatio = result.metadata.compressionRatio;
        showCompressionSuccess(`压缩成功！节省空间 ${compressionRatio}`);
    } else {
        console.log('图片无需压缩或压缩失败，使用原始文件');
        // 显示无需压缩的提示
        showCompressionInfo('图片无需压缩，使用原始文件');
    }
}

// Toast提示函数
function showCompressionProgress() {
    try {
        const Toast = WeaverMobile.Toast;
        return Toast.loading('正在压缩图片...', 0, null, true);
    } catch (error) {
        console.warn('WeaverMobile.Toast 不可用，使用console提示');
        console.log('正在压缩图片...');
        return null;
    }
}

function hideCompressionProgress(loadingToast) {
    try {
        if (loadingToast) {
            loadingToast.close();
        }
    } catch (error) {
        console.warn('关闭Toast失败:', error);
    }
}

function showCompressionSuccess(message = '图片压缩成功') {
    try {
        const Toast = WeaverMobile.Toast;
        Toast.success(message, 2, null, false);
    } catch (error) {
        console.warn('WeaverMobile.Toast 不可用，使用console提示');
        console.log('?', message);
    }
}

function showCompressionError(message = '图片压缩失败，将使用原始图片') {
    try {
        const Toast = WeaverMobile.Toast;
        Toast.fail(message, 3, null, false);
    } catch (error) {
        console.warn('WeaverMobile.Toast 不可用，使用console提示');
        console.error('?', message);
    }
}

function showCompressionInfo(message = '图片处理完成') {
    try {
        const Toast = WeaverMobile.Toast;
        Toast.info(message, 2, null, false);
    } catch (error) {
        console.warn('WeaverMobile.Toast 不可用，使用console提示');
        console.log('??', message);
    }
}






