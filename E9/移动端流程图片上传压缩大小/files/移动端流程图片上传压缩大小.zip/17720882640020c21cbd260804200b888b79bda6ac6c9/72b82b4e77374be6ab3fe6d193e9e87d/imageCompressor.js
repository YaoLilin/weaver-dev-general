/**
 * 通用图片压缩组件
 * 支持自定义压缩参数，可处理各种文件对象类型
 */
class ImageCompressor {
    /**
     * 构造函数
     * @param {Object} options 配置选项
     * @param {number} options.resolutionScale 图像分辨率压缩百分比 (0-1, 默认0.5)
     * @param {number} options.quality 质量压缩百分比 (0-1, 默认0.7)
     * @param {number} options.minResolution 图像分辨率超过多少启用压缩 (像素, 默认800)
     * @param {number} options.minFileSize 文件大小超过多少后启用压缩 (字节, 默认50KB)
     * @param {boolean} options.autoConvertToJpg 是否自动转换为JPG格式 (默认true)
     * @param {string} options.outputFormat 输出格式 ('jpeg', 'png', 'webp', 默认'jpeg')
     * @param {boolean} options.enableLogging 是否启用日志输出 (默认true)
     */
    constructor(options = {}) {
        this.config = {
            resolutionScale: options.resolutionScale || 0.5,
            quality: options.quality || 0.7,
            minResolution: options.minResolution || 800,
            minFileSize: options.minFileSize || 50 * 1024,
            autoConvertToJpg: options.autoConvertToJpg !== false,
            outputFormat: options.outputFormat || 'jpeg',
            enableLogging: options.enableLogging !== false
        };

        this.log('图片压缩组件初始化完成', this.config);
    }

    /**
     * 压缩图片文件
     * @param {File|Blob|string} file 要压缩的文件 (File对象、Blob对象或base64字符串)
     * @param {string} fileName 文件名 (可选，如果不提供则自动生成)
     * @returns {Promise<Object>} 压缩结果对象
     */
    async compress(file, fileName = null) {
        try {
            this.log('开始压缩文件:', file);

            // 标准化文件对象
            const normalizedFile = await this.#normalizeFile(file, fileName);
            if (!normalizedFile) {
                throw new Error('无法处理文件对象');
            }

            // 检查是否需要压缩
            if (!this.#shouldCompress(normalizedFile)) {
                this.log('文件无需压缩，返回原始文件');
                return this.#createResult(normalizedFile, false);
            }

            // 执行压缩
            const compressedBlob = await this.#compressImageToBlob(normalizedFile);
            if (!compressedBlob) {
                throw new Error('图片压缩失败');
            }

            // 创建压缩后的文件对象
            const compressedFile = this.#createCompressedFile(compressedBlob, normalizedFile.name);

            // 生成base64 URL
            const base64Url = await this.#createBase64FromBlob(compressedBlob);

            // 创建结果对象
            const result = this.#createResult(compressedFile, true, {
                originalSize: normalizedFile.size,
                compressedSize: compressedBlob.size,
                compressionRatio: this.#calculateCompressionRatio(normalizedFile.size, compressedBlob.size)
            });

            // 设置base64字段
            result.base64 = base64Url;

            this.log('压缩完成:', result);
            return result;

        } catch (error) {
            this.log('压缩失败:', error);
            throw error;
        }
    }

    /**
     * 批量压缩图片文件
     * @param {Array} files 文件数组
     * @param {Function} progressCallback 进度回调函数 (可选)
     * @returns {Promise<Array>} 压缩结果数组
     */
    async compressBatch(files, progressCallback = null) {
        const results = [];
        const total = files.length;

        for (let i = 0; i < total; i++) {
            try {
                if (progressCallback) {
                    progressCallback(i + 1, total, files[i].name || `文件${i + 1}`);
                }

                const result = await this.compress(files[i]);
                results.push(result);

            } catch (error) {
                this.log(`文件 ${i + 1} 压缩失败:`, error);
                            // 压缩失败时，返回原始文件
            const normalizedFile = await this.#normalizeFile(files[i]);
            results.push(this.#createResult(normalizedFile, false, { error: error.message }));
            }
        }

        return results;
    }

        /**
     * 标准化文件对象
     * @param {File|Blob|string} file 输入文件
     * @param {string} fileName 文件名
     * @returns {Promise<File>} 标准化的File对象
     */
    async #normalizeFile(file, fileName) {
        if (file instanceof File) {
            return file;
        }
        
        if (file instanceof Blob) {
            const name = fileName || `compressed_${Date.now()}.${this.config.outputFormat}`;
            return new File([file], name, { type: file.type });
        }
        
        if (typeof file === 'string' && file.startsWith('data:')) {
            // base64字符串
            const name = fileName || `compressed_${Date.now()}.${this.config.outputFormat}`;
            return await this.#createFileFromBase64(file, name);
        }
        
        throw new Error('不支持的文件类型');
    }

    /**
     * 判断是否需要压缩
     * @param {File} file 文件对象
     * @returns {boolean} 是否需要压缩
     */
    #shouldCompress(file) {
        // 检查文件类型
        if (!file.type.startsWith('image/')) {
            this.log('非图片文件，跳过压缩');
            return false;
        }

        // 检查是否已经压缩过
        if (file.name && (file.name.includes('_compressed') || file.name.includes('_min'))) {
            this.log('文件已压缩过，跳过压缩');
            return false;
        }

        // 检查压缩条件：文件大小或分辨率任一条件成立则进行压缩
        const shouldCompressBySize = file.size >= this.config.minFileSize;
        const shouldCompressByResolution = this.#checkResolutionCompression(file);
        
        if (shouldCompressBySize || shouldCompressByResolution) {
            this.log('满足压缩条件:', {
                bySize: shouldCompressBySize ? `文件大小 ${file.size} >= ${this.config.minFileSize}` : '不满足',
                byResolution: shouldCompressByResolution ? '分辨率超过阈值' : '不满足'
            });
            return true;
        }

        this.log('不满足压缩条件:', {
            fileSize: file.size,
            minFileSize: this.config.minFileSize,
            resolutionCompression: this.config.resolutionScale < 1 ? '启用' : '禁用'
        });
        return false;
    }

    /**
     * 检查是否需要基于分辨率进行压缩
     * @param {File} file 文件对象
     * @returns {boolean} 是否需要基于分辨率压缩
     */
    #checkResolutionCompression(file) {
        // 如果用户没有启用分辨率压缩，则不基于分辨率压缩
        if (this.config.resolutionScale >= 1) {
            return false;
        }

        // 这里需要获取图片的实际尺寸来判断
        // 由于在shouldCompress阶段无法获取图片尺寸，我们返回true让压缩逻辑处理
        // 实际的尺寸判断会在compressImageToBlob中进行
        return true;
    }

    /**
     * 压缩图片到Blob对象
     * @param {File} file 原始文件
     * @returns {Promise<Blob>} 压缩后的Blob对象
     */
    async #compressImageToBlob(file) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            // 设置跨域处理
            img.crossOrigin = 'anonymous';

            img.onload = () => {
                try {
                    // 计算压缩后的尺寸
                    const originalWidth = img.width;
                    const originalHeight = img.height;

                    // 检查分辨率是否需要压缩
                    const maxDimension = Math.max(originalWidth, originalHeight);
                    let scale = 1;

                    // 分辨率压缩逻辑：基于resolutionScale和minResolution
                    if (this.config.resolutionScale < 1) {
                        // 用户启用了分辨率压缩
                        scale = this.config.resolutionScale;
                        
                        // 如果设置了最小分辨率阈值，确保不会压缩过度
                        if (maxDimension > this.config.minResolution) {
                            const minScale = this.config.minResolution / maxDimension;
                            scale = Math.min(scale, minScale);
                            this.log('分辨率压缩受minResolution限制:', {
                                userScale: this.config.resolutionScale,
                                minScale: minScale.toFixed(3),
                                finalScale: scale.toFixed(3)
                            });
                        }
                    } else {
                        // 用户没有启用分辨率压缩，保持原始尺寸
                        scale = 1;
                        this.log('分辨率压缩已禁用，保持原始尺寸');
                    }

                    const newWidth = Math.round(originalWidth * scale);
                    const newHeight = Math.round(originalHeight * scale);

                    // 设置canvas尺寸
                    canvas.width = newWidth;
                    canvas.height = newHeight;

                    // 绘制图片
                    ctx.fillStyle = '#fff';
                    ctx.fillRect(0, 0, newWidth, newHeight);
                    ctx.drawImage(img, 0, 0, newWidth, newHeight);

                    // 转换为blob
                    canvas.toBlob((blob) => {
                        if (blob) {
                            this.log('图片压缩完成:', {
                                originalDimensions: `${originalWidth}x${originalHeight}`,
                                compressedDimensions: `${newWidth}x${newHeight}`,
                                scale: scale.toFixed(2),
                                resolutionCompression: this.config.resolutionScale < 1 ? '启用' : '禁用',
                                minResolutionThreshold: this.config.minResolution
                            });
                            resolve(blob);
                        } else {
                            reject(new Error('图片压缩失败'));
                        }
                    }, `image/${this.config.outputFormat}`, this.config.quality);

                } catch (error) {
                    reject(error);
                } finally {
                    // 清理资源
                    if (img.src.startsWith('blob:')) {
                        URL.revokeObjectURL(img.src);
                    }
                }
            };

            img.onerror = (error) => {
                if (img.src.startsWith('blob:')) {
                    URL.revokeObjectURL(img.src);
                }
                reject(new Error('图片加载失败'));
            };

            // 开始加载图片
            if (file instanceof File) {
                img.src = URL.createObjectURL(file);
            } else {
                img.src = file;
            }
        });
    }

    /**
     * 创建压缩后的文件对象
     * @param {Blob} blob 压缩后的blob
     * @param {string} originalName 原始文件名
     * @returns {File} 压缩后的File对象
     */
    #createCompressedFile(blob, originalName) {
        let newName = originalName;

        if (this.config.autoConvertToJpg && this.config.outputFormat === 'jpeg') {
            const extension = originalName.substring(originalName.lastIndexOf('.'));
            newName = originalName.replace(extension, '.jpg');
        }

        return new File([blob], newName, {
            type: `image/${this.config.outputFormat}`,
            lastModified: Date.now()
        });
    }

    /**
     * 创建结果对象
     * @param {File} file 文件对象
     * @param {boolean} compressed 是否已压缩
     * @param {Object} metadata 元数据
     * @returns {Object} 结果对象
     */
    #createResult(file, compressed, metadata = {}) {
        return {
            file: file,                    // File对象
            name: file.name,               // 文件名
            size: file.size,               // 文件大小
            type: file.type,               // 文件类型
            compressed: compressed,        // 是否已压缩
            base64: null,                     // base64 URL (需要时生成)
            metadata: metadata             // 压缩元数据
        };
    }

    /**
     * 计算压缩比例
     * @param {number} originalSize 原始大小
     * @param {number} compressedSize 压缩后大小
     * @returns {string} 压缩比例字符串
     */
    #calculateCompressionRatio(originalSize, compressedSize) {
        const ratio = ((originalSize - compressedSize) / originalSize * 100).toFixed(2);
        return `${ratio}%`;
    }

    /**
     * 从base64 URL创建文件对象
     * @param {string} base64Url base64数据URL
     * @param {string} fileName 文件名
     * @returns {Promise<File>} 文件对象
     */
    async #createFileFromBase64(base64Url, fileName) {
        try {
            const base64Data = base64Url.split(',')[1];
            const byteCharacters = atob(base64Data);
            const byteNumbers = new Array(byteCharacters.length);

            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }

            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: `image/${this.config.outputFormat}` });

            return new File([blob], fileName, {
                type: `image/${this.config.outputFormat}`,
                lastModified: Date.now()
            });
        } catch (error) {
            throw new Error('从base64创建文件失败: ' + error.message);
        }
    }

    /**
     * 从Blob创建base64 URL
     * @param {Blob} blob Blob对象
     * @returns {Promise<string>} base64数据URL
     */
    async #createBase64FromBlob(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(new Error('读取文件失败'));
            reader.readAsDataURL(blob);
        });
    }

    /**
     * 更新配置
     * @param {Object} newOptions 新的配置选项
     */
    updateConfig(newOptions) {
        this.config = { ...this.config, ...newOptions };
        this.log('配置已更新:', this.config);
    }

    /**
     * 获取当前配置
     * @returns {Object} 当前配置
     */
    getConfig() {
        return { ...this.config };
    }

    /**
     * 日志输出
     * @param {...any} args 日志参数
     */
    log(...args) {
        if (this.config.enableLogging) {
            console.log('[ImageCompressor]', ...args);
        }
    }

    /**
     * 检查浏览器兼容性
     * @returns {Object} 兼容性检查结果
     */
    static checkCompatibility() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        return {
            canvas: !!canvas,
            context2d: !!ctx,
            fileAPI: typeof File !== 'undefined',
            blobAPI: typeof Blob !== 'undefined',
            fileReader: typeof FileReader !== 'undefined',
            urlAPI: typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function'
        };
    }
}

// 导出组件
ecodeSDK.setCom('${appId}','ImageCompressor',ImageCompressor);
