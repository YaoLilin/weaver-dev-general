"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classPrivateFieldLooseBase(receiver, privateKey) { if (!Object.prototype.hasOwnProperty.call(receiver, privateKey)) { throw new TypeError("attempted to use private field on non-instance"); } return receiver; }

var id = 0;

function _classPrivateFieldLooseKey(name) { return "__private_" + id++ + "_" + name; }

/**
 * 通用图片压缩组件
 * 支持自定义压缩参数，可处理各种文件对象类型
 */
var ImageCompressor =
/*#__PURE__*/
function () {
  /**
   * 构造函数
   * @param {Object} options 配置选项
   * @param {number} options.resolutionScale 图像分辨率压缩百分比 (0-1, 默认0.5)
   * @param {number} options.quality 质量压缩百分比 (0-1, 默认0.7)
   * @param {number} options.minResolution 图像分辨率超过多少启用压缩 (像素, 默认800)
   * @param {number} options.minFileSize 文件大小超过多少后启用压缩 (字节, 默认50KB)
   * @param {boolean} options.autoConvertToJpg 是否自动转换为JPG格式 (默认true)
   * @param {string} options.outputFormat 输出格式 ('jpeg', 'png', 'webp', 默认'jpeg')
   * @param {boolean} options.enableLogging 是否启用日志输出 (默认true)
   */
  function ImageCompressor() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck(this, ImageCompressor);

    Object.defineProperty(this, _createBase64FromBlob, {
      value: _createBase64FromBlob2
    });
    Object.defineProperty(this, _createFileFromBase, {
      value: _createFileFromBase2
    });
    Object.defineProperty(this, _calculateCompressionRatio, {
      value: _calculateCompressionRatio2
    });
    Object.defineProperty(this, _createResult, {
      value: _createResult2
    });
    Object.defineProperty(this, _createCompressedFile, {
      value: _createCompressedFile2
    });
    Object.defineProperty(this, _compressImageToBlob, {
      value: _compressImageToBlob2
    });
    Object.defineProperty(this, _checkResolutionCompression, {
      value: _checkResolutionCompression2
    });
    Object.defineProperty(this, _shouldCompress, {
      value: _shouldCompress2
    });
    Object.defineProperty(this, _normalizeFile, {
      value: _normalizeFile2
    });
    this.config = {
      resolutionScale: options.resolutionScale || 0.5,
      quality: options.quality || 0.7,
      minResolution: options.minResolution || 800,
      minFileSize: options.minFileSize || 50 * 1024,
      autoConvertToJpg: options.autoConvertToJpg !== false,
      outputFormat: options.outputFormat || 'jpeg',
      enableLogging: options.enableLogging !== false
    };
    this.log('图片压缩组件初始化完成', this.config);
  }
  /**
   * 压缩图片文件
   * @param {File|Blob|string} file 要压缩的文件 (File对象、Blob对象或base64字符串)
   * @param {string} fileName 文件名 (可选，如果不提供则自动生成)
   * @returns {Promise<Object>} 压缩结果对象
   */


  _createClass(ImageCompressor, [{
    key: "compress",
    value: async function compress(file) {
      var fileName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      try {
        this.log('开始压缩文件:', file); // 标准化文件对象

        var normalizedFile = await _classPrivateFieldLooseBase(this, _normalizeFile)[_normalizeFile](file, fileName);

        if (!normalizedFile) {
          throw new Error('无法处理文件对象');
        } // 检查是否需要压缩


        if (!_classPrivateFieldLooseBase(this, _shouldCompress)[_shouldCompress](normalizedFile)) {
          this.log('文件无需压缩，返回原始文件');
          return _classPrivateFieldLooseBase(this, _createResult)[_createResult](normalizedFile, false);
        } // 执行压缩


        var compressedBlob = await _classPrivateFieldLooseBase(this, _compressImageToBlob)[_compressImageToBlob](normalizedFile);

        if (!compressedBlob) {
          throw new Error('图片压缩失败');
        } // 创建压缩后的文件对象


        var compressedFile = _classPrivateFieldLooseBase(this, _createCompressedFile)[_createCompressedFile](compressedBlob, normalizedFile.name); // 生成base64 URL


        var base64Url = await _classPrivateFieldLooseBase(this, _createBase64FromBlob)[_createBase64FromBlob](compressedBlob); // 创建结果对象

        var result = _classPrivateFieldLooseBase(this, _createResult)[_createResult](compressedFile, true, {
          originalSize: normalizedFile.size,
          compressedSize: compressedBlob.size,
          compressionRatio: _classPrivateFieldLooseBase(this, _calculateCompressionRatio)[_calculateCompressionRatio](normalizedFile.size, compressedBlob.size)
        }); // 设置base64字段


        result.base64 = base64Url;
        this.log('压缩完成:', result);
        return result;
      } catch (error) {
        this.log('压缩失败:', error);
        throw error;
      }
    }
    /**
     * 批量压缩图片文件
     * @param {Array} files 文件数组
     * @param {Function} progressCallback 进度回调函数 (可选)
     * @returns {Promise<Array>} 压缩结果数组
     */

  }, {
    key: "compressBatch",
    value: async function compressBatch(files) {
      var progressCallback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var results = [];
      var total = files.length;

      for (var i = 0; i < total; i++) {
        try {
          if (progressCallback) {
            progressCallback(i + 1, total, files[i].name || "\u6587\u4EF6".concat(i + 1));
          }

          var result = await this.compress(files[i]);
          results.push(result);
        } catch (error) {
          this.log("\u6587\u4EF6 ".concat(i + 1, " \u538B\u7F29\u5931\u8D25:"), error); // 压缩失败时，返回原始文件

          var normalizedFile = await _classPrivateFieldLooseBase(this, _normalizeFile)[_normalizeFile](files[i]);
          results.push(_classPrivateFieldLooseBase(this, _createResult)[_createResult](normalizedFile, false, {
            error: error.message
          }));
        }
      }

      return results;
    }
    /**
    * 标准化文件对象
    * @param {File|Blob|string} file 输入文件
    * @param {string} fileName 文件名
    * @returns {Promise<File>} 标准化的File对象
    */

  }, {
    key: "updateConfig",

    /**
     * 更新配置
     * @param {Object} newOptions 新的配置选项
     */
    value: function updateConfig(newOptions) {
      this.config = _objectSpread({}, this.config, {}, newOptions);
      this.log('配置已更新:', this.config);
    }
    /**
     * 获取当前配置
     * @returns {Object} 当前配置
     */

  }, {
    key: "getConfig",
    value: function getConfig() {
      return _objectSpread({}, this.config);
    }
    /**
     * 日志输出
     * @param {...any} args 日志参数
     */

  }, {
    key: "log",
    value: function log() {
      if (this.config.enableLogging) {
        var _console;

        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        (_console = console).log.apply(_console, ['[ImageCompressor]'].concat(args));
      }
    }
    /**
     * 检查浏览器兼容性
     * @returns {Object} 兼容性检查结果
     */

  }], [{
    key: "checkCompatibility",
    value: function checkCompatibility() {
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');
      return {
        canvas: !!canvas,
        context2d: !!ctx,
        fileAPI: typeof File !== 'undefined',
        blobAPI: typeof Blob !== 'undefined',
        fileReader: typeof FileReader !== 'undefined',
        urlAPI: typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function'
      };
    }
  }]);

  return ImageCompressor;
}(); // 导出组件


var _normalizeFile = _classPrivateFieldLooseKey("normalizeFile");

var _shouldCompress = _classPrivateFieldLooseKey("shouldCompress");

var _checkResolutionCompression = _classPrivateFieldLooseKey("checkResolutionCompression");

var _compressImageToBlob = _classPrivateFieldLooseKey("compressImageToBlob");

var _createCompressedFile = _classPrivateFieldLooseKey("createCompressedFile");

var _createResult = _classPrivateFieldLooseKey("createResult");

var _calculateCompressionRatio = _classPrivateFieldLooseKey("calculateCompressionRatio");

var _createFileFromBase = _classPrivateFieldLooseKey("createFileFromBase64");

var _createBase64FromBlob = _classPrivateFieldLooseKey("createBase64FromBlob");

var _normalizeFile2 = async function _normalizeFile2(file, fileName) {
  if (_instanceof(file, File)) {
    return file;
  }

  if (_instanceof(file, Blob)) {
    var name = fileName || "compressed_".concat(Date.now(), ".").concat(this.config.outputFormat);
    return new File([file], name, {
      type: file.type
    });
  }

  if (typeof file === 'string' && file.startsWith('data:')) {
    // base64字符串
    var _name = fileName || "compressed_".concat(Date.now(), ".").concat(this.config.outputFormat);

    return await _classPrivateFieldLooseBase(this, _createFileFromBase)[_createFileFromBase](file, _name);
  }

  throw new Error('不支持的文件类型');
};

var _shouldCompress2 = function _shouldCompress2(file) {
  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    this.log('非图片文件，跳过压缩');
    return false;
  } // 检查是否已经压缩过


  if (file.name && (file.name.includes('_compressed') || file.name.includes('_min'))) {
    this.log('文件已压缩过，跳过压缩');
    return false;
  } // 检查压缩条件：文件大小或分辨率任一条件成立则进行压缩


  var shouldCompressBySize = file.size >= this.config.minFileSize;

  var shouldCompressByResolution = _classPrivateFieldLooseBase(this, _checkResolutionCompression)[_checkResolutionCompression](file);

  if (shouldCompressBySize || shouldCompressByResolution) {
    this.log('满足压缩条件:', {
      bySize: shouldCompressBySize ? "\u6587\u4EF6\u5927\u5C0F ".concat(file.size, " >= ").concat(this.config.minFileSize) : '不满足',
      byResolution: shouldCompressByResolution ? '分辨率超过阈值' : '不满足'
    });
    return true;
  }

  this.log('不满足压缩条件:', {
    fileSize: file.size,
    minFileSize: this.config.minFileSize,
    resolutionCompression: this.config.resolutionScale < 1 ? '启用' : '禁用'
  });
  return false;
};

var _checkResolutionCompression2 = function _checkResolutionCompression2(file) {
  // 如果用户没有启用分辨率压缩，则不基于分辨率压缩
  if (this.config.resolutionScale >= 1) {
    return false;
  } // 这里需要获取图片的实际尺寸来判断
  // 由于在shouldCompress阶段无法获取图片尺寸，我们返回true让压缩逻辑处理
  // 实际的尺寸判断会在compressImageToBlob中进行


  return true;
};

var _compressImageToBlob2 = async function _compressImageToBlob2(file) {
  var _this = this;

  return new Promise(function (resolve, reject) {
    var img = new Image();
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d'); // 设置跨域处理

    img.crossOrigin = 'anonymous';

    img.onload = function () {
      try {
        // 计算压缩后的尺寸
        var originalWidth = img.width;
        var originalHeight = img.height; // 检查分辨率是否需要压缩

        var maxDimension = Math.max(originalWidth, originalHeight);
        var scale = 1; // 分辨率压缩逻辑：基于resolutionScale和minResolution

        if (_this.config.resolutionScale < 1) {
          // 用户启用了分辨率压缩
          scale = _this.config.resolutionScale; // 如果设置了最小分辨率阈值，确保不会压缩过度

          if (maxDimension > _this.config.minResolution) {
            var minScale = _this.config.minResolution / maxDimension;
            scale = Math.min(scale, minScale);

            _this.log('分辨率压缩受minResolution限制:', {
              userScale: _this.config.resolutionScale,
              minScale: minScale.toFixed(3),
              finalScale: scale.toFixed(3)
            });
          }
        } else {
          // 用户没有启用分辨率压缩，保持原始尺寸
          scale = 1;

          _this.log('分辨率压缩已禁用，保持原始尺寸');
        }

        var newWidth = Math.round(originalWidth * scale);
        var newHeight = Math.round(originalHeight * scale); // 设置canvas尺寸

        canvas.width = newWidth;
        canvas.height = newHeight; // 绘制图片

        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, newWidth, newHeight);
        ctx.drawImage(img, 0, 0, newWidth, newHeight); // 转换为blob

        canvas.toBlob(function (blob) {
          if (blob) {
            _this.log('图片压缩完成:', {
              originalDimensions: "".concat(originalWidth, "x").concat(originalHeight),
              compressedDimensions: "".concat(newWidth, "x").concat(newHeight),
              scale: scale.toFixed(2),
              resolutionCompression: _this.config.resolutionScale < 1 ? '启用' : '禁用',
              minResolutionThreshold: _this.config.minResolution
            });

            resolve(blob);
          } else {
            reject(new Error('图片压缩失败'));
          }
        }, "image/".concat(_this.config.outputFormat), _this.config.quality);
      } catch (error) {
        reject(error);
      } finally {
        // 清理资源
        if (img.src.startsWith('blob:')) {
          URL.revokeObjectURL(img.src);
        }
      }
    };

    img.onerror = function (error) {
      if (img.src.startsWith('blob:')) {
        URL.revokeObjectURL(img.src);
      }

      reject(new Error('图片加载失败'));
    }; // 开始加载图片


    if (_instanceof(file, File)) {
      img.src = URL.createObjectURL(file);
    } else {
      img.src = file;
    }
  });
};

var _createCompressedFile2 = function _createCompressedFile2(blob, originalName) {
  var newName = originalName;

  if (this.config.autoConvertToJpg && this.config.outputFormat === 'jpeg') {
    var extension = originalName.substring(originalName.lastIndexOf('.'));
    newName = originalName.replace(extension, '.jpg');
  }

  return new File([blob], newName, {
    type: "image/".concat(this.config.outputFormat),
    lastModified: Date.now()
  });
};

var _createResult2 = function _createResult2(file, compressed) {
  var metadata = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return {
    file: file,
    // File对象
    name: file.name,
    // 文件名
    size: file.size,
    // 文件大小
    type: file.type,
    // 文件类型
    compressed: compressed,
    // 是否已压缩
    base64: null,
    // base64 URL (需要时生成)
    metadata: metadata // 压缩元数据

  };
};

var _calculateCompressionRatio2 = function _calculateCompressionRatio2(originalSize, compressedSize) {
  var ratio = ((originalSize - compressedSize) / originalSize * 100).toFixed(2);
  return "".concat(ratio, "%");
};

var _createFileFromBase2 = async function _createFileFromBase2(base64Url, fileName) {
  try {
    var base64Data = base64Url.split(',')[1];
    var byteCharacters = atob(base64Data);
    var byteNumbers = new Array(byteCharacters.length);

    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    var byteArray = new Uint8Array(byteNumbers);
    var blob = new Blob([byteArray], {
      type: "image/".concat(this.config.outputFormat)
    });
    return new File([blob], fileName, {
      type: "image/".concat(this.config.outputFormat),
      lastModified: Date.now()
    });
  } catch (error) {
    throw new Error('从base64创建文件失败: ' + error.message);
  }
};

var _createBase64FromBlob2 = async function _createBase64FromBlob2(blob) {
  return new Promise(function (resolve, reject) {
    var reader = new FileReader();

    reader.onload = function () {
      return resolve(reader.result);
    };

    reader.onerror = function () {
      return reject(new Error('读取文件失败'));
    };

    reader.readAsDataURL(blob);
  });
};

ecodeSDK.setCom('${appId}', 'ImageCompressor', ImageCompressor);