"use strict";

var config = {
  // 启用上传图片压缩的流程表单id，流程表单id获取方式，如果表名为 formtable_main_16 ，则表单id为：-16
  enableWorkflowFormIds: [-16],
  // 图像压缩配置
  compressorConfig: {
    // 图像分辨率压缩百分比 (0-1)
    resolutionScale: 1,
    // 质量压缩百分比 (0-1)
    quality: 0.6,
    // 图像分辨率超过多少启用压缩 (像素)
    minResolution: 800,
    // 文件大小超过多少后启用压缩 (字节)
    minFileSize: 500 * 1024,
    // 是否自动转换为JPG格式
    autoConvertToJpg: true,
    // 输出格式
    outputFormat: 'jpeg',
    // 是否启用日志输出
    enableLogging: true
  }
};
ecodeSDK.setCom('${appId}', 'config', config);